from pathlib import Path
import hashlib,sqlite3,subprocess,sys,tempfile
source=Path(__file__).with_name('oms-windows-session-state.py').read_text()
with tempfile.TemporaryDirectory(prefix='oms-state-archive-check-') as root:
 root=Path(root);home=root/'home';home.mkdir();backups=root/'backups';backups.mkdir();archive=backups/'prior'
 code=source.replace("'C:/ProgramData/OMSStudyHub-V2/codex-session'",repr(home.as_posix())).replace("'C:/ProgramData/OMSStudyHub-V2/backups'",repr(backups.as_posix()))
 script=root/'helper.py';script.write_text(code)
 for name in ('state_5.sqlite','logs_2.sqlite','goals_1.sqlite','memories_1.sqlite','queue_1.sqlite'):
  db=sqlite3.connect(home/name);db.execute('CREATE TABLE threads(id INTEGER)');db.commit();db.close()
 (home/'auth.json').write_text('synthetic-auth-marker')
 expected={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in home.iterdir()}
 subprocess.run([sys.executable,str(script),'archive',str(archive)],check=True)
 assert [p.name for p in home.iterdir()]==['auth.json']
 (home/'state_5.sqlite').write_bytes(b'synthetic replacement state')
 subprocess.run([sys.executable,str(script),'restore',str(archive)],check=True)
 assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in home.iterdir()}==expected
 subprocess.run([sys.executable,str(script),'verify_original',str(archive)],check=True)
 (home/'queue_1.sqlite').write_bytes(b'corrupt fixture')
 assert subprocess.run([sys.executable,str(script),'verify_original',str(archive)],capture_output=True).returncode!=0
 assert (archive/'replacement-state/state_5.sqlite').read_bytes()==b'synthetic replacement state'
 print('Native archive/restore preserves every original byte and retains replacement state.',flush=True)
