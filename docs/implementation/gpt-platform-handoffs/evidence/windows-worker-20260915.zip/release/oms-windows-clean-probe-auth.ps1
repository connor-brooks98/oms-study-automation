$ErrorActionPreference='Stop'
$root='C:\Users\conbr\AppData\Local\Temp\oms-win-20260915a'
if(-not (Test-Path 'C:\ProgramData\OMSStudyHub-V2\codex-session\auth.json' -PathType Leaf)){throw 'Live auth missing.'}
$removed=@()
foreach($name in @('provider-home','provider-home-identity','provider-home-final')) {
 $path=Join-Path $root ($name+'\auth.json')
 if(Test-Path -LiteralPath $path -PathType Leaf){
  if((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Unexpected probe-auth reparse point.'}
  Remove-Item -LiteralPath $path
  $removed+=$name
 }
}
@{removed_probe_auth=$removed;live_auth_retained=(Test-Path 'C:\ProgramData\OMSStudyHub-V2\codex-session\auth.json')} | ConvertTo-Json | Set-Content "$root\probe-auth-cleanup.json"
Get-Content "$root\probe-auth-cleanup.json"
