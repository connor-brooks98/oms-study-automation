$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$root='C:\ProgramData\OMSStudyHub-V2\codex-session'
$receipt='C:\Users\conbr\AppData\Local\Temp\oms-win-20260915a\private-descendant-acl-repair.json'
if(Test-Path $receipt){throw 'Repair already recorded; inspect before retry.'}
$rootAcl=Get-Acl -LiteralPath $root
$current=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$allowed=@('S-1-3-4','S-1-5-18','S-1-5-32-544',$current)
function Assert-Private([string]$path) {
 if((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse point is not allowed.'}
 $acl=Get-Acl -LiteralPath $path
 if($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -cne $current){throw 'Unexpected owner.'}
 foreach($rule in $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
  if($rule.IdentityReference.Value -cnotin $allowed -or $rule.AccessControlType -ne 'Allow'){throw 'Unexpected private-directory ACL.'}
 }
 return $acl
}
$null=Assert-Private $root
if(-not $rootAcl.AreAccessRulesProtected){throw 'Private root must remain protected.'}
$paths=@('host-home','host-home\tmp','host-home\AppData','host-home\AppData\Roaming','host-home\AppData\Local') | ForEach-Object {Join-Path $root $_}
$before=@($paths | ForEach-Object { $acl=Assert-Private $_; @{path=$_;sddl=$acl.Sddl} })
$result=[ordered]@{status='prepared';root_sddl=$rootAcl.Sddl;before=$before;after=@();error=$null}
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $receipt
$changed=@()
try {
 foreach($entry in $before) {
  $acl=Get-Acl -LiteralPath $entry.path
  $acl.SetAccessRuleProtection($false,$true)
  Set-Acl -LiteralPath $entry.path -AclObject $acl
  $changed+=,$entry
  $verified=Assert-Private $entry.path
  if($verified.AreAccessRulesProtected){throw 'Descendant still blocks private-root inheritance.'}
  $result.after+=@{path=$entry.path;sddl=$verified.Sddl}
 }
 if((Get-Acl -LiteralPath $root).Sddl -cne $rootAcl.Sddl){throw 'Private root changed.'}
 $result.status='repaired'
} catch {
 $result.error=$_.Exception.Message
 [array]::Reverse($changed)
 foreach($entry in $changed){$acl=Get-Acl -LiteralPath $entry.path;$acl.SetSecurityDescriptorSddlForm($entry.sddl);Set-Acl -LiteralPath $entry.path -AclObject $acl}
 $result.status='rolled_back'
} finally {$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $receipt}
Write-Output ($result | ConvertTo-Json -Depth 5)
if($result.status -cne 'repaired'){exit 1}
