[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][ValidatePattern('^[0-9a-f]{40}$')][string]$TargetCommit,
  [Parameter(Mandatory = $true)][ValidatePattern('^[0-9a-f]{40}$')][string]$TargetTree
)

# Bounded, schema-compatible code rollout. Root separately validates dependencies.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Set-StrictMode -Version Latest
$ProjectRoot = 'C:\Services\oms-study-automation-v2'
$TaskName = 'OMS Study Hub V2'
$DataRoot = 'C:\ProgramData\OMSStudyHub-V2'
$BackupRoot = Join-Path $DataRoot ('backups\windows-worker-20260915-' + [guid]::NewGuid().ToString('N'))
$OldCommit = '0d35dff67759c23d6b74cd53dbafa6dd343ae6e0'
$OldTree = '87e06b8cdd70173cbc1373e5b420031209ff0ce4'
$EnvHash = (Get-FileHash (Join-Path $ProjectRoot '.env') -Algorithm SHA256).Hash
$Python = Join-Path $ProjectRoot '.venv\Scripts\python.exe'
$Receipt = Join-Path $BackupRoot ('code-deployment-result-{0}-{1}.json' -f [datetime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ'), [guid]::NewGuid().ToString('N'))
$Utf8 = New-Object Text.UTF8Encoding($false)
$RuntimeSource = 'C:\Users\conbr\AppData\Local\OMSStudyHub\acceptance\runtime-build-734bbdfad4a9\target\codex-no-lto-20260913\x86_64-pc-windows-msvc\release\codex.exe'
$RuntimeRoot = Join-Path $DataRoot 'runtimes\codex-d6eb90b7409d'
$RuntimeTarget = Join-Path $RuntimeRoot 'codex.exe'
$RuntimeHash = 'd6eb90b7409dc22f407a9dfa44ec629a8a5a6bf3ca001493aef13dd85a75dbda'
$OriginalEnvHash = $EnvHash
$EnvChanged = $false
$StateArchived = $false
$StateAttempted = $false
$StateArchive = Join-Path $BackupRoot 'prior-runtime-state'
$StateScript = 'C:\Users\conbr\AppData\Local\Temp\oms-windows-session-state.py'
$StopAttempted = $false
$StopTime = $null
$Result = [ordered]@{ status='preflight_failed'; old_commit=$OldCommit; old_tree=$OldTree; target_commit=$TargetCommit; target_tree=$TargetTree; backup=$BackupRoot; receipt=$Receipt; downtime_seconds=$null; rollback=$null; error=$null; health=$null; completed_utc=$null }

function Invoke-ReleaseGit {
  param([string[]]$Arguments)
  $output = @(& git.exe -C $ProjectRoot @Arguments)
  if ($LASTEXITCODE -ne 0) { throw ('Git failed: ' + ($Arguments -join ' ')) }
  return $output
}
function Assert-Source {
  param([string]$Commit, [string]$Tree)
  if ((Invoke-ReleaseGit @('branch','--show-current')) -cne 'main' -or
      (Invoke-ReleaseGit @('rev-parse','HEAD')) -cne $Commit -or
      (Invoke-ReleaseGit @('rev-parse','HEAD^{tree}')) -cne $Tree -or
      @(Invoke-ReleaseGit @('status','--porcelain=v1','--untracked-files=no')).Count -ne 0 -or
      @(Invoke-ReleaseGit @('status','--porcelain=v1','--untracked-files=all','--','src','scripts','pyproject.toml')).Count -ne 0) { throw 'Source identity or cleanliness changed.' }
}
function Assert-TaskAndConfig {
  if ((Get-FileHash (Join-Path $ProjectRoot '.env') -Algorithm SHA256).Hash -ine $EnvHash) { throw 'Environment configuration changed.' }
  $task = Get-ScheduledTask -TaskName $TaskName
  $savedXml = [IO.File]::ReadAllText((Join-Path $BackupRoot 'task.xml')).TrimEnd()
  if ((Export-ScheduledTask -TaskName $TaskName).TrimEnd() -cne $savedXml) { throw 'Scheduled task changed since backup.' }
  $taskSid = ([Security.Principal.NTAccount]::new([string]$task.Principal.UserId)).Translate([Security.Principal.SecurityIdentifier]).Value
  if ($task.Principal.UserId -ine 'conbr' -or $taskSid -cne ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value) -or
      [string]$task.Principal.LogonType -cne 'Interactive' -or [string]$task.Settings.ExecutionTimeLimit -cne 'PT0S' -or @($task.Actions).Count -ne 4) { throw 'Task identity/settings do not match this rollout.' }
  foreach ($index in 0..3) {
    $action = $task.Actions[$index]
    $scriptName = if ($index -eq 0) { 'start-hub.ps1' } else { 'restart-hub-after-failure.ps1' }
    $id = if ($index -eq 0) { 'f28-primary-0' } else { "f28-recovery-$index" }
    $arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $ProjectRoot "scripts\$scriptName") + '" -DataRoot "' + $DataRoot + '" -ActionIndex ' + $index
    if ($index -gt 0) { $arguments += ' -DelaySeconds 60' }
    if ([string]$action.Id -cne $id -or [string]$action.WorkingDirectory -ine $ProjectRoot -or [string]$action.Arguments -cne $arguments -or
        [string]$action.Execute -ine (Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe')) { throw "Scheduled task action $index changed." }
  }
}
function Get-ReleaseListeners {
  return @(Get-NetTCPConnection -ErrorAction Stop | Where-Object { $_.State -eq 'Listen' -and $_.LocalPort -eq 8765 })
}
function Assert-Ready {
  param([string]$Commit, [string]$Tree, [switch]$Idle, [switch]$AllowStoppedTask)
  $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8765/health/ready' -TimeoutSec 3
  $listeners = @(Get-ReleaseListeners)
  if ($listeners.Count -ne 1 -or [string]$listeners[0].LocalAddress -cne '127.0.0.1') { throw 'Expected one loopback listener.' }
  $process = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $listeners[0].OwningProcess)
  $owner = Invoke-CimMethod -InputObject $process -MethodName GetOwner
  if ($owner.ReturnValue -ne 0 -or $owner.User -ine 'conbr' -or [string]$process.CommandLine -notmatch '(?:^|\s)-m\s+oms_hub\.cli\s+serve(?:\s|$)') { throw 'Listener owner or command differs.' }
  if ($health.status -cne 'ok' -or $health.database_reachable -isnot [bool] -or -not $health.database_reachable -or
      $health.deployment_root -cne $ProjectRoot -or $health.build_revision -cne $Commit -or $health.build_tree -cne $Tree -or $health.schema_version -ne 42 -or
      (@($health.workers.PSObject.Properties.Name | Sort-Object) -join '|') -cne 'generation_worker|ingestion_worker|studio_worker') { throw 'Ready health identity/schema differs.' }
  foreach ($worker in $health.workers.PSObject.Properties.Value) {
    if ($worker.alive -isnot [bool] -or -not $worker.alive -or $worker.start_count -ne 1 -or ($Idle -and $null -ne $worker.active_work_age_seconds)) { throw 'Workers are not in the expected ready state.' }
  }
  if (-not $AllowStoppedTask -and (Get-ScheduledTask -TaskName $TaskName).State -ne 'Running') { throw 'Scheduled task is not running.' }
  return $health
}
function Wait-Clear {
  $deadline = [datetime]::UtcNow.AddSeconds(20)
  $clearCount = 0
  do {
    if (@(Get-ReleaseListeners).Count -eq 0 -and @(Get-ConflictingHubProcesses -ExpectedProjectRoot $ProjectRoot).Count -eq 0 -and (Get-ScheduledTask -TaskName $TaskName).State -ne 'Running') { $clearCount++ } else { $clearCount = 0 }
    if ($clearCount -ge 2) { return }
    Start-Sleep -Milliseconds 500
  } while ([datetime]::UtcNow -lt $deadline)
  throw 'Scheduled task and guarded process cleanup did not clear the runtime.'
}
function Wait-Ready {
  param([string]$Commit, [string]$Tree)
  $deadline = [datetime]::UtcNow.AddSeconds(45)
  do {
    try { return (Assert-Ready $Commit $Tree) } catch { $lastFailure = $_.Exception.Message }
    Start-Sleep -Seconds 1
  } while ([datetime]::UtcNow -lt $deadline)
  throw "Ready check timed out: $lastFailure"
}

try {
  Set-Location $ProjectRoot
  $validation = Get-Content 'C:\Users\conbr\AppData\Local\Temp\oms-win-worker-validation.json' -Raw | ConvertFrom-Json
  if ($validation.exit_code -ne 0 -or $validation.revision -cne $TargetCommit) { throw 'Native validation result differs.' }
  $validationLog = 'C:\Users\conbr\AppData\Local\Temp\oms-win-20260915a\regression-fixed.log'
  if ((Get-Content $validationLog -Raw) -notmatch '290 passed') { throw 'Native quiz regression acceptance missing.' }
  foreach ($changed in @(Invoke-ReleaseGit @('diff','--name-only',$OldCommit,$TargetCommit,'--','src'))) {
    if ($changed -cnotin @('src/oms_hub/llm/codex_session.py','src/oms_hub/llm/windows_lpac.py')) { throw "Unexpected production change: $changed" }
  }
  if (@(Invoke-ReleaseGit @('diff','--name-only',$OldCommit,$TargetCommit,'--','pyproject.toml','scripts','src/oms_hub/migrations.py','src/oms_hub/models.py')).Count -ne 0) { throw 'Target changes deployment dependencies or schema.' }
  $actualSource = Get-Content 'C:\Users\conbr\AppData\Local\Temp\oms-quiz-assets-acceptance.log' -Raw | ConvertFrom-Json
  if ($actualSource.status -cne 'passed' -or $actualSource.lecture_id -ne 110 -or -not $actualSource.manifest_roundtrip) { throw 'Actual lecture source acceptance missing.' }
  $matrix = Get-Content 'C:\Users\conbr\AppData\Local\Temp\oms-matrix-fixture-result.json' -Raw | ConvertFrom-Json
  $interrupt = Get-Content 'C:\Users\conbr\AppData\Local\Temp\oms-interrupt-fixture-result.json' -Raw | ConvertFrom-Json
  $nativeMatrix = Get-Content 'C:\Users\conbr\AppData\Local\Temp\oms-win-20260915a\matrix-final.log' -Raw | ConvertFrom-Json
  $nativeInterrupt = Get-Content 'C:\Users\conbr\AppData\Local\Temp\oms-win-20260915a\interrupt-closed.log' -Raw | ConvertFrom-Json
  if (-not $matrix.passed -or $matrix.requests -ne 2 -or @($matrix.errors).Count -ne 0 -or -not $nativeMatrix.passed -or -not $nativeMatrix.token_verified -or $nativeMatrix.exit_code -ne 0) { throw 'Final native tool matrix missing.' }
  if (-not $interrupt.passed -or $interrupt.requests -ne 1 -or @($interrupt.errors).Count -ne 0 -or -not $interrupt.headers_sent_body_withheld -or -not $interrupt.client_disconnected -or -not $nativeInterrupt.passed -or -not $nativeInterrupt.token_verified -or $nativeInterrupt.exit_code -ne 0 -or $nativeInterrupt.interrupt_sent_epoch -le $interrupt.request_received_utc) { throw 'Final controlled interrupt or fixture cleanup failed.' }
  $provider = Get-Content 'C:\Users\conbr\AppData\Local\Temp\oms-win-20260915a\provider-final-report.json' -Raw | ConvertFrom-Json
  if (-not $provider.passed -or -not $provider.account_persisted -or -not $provider.source_auth_unchanged -or $provider.candidate_auth_changed -or $provider.model -cne 'gpt-5.5') { throw 'Native subscription acceptance missing.' }
  foreach ($process in $provider.processes) { if (-not $process.token_verified -or -not $process.handles_closed -or -not $process.profile_removed) { throw 'Native cleanup acceptance missing.' } }
  if ((Get-FileHash $RuntimeSource -Algorithm SHA256).Hash -ine $RuntimeHash) { throw 'Runtime source hash mismatch.' }
  if (Test-Path $RuntimeRoot) {
    $runtimeFiles = @(Get-ChildItem -LiteralPath $RuntimeRoot -Force)
    if ($runtimeFiles.Count -ne 1 -or $runtimeFiles[0].FullName -ine $RuntimeTarget -or $runtimeFiles[0].PSIsContainer -or ($runtimeFiles[0].Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Unexpected existing runtime staging contents.' }
  } else {
    New-Item -ItemType Directory -Path $RuntimeRoot | Out-Null
    Copy-Item -LiteralPath $RuntimeSource -Destination $RuntimeTarget
  }
  if ((Get-FileHash $RuntimeTarget -Algorithm SHA256).Hash -ine $RuntimeHash) { throw 'Staged runtime hash mismatch.' }
  Assert-Source $OldCommit $OldTree
  if ($TargetCommit -ceq $OldCommit -or (Invoke-ReleaseGit @('rev-parse',"${TargetCommit}^{tree}")) -cne $TargetTree) { throw 'Target identity is invalid.' }
  Invoke-ReleaseGit @('merge-base','--is-ancestor',$OldCommit,$TargetCommit) | Out-Null
  foreach ($path in @(Invoke-ReleaseGit @('diff','--name-only',$OldCommit,$TargetCommit))) {
    if (@(Invoke-ReleaseGit @('ls-files','--others','--exclude-standard','--',$path)).Count -ne 0 -or
        @(Invoke-ReleaseGit @('ls-files','--others','--ignored','--exclude-standard','--',$path)).Count -ne 0) { throw "Untracked or ignored target path collision: $path" }
  }
  # Import only the existing discovery and guarded stop helpers, never installer body.
  $tokens = $null; $parseErrors = $null
  $ast = [Management.Automation.Language.Parser]::ParseFile((Join-Path $ProjectRoot 'scripts\install-windows.ps1'), [ref]$tokens, [ref]$parseErrors)
  if ($parseErrors.Count -ne 0) { throw 'Installed process helper script does not parse.' }
  foreach ($name in @('Test-ProcessPathUnderRoot','Get-ConflictingHubProcesses','Stop-ConflictingHubProcesses')) {
    $definitions = @($ast.FindAll({ param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq $name }, $false))
    if ($definitions.Count -ne 1) { throw "Trusted process helper missing: $name" }
    $definition = $definitions[0].Extent.Text
    Invoke-Expression $definition
  }
  New-Item -ItemType Directory -Path $BackupRoot -ErrorAction Stop | Out-Null
  [IO.File]::WriteAllText((Join-Path $BackupRoot 'task.xml'), (Export-ScheduledTask -TaskName $TaskName), $Utf8)
  Copy-Item -LiteralPath (Join-Path $ProjectRoot '.env') -Destination (Join-Path $BackupRoot '.env')
  Set-Acl -LiteralPath (Join-Path $BackupRoot '.env') -AclObject (Get-Acl -LiteralPath (Join-Path $ProjectRoot '.env'))
  $databaseBackup = Join-Path $BackupRoot 'hub.db' 
  $backupResult = & $Python (Join-Path $ProjectRoot 'scripts\backup-sqlite.py') --source (Join-Path $DataRoot 'hub.db') --destination $databaseBackup
  if ($LASTEXITCODE -ne 0) { throw 'Online database backup failed.' }
  [IO.File]::WriteAllText((Join-Path $BackupRoot 'database-backup.json'), ($backupResult -join "`n"), $Utf8)
  $preflight = @{ old_commit=$OldCommit; old_tree=$OldTree; schema=42; env_sha256=$EnvHash; created_utc=[datetime]::UtcNow.ToString('o') }
  [IO.File]::WriteAllText((Join-Path $BackupRoot 'preflight.json'), ($preflight | ConvertTo-Json), $Utf8)
  Assert-TaskAndConfig
  Assert-Ready $OldCommit $OldTree -Idle -AllowStoppedTask | Out-Null
  Start-Sleep -Milliseconds 500
  Assert-Source $OldCommit $OldTree
  Assert-TaskAndConfig
  Assert-Ready $OldCommit $OldTree -Idle -AllowStoppedTask | Out-Null
  $extendlmRoot = Join-Path $DataRoot 'extendlm'
  if ((Test-Path $extendlmRoot) -and @(Get-ChildItem $extendlmRoot -Recurse -File | Where-Object { $_.Directory.Name -eq 'files' }).Count -ne 0) { throw 'ExtendLM has staged uploads. Finish or resume them before rollout.' }
  $hubPid = (Get-ReleaseListeners)[0].OwningProcess
  $ownedCodex = @(Get-CimInstance Win32_Process -Filter ("ParentProcessId=" + $hubPid) | Where-Object { $_.Name -ieq 'codex.exe' })
  if ($ownedCodex.Count -gt 1) { throw 'Unexpected number of legacy managed Codex children.' }
  foreach ($child in $ownedCodex) {
    if ((Get-FileHash -LiteralPath $child.ExecutablePath -Algorithm SHA256).Hash -ine 'd6eb90b7409dc22f407a9dfa44ec629a8a5a6bf3ca001493aef13dd85a75dbda') { throw 'Legacy managed child identity changed.' }
  }
  $StopTime = [datetime]::UtcNow
  $StopAttempted = $true
  Stop-ScheduledTask -TaskName $TaskName
  foreach ($child in $ownedCodex) {
    $remaining = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $child.ProcessId)
    if ($null -ne $remaining) {
      if ($remaining.CreationDate -ne $child.CreationDate -or $remaining.ExecutablePath -ine $child.ExecutablePath -or $remaining.ParentProcessId -ne $hubPid) { throw 'Legacy managed child PID identity drift.' }
      $ownedProcess = Get-Process -Id $child.ProcessId -ErrorAction SilentlyContinue
      if ($null -ne $ownedProcess) {
        try {
          [void]$ownedProcess.Handle
          $stillSame = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $child.ProcessId)
          if ($null -ne $stillSame -and ($stillSame.CreationDate -ne $child.CreationDate -or $stillSame.ExecutablePath -ine $child.ExecutablePath)) { throw 'Legacy child changed before stop.' }
          if (-not $ownedProcess.HasExited) { Stop-Process -InputObject $ownedProcess -ErrorAction Stop }
          if (-not $ownedProcess.WaitForExit(10000)) { throw 'Legacy managed child did not exit.' }
        } finally { $ownedProcess.Dispose() }
      }
    }
  }
  Stop-ConflictingHubProcesses -ExpectedProjectRoot $ProjectRoot
  Wait-Clear
  Assert-Source $OldCommit $OldTree
  Assert-TaskAndConfig
  $StateAttempted = $true
  & $Python $StateScript archive $StateArchive
  if ($LASTEXITCODE -ne 0) { throw 'Managed state archive failed.' }
  $StateArchived = $true
  Invoke-ReleaseGit @('merge','--ff-only','--no-edit',$TargetCommit) | Out-Null
  Assert-Source $TargetCommit $TargetTree
  $envPath = Join-Path $ProjectRoot '.env'
  $envText = [IO.File]::ReadAllText($envPath)
  foreach ($key in @('OMS_HUB_CODEX_EXECUTABLE','OMS_HUB_CODEX_BINARY_SHA256')) { if ([regex]::Matches($envText, ('(?m)^'+$key+'=')).Count -ne 1) { throw 'Expected exactly one runtime setting.' } }
  $envText = [regex]::Replace($envText, '(?m)^OMS_HUB_CODEX_EXECUTABLE=[^\r\n]*', ('OMS_HUB_CODEX_EXECUTABLE=' + "'" + $RuntimeTarget + "'"))
  $envText = [regex]::Replace($envText, '(?m)^OMS_HUB_CODEX_BINARY_SHA256=[^\r\n]*', ('OMS_HUB_CODEX_BINARY_SHA256=' + $RuntimeHash))
  $envTemporary = $envPath + '.worker-' + [guid]::NewGuid().ToString('N')
  [IO.File]::WriteAllText($envTemporary, $envText, $Utf8)
  $newEnvHash = (Get-FileHash $envTemporary -Algorithm SHA256).Hash
  [IO.File]::Replace($envTemporary, $envPath, (Join-Path $BackupRoot '.env-replaced'))
  $EnvChanged = $true
  $EnvHash = $newEnvHash
  Assert-TaskAndConfig
  Start-ScheduledTask -TaskName $TaskName
  $Result.health = Wait-Ready $TargetCommit $TargetTree
  $Result.downtime_seconds = [math]::Round(([datetime]::UtcNow - $StopTime).TotalSeconds, 3)
  Assert-TaskAndConfig
  $Result.status = 'deployed'
} catch {
  $Result.error = $_.Exception.Message
  if ($StopAttempted) {
    try {
      Assert-TaskAndConfig
      $current = [string](Invoke-ReleaseGit @('rev-parse','HEAD'))
      if ($current -ceq $TargetCommit) { Assert-Source $TargetCommit $TargetTree }
      elseif ($current -ceq $OldCommit) { Assert-Source $OldCommit $OldTree }
      else { throw 'Unexpected checkout; automatic rollback withheld.' }
      Stop-ScheduledTask -TaskName $TaskName
      Stop-ConflictingHubProcesses -ExpectedProjectRoot $ProjectRoot
      Wait-Clear
      if ($StateArchived) {
        & $Python $StateScript restore $StateArchive
        if ($LASTEXITCODE -ne 0) { throw 'Managed state restore failed.' }
      } elseif ($StateAttempted) {
        & $Python $StateScript verify_original $StateArchive
        if ($LASTEXITCODE -ne 0) { throw 'Original runtime state could not be verified; Hub remains stopped.' }
      }
      if ($current -ceq $TargetCommit) { Invoke-ReleaseGit @('reset','--keep',$OldCommit) | Out-Null }
      Assert-Source $OldCommit $OldTree
      if ($EnvChanged) {
        Copy-Item -LiteralPath (Join-Path $BackupRoot '.env') -Destination (Join-Path $ProjectRoot '.env') -Force
        $EnvHash = $OriginalEnvHash
        $EnvChanged = $false
      }
      Assert-TaskAndConfig
      Start-ScheduledTask -TaskName $TaskName
      $Result.health = Wait-Ready $OldCommit $OldTree
      $Result.status = 'rolled_back'
      $Result.rollback = 'Old source and scheduled task restored; live database preserved.'
    } catch {
      $Result.status = 'recovery_required'
      $Result.rollback = $_.Exception.Message
    }
  }
}
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null
$Result.completed_utc = [datetime]::UtcNow.ToString('o')
$json = $Result | ConvertTo-Json -Depth 8
[IO.File]::WriteAllText("$Receipt.tmp", $json + "`n", $Utf8)
Move-Item -LiteralPath "$Receipt.tmp" -Destination $Receipt
Write-Output $json
if ($Result.status -ne 'deployed') { exit 1 }
