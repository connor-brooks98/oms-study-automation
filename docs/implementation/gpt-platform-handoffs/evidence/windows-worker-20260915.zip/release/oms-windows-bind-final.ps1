$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$p='C:\Users\conbr\AppData\Local\Temp\oms-win-20260915a'
$expected=Get-Content C:\Users\conbr\AppData\Local\Temp\oms-windows-final-source-hashes.json -Raw | ConvertFrom-Json
foreach($item in $expected.PSObject.Properties){if((Get-FileHash (Join-Path $p $item.Name) -Algorithm SHA256).Hash -ine $item.Value){throw ('Candidate source drift: '+$item.Name)}}
$r=Get-Content "$p\timeout-fixed-result.json" -Raw | ConvertFrom-Json
if($r.exit_code -ne 0 -or (Get-Content "$p\timeout-fixed.log" -Raw) -notmatch '83 passed'){throw 'Regression not accepted'}
@{revision='3480372bf885d9541b3259a2bb9dc7007b19a4ff';exit_code=0;source_sha256=$expected;native_log_sha256=(Get-FileHash "$p\timeout-fixed.log" -Algorithm SHA256).Hash} | ConvertTo-Json -Depth 5 | Set-Content C:\Users\conbr\AppData\Local\Temp\oms-win-final-validation.json
$queue=Get-Content "$p\queue-fixed-result.json" -Raw | ConvertFrom-Json
if($queue.exit_code -ne 0 -or (Get-Content "$p\queue-fixed.log" -Raw) -notmatch '97 passed'){throw 'Queue regression not accepted'}
$tokens=$null;$errors=$null
[void][Management.Automation.Language.Parser]::ParseFile('C:\Users\conbr\AppData\Local\Temp\oms-windows-deploy-final.ps1',[ref]$tokens,[ref]$errors)
if($errors.Count -ne 0){throw 'Deploy script parse failure'}
'validated'
