"""Archive incompatible managed runtime state; preserve login and restore on rollout failure."""
from pathlib import Path
import hashlib,json,sqlite3,sys
from contextlib import closing
home=Path('C:/ProgramData/OMSStudyHub-V2/codex-session')
archive=Path(sys.argv[2]).resolve()
assert archive.is_relative_to(Path('C:/ProgramData/OMSStudyHub-V2/backups'))
names=('state_5.sqlite','logs_2.sqlite','goals_1.sqlite','memories_1.sqlite','queue_1.sqlite')
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def files(root):
 return [root/(name+suffix) for name in names for suffix in ('','-wal','-shm') if (root/(name+suffix)).exists()]
if sys.argv[1]=='archive':
 assert not archive.exists()
 for path in files(home):assert path.resolve()==path and path.is_file() and not path.is_symlink()
 for name in names:
  with closing(sqlite3.connect((home/name).as_uri()+'?mode=ro',uri=True)) as db:
   assert db.execute('PRAGMA integrity_check').fetchone()==('ok',)
   if name=='state_5.sqlite':assert db.execute('SELECT count(*) FROM threads').fetchone()==(0,)
 archive.mkdir(mode=0o700)
 manifest={'status':'prepared','auth_sha256':digest(home/'auth.json'),'files':{p.name:digest(p) for p in files(home)},'moved':[]}
 def save(): (archive/'manifest.json').write_text(json.dumps(manifest,indent=2))
 save()
 try:
  for name, expected in manifest['files'].items():
   assert digest(home/name)==expected
   (home/name).replace(archive/name);manifest['moved'].append(name);save()
  assert digest(home/'auth.json')==manifest['auth_sha256']
  manifest['status']='archived';save()
 except BaseException:
  for name in reversed(manifest['moved']): (archive/name).replace(home/name)
  manifest['status']='rolled_back';save();raise
 print(json.dumps({'status':manifest['status'],'files':len(manifest['moved']),'auth_unchanged':True,'prior_thread_count':0}))
elif sys.argv[1]=='verify_original':
 manifest=json.loads((archive/'manifest.json').read_text())
 for name,expected in manifest['files'].items():assert digest(home/name)==expected
 assert digest(home/'auth.json')==manifest['auth_sha256']
 print(json.dumps({'status':'original_verified'}))
elif sys.argv[1]=='restore':
 manifest=json.loads((archive/'manifest.json').read_text())
 assert manifest['status']=='archived'
 for name,expected in manifest['files'].items():assert digest(archive/name)==expected
 failed=archive/'replacement-state';failed.mkdir(mode=0o700)
 for path in files(home):path.replace(failed/path.name)
 for name in manifest['files']:(archive/name).replace(home/name)
 manifest['status']='restored';(archive/'manifest.json').write_text(json.dumps(manifest,indent=2))
 print(json.dumps({'status':'restored','original_files_verified':True}))
else:raise ValueError('Unsupported action')
