# Windows managed worker evidence, 2026-09-15

Final live code: 3480372bf885d9541b3259a2bb9dc7007b19a4ff.
Runtime SHA256: d6eb90b7409dc22f407a9dfa44ec629a8a5a6bf3ca001493aef13dd85a75dbda.

- native: initial native 287-pass suite, synthetic subscription proof, complete four-capability tool matrix and controlled interrupt; earlier failed diagnostics kept separately by filename.
- native-fixed: 290-pass native suite after protected-directory/shutdown fixes, actual-home diagnostics, queue/timeout follow-up checks, and live dispatch/observation summaries.
- fixtures/matrix and fixtures/interrupt: final accepted fixture-side evidence. Both provider response and fixture cleanup are required.
- fixtures/failed-interrupt: superseded fixture deadline failure; NOT acceptance. The corresponding native interrupt completed, which alone was insufficient.
- release: reviewed scripts, successful and rolled-back rollout receipts, local validation logs, source hashes, narrowly scoped ACL repair, state archive/restore helper.
- final-source: exact relevant committed implementation/test files.

Native transport changed only for protected private descendants and verified delayed exit after the original tool matrix. Native regression includes genuine production-created homes, SQLite WAL persistence across identities, file/descendant denial, and cleanup. App wiring and queue reuse received separate focused native regression.

The three synthetic-provider credential copies were removed after testing. Live auth remains in the protected managed home. This archive contains no credential homes, credentials, SQLite databases, runtime binaries, lecture files, or lecture output. Actual source/quiz content stays in the private Hub artifacts. Synthetic provider source is included for reproducibility; running it requires separately authorized credentials.

PowerShell-generated native logs may be UTF-16LE. The original retained files are preserved byte-for-byte. See the handoff document for the final real-lecture outcome and limits.
