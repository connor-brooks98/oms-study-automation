from pathlib import Path
import os,subprocess,shutil,json
from oms_hub.llm.windows_lpac import LpacProcess
root=Path(__file__).parent/'https-check';root.mkdir(exist_ok=False)
home,work=root/'home',root/'work';home.mkdir();work.mkdir()
exe=root/'curl.exe';shutil.copy2(Path(os.environ['SystemRoot'])/'System32'/'curl.exe',exe)
args=[str(exe),'--connect-timeout','5','--max-time','10','-I','https://chatgpt.com']
control=subprocess.run(args,capture_output=True,timeout=15)
print(json.dumps({'ordinary_exit':control.returncode,'ordinary_stderr':control.stderr.decode('utf8','replace')}),flush=True)
env={k:v for k,v in os.environ.items() if k.upper() in {'SYSTEMROOT','WINDIR','LOCALAPPDATA'}}
env.update(TMP=str(home),TEMP=str(home))
p=LpacProcess(args,cwd=work,env=env,session_home=home,shutdown_timeout=2)
try:
 p.stdin.close();p.wait(timeout=15)
 print(json.dumps({'lpac_exit':p.returncode,'lpac_stderr':p.stderr.read().decode('utf8','replace'),'stdout':p.stdout.read().decode('utf8','replace')[:1000]}),flush=True)
finally:p.close()
