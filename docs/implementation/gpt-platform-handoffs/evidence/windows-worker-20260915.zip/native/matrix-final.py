from pathlib import Path
import os,json,time,hashlib
from oms_hub.llm import codex_session as session, windows_lpac as lpac
from oms_hub.llm.codex_policy import policy_args
root=Path(__file__).parent
home,work=root/'matrix-final'/'home',root/'matrix-final'/'work'
home.mkdir(parents=True,exist_ok=False);work.mkdir()
runtime=root/'runtime'/'codex.exe'
assert hashlib.file_digest(runtime.open('rb'),'sha256').hexdigest()==session.ACCEPTED_WINDOWS_BINARY_SHA256
# Auth-free LAN fixture only. Production retains internetClient instead of privateNetworkClientServer.
# Use the exact production capabilities.
config='''model_provider="policy_fixture"
[model_providers.policy_fixture]
name="Synthetic LAN fixture"
base_url="http://100.107.65.56:53428/windows-worker-20260915/v1"
wire_api="responses"
requires_openai_auth=false
supports_websockets=false
request_max_retries=0
stream_max_retries=0
'''
(home/'config.toml').write_text(config)
args=policy_args();args[args.index('model_provider="openai"')]='model_provider="policy_fixture"'
env={k:v for k,v in os.environ.items() if k.upper() in {'SYSTEMROOT','WINDIR'}}
env.update(CODEX_HOME=str(home),HOME=str(home),USERPROFILE=str(home),APPDATA=str(home),LOCALAPPDATA=os.environ['LOCALAPPDATA'],TMP=str(home),TEMP=str(home))
client=session.CodexSessionClient(runtime,home,work)
wire=session._Stdio([str(runtime),'app-server','--listen','stdio://',*args],cwd=work,env=env,shutdown_timeout=3)
client._wire=wire
end=time.monotonic()+45
try:
 init=client._rpc('initialize',{'clientInfo':{'name':'oms-study-hub','version':'1'},'capabilities':{'experimentalApi':True}},end,lambda:False)
 assert init['codexHome']==lpac.canonical_path(home)
 wire.send({'method':'initialized'},end,lambda:False)
 params={'model':'gpt-5.5','modelProvider':'policy_fixture','allowProviderModelFallback':False,'dynamicTools':[],'environments':[],'selectedCapabilityRoots':[],'runtimeWorkspaceRoots':[],'cwd':str(work),'ephemeral':True,'approvalPolicy':'untrusted','approvalsReviewer':'user','sandbox':'read-only'}
 thread=client._rpc('thread/start',params,end,lambda:False)
 assert thread['model']=='gpt-5.5' and thread['sandbox']=={'type':'readOnly','networkAccess':False}
 tid=thread['thread']['id']
 turn=client._rpc('turn/start',{'threadId':tid,'model':'gpt-5.5','input':[{'type':'text','text':'Synthetic policy fixture. Never execute tools.'}]},end,lambda:False)
 turnid=turn['turn']['id']
 while not any(session._is_completed(e,tid,turnid) for e in client._events):client._receive(end,lambda:False)
 assert session.collect_completed_text(client._events,thread_id=tid,turn_id=turnid)=='fixture complete'
 wire.process.stdin.close();wire.process.wait(timeout=5)
 print(json.dumps({'passed':True,'token_verified':wire.process.token_verified,'exit_code':wire.process.poll(),'thread_id':tid,'turn_id':turnid}),flush=True)
finally:
 (root/'matrix-final-events.json').write_text(json.dumps(client._events))
 (root/'matrix-final-stderr.txt').write_bytes(wire.stderr_tail)
 client.close()
