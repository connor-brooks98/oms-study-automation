from pathlib import Path
import os,shutil,json
from oms_hub.llm.windows_lpac import LpacProcess
root=Path('C:/ProgramData/OMSStudyHub-V2'); temp=Path(__file__).parent
exe=temp/'runtime/cmd.exe'
if not exe.exists():shutil.copy2(Path(os.environ['SystemRoot'])/'System32/cmd.exe',exe)
home=root/'codex-session';work=root/'codex-work/connection'
cmd='type "'+str(home/'auth.json')+'" >nul & echo AUTH=!errorlevel! & type "'+str(home/'state_5.sqlite')+'" >nul & echo STATE_READ=!errorlevel! & echo CHECK>"'+str(home/'native-acl-probe.txt')+'" & echo HOME_WRITE=!errorlevel! & echo CHECK>"'+str(home/'host-home/tmp/native-acl-probe.txt')+'" & echo TEMP_WRITE=!errorlevel!'
cmd=cmd.replace(chr(34),'')
p=LpacProcess([str(exe),'/d','/v:on','/s','/c',cmd],cwd=work,env={k:os.environ[k] for k in ("SystemRoot","WINDIR","LOCALAPPDATA")},session_home=home,shutdown_timeout=3)
try:
 p.stdin.close();p.wait(timeout=15)
 print(json.dumps({'stdout':p.stdout.read().decode('utf8','replace'),'stderr':p.stderr.read().decode('utf8','replace'),'exit':p.returncode,'home_written':(home/'native-acl-probe.txt').exists(),'temp_written':(home/'host-home/tmp/native-acl-probe.txt').exists()}),flush=True)
finally:
 p.close()
 for f in (home/'native-acl-probe.txt',home/'host-home/tmp/native-acl-probe.txt'):f.unlink(missing_ok=True)
