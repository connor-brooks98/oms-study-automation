from pathlib import Path
from dataclasses import asdict
import json,time,traceback
from oms_hub.llm import codex_session as session
root=Path('C:/ProgramData/OMSStudyHub-V2'); wires=[];base=session._Stdio
class Capture(base):
 def __init__(self,*a,**kw):super().__init__(*a,**kw);wires.append(self)
session._Stdio=Capture
client=session.CodexSessionClient(root/'runtimes/codex-d6eb90b7409d/codex.exe',root/'codex-session',root/'codex-work')
try:
 print(json.dumps(asdict(client.status())),flush=True)
except Exception:traceback.print_exc()
finally:
 time.sleep(1)
 for w in wires:
  print(json.dumps({'pid':w.process.pid,'exit':w.process.poll(),'stderr':w.stderr_tail.decode('utf8','replace'),'handles_closed':w.process._process is None,'profile_removed':w.process._profile is None}),flush=True)
 try:client.close()
 except Exception:traceback.print_exc()
