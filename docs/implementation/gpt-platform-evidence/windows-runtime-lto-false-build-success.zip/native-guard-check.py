import runpy,json,hashlib
from pathlib import Path
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/codex-build-nolto3-20260913-guard.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='fa79fbe1af0d74fba30ccab110b681a1cde417b3159873399b93cb7221f0f177'
g=runpy.run_path(str(p))
print(json.dumps(g["health"]("preflight"),indent=2))
