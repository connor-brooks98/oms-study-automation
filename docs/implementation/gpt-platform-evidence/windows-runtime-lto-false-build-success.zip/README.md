Prepared-only second no-LTO continuation: no staging or launch.

The nolto2 build ended in its known normal90-minute timeout124/timed_out=true with clean query/cleanup, disabled task, zero owned processes, exact Hub preservation and no executable. Three actual terminal pins and six local proof hashes are now bound. Final bound independent review is required before staging/launch; the earlier unbound static preparation is retained in prepared-unbound/.

This is the existing reviewed driver with only fresh nolto3 task/once/log/guard identities. Environment is byte-identical: same source/tool/std/arg0/lock/V8 pins, CARGO_PROFILE_RELEASE_LTO=false, -j1, short c2 cache and codex-no-lto-20260913 target. All prior receipts and targets remain retained. No source/profile/security change, provider/runtime execution or deadline extension.

The 90-minute job, 92-minute Limited no-trigger task, BelowNormal priority, 9.5GiB cap, 11.5/13.5GiB preflight commit/physical thresholds, 2/4GiB ongoing emergency floors at nominal5s cadence, 30s Hub guard and unconditional owned cleanup are unchanged. Review normalized-delta.diff and prepared-hashes.json. Fresh policy/Hub/ownership/disk/native reserve preflight is required after final bound review and before any authorized one-shot continuation.
