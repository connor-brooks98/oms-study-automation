Private Windows Codex build succeeded on 2026-09-13. This is build acceptance only; the executable was copied for preservation and was not executed.

Cargo completed in 70m22s under the unchanged serial, 9.5 GiB, 90-minute owned-job controls. The release profile retains opt3, codegen-units4 and line-tables debuginfo; CARGO_PROFILE_RELEASE_LTO=false disables cross-crate LTO. The prior reviewed unit graphs establish that only the intended LTO fields changed.

Exact executable: 74d7706f403336b693853eb8582e0424d9f765ac6c2d98e408206bf03e5ecf4f; 293978624 bytes. The local build-output/codex.exe hash equals the native final build receipt. Source, patched Rust std, arg0 patch, lock normalization, toolchain and V8 pins remain in the prepared pins and retained invocation/environment.

All 144 Hub and 986 memory checks passed. Independent reconciliation at 2026-09-13T21:22:58.6803676Z confirms task Disabled, no owned processes, sole Hub listener8268 and unchanged build/tree/schema/workers. Peak job memory 9299189760 bytes remained below the 10200547328 byte cap. No compiler errors; retained upstream warnings are unchanged.

All prior failed/timed-out runs remain retained separately. Native version/initialize and arg0 test acceptance are separate subsequent gates. Do not classify this custom executable as the official release binary.
