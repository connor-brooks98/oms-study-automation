$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-f4eb50a9ed74';$files=@{
  'probe-windows-lpac.ps1'='e04780505e9e8ad42b7eb52792cfd89b9b3fac09653719f9977f8516154fe4d1'
  'probe-interactive.ps1'='e23a2cd6e70c22fec38b6c5e2e30bbfce1de3a3b0a6a5d2e8e69be38b1a3f833'
  'run-lpac-task.ps1'='a6b9e629dcef7f723dc41c319d60bbac26421607915886c8378e4200d49fae87'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
