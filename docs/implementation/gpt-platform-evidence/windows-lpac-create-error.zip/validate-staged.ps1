$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-ea733eb9d915';$files=@{
  'probe-windows-lpac.ps1'='38593c8f5a6f924d5c3707387598c793205aed3cf6fdc2ea1b8af8de0826eb53'
  'probe-interactive.ps1'='3943d99c3f6de4a5caf7ea57bee7b1949febe56f93daaedb5b1d6977719e1657'
  'run-lpac-task.ps1'='ffd57d3159e694d31c7e9065f1270866758d9a99d407aee34a7e8d5956a315ca'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
