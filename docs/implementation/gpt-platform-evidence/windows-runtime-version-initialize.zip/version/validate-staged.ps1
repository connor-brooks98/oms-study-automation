if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-4bb857a5676f';$files=@{
  'probe-windows-lpac.ps1'='fa6e51c95512bb81fef0a9b2de136028bb52b86b23f702586e998dfd8059ee48'
  'probe-interactive.ps1'='d27cab2d875321f247d54c31e413ad51e87839e70fb20a3e895fc8b8096c3762'
  'run-lpac-task.ps1'='303e15b2f1322625a32fd3f4b8a73463ee110747ac0b98b70196675fa1d581c6'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
