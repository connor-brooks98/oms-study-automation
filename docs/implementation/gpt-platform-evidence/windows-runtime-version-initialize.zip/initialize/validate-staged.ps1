if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-ba76f642be8d';$files=@{
  'probe-windows-lpac.ps1'='fa6e51c95512bb81fef0a9b2de136028bb52b86b23f702586e998dfd8059ee48'
  'probe-interactive.ps1'='5eeb8cf31fc88e2bf5d25f6afae720fd50ee4849f0eed985705180a4b8fdd5bc'
  'run-lpac-task.ps1'='dda10df2db1adb7c538ef465b3eac2b12a3ce9687343fc80fe71f81fb0e3a65f'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
