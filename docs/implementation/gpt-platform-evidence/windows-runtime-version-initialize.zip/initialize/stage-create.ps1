if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$p='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-ba76f642be8d';if(Test-Path -LiteralPath $p){throw 'stage exists; no retry'};$null=New-Item -ItemType Directory -Path $p
