# Network-free, one-child Windows LPAC acceptance probe. Retains every new fixture/profile.
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$FixtureParent,
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^oms-lpac-[0-9a-f]{32}$')][string]$ProfileName,
    [switch]$CodexVersion,
    [switch]$CodexInitialize
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
if ($CodexVersion -and $CodexInitialize) { throw 'Choose only one fixed Codex mode.' }
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or -not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -ne 'Desktop') {
    throw 'Run only in an existing 64-bit Windows PowerShell process.'
}
# Refuse reused paths and junction/symlink ancestors before creating any fixture.
$parent = [IO.Path]::GetFullPath($FixtureParent)
if ($parent -notmatch '^[A-Za-z]:\\' -or -not [IO.Directory]::Exists($parent)) { throw 'FixtureParent must be an existing local directory.' }
$ancestor = [IO.DirectoryInfo]$parent
while ($null -ne $ancestor) {
    if (($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Reparse-point ancestors are forbidden.' }
    $ancestor = $ancestor.Parent
}
$fixture = Join-Path $parent $ProfileName
if (Test-Path -LiteralPath $fixture) { throw 'Fixture already exists; use a new profile name. No retry.' }
$null = New-Item -ItemType Directory -Path $fixture
$owner = [Security.Principal.WindowsIdentity]::GetCurrent().User
$privateAcl = [Security.AccessControl.DirectorySecurity]::new()
$privateAcl.SetAccessRuleProtection($true, $false)
$privateAcl.SetOwner($owner)
$privateAcl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new(
    $owner, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow'))
Set-Acl -LiteralPath $fixture -AclObject $privateAcl
$compilerTemp = Join-Path $fixture 'compiler'
$null = New-Item -ItemType Directory -Path $compilerTemp
$savedTemp = $env:TEMP
$savedTmp = $env:TMP
$report = [ordered]@{ status = 'failed'; fixture = $fixture; profile_name = $ProfileName; native_result = $null; error = $null }
try {
    # Add-Type's temporary compiler files belong to this fixture too.
    $env:TEMP = $compilerTemp
    $env:TMP = $compilerTemp
    $jsonAssembly = [Reflection.Assembly]::Load('System.Web.Extensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35')
    Add-Type -ReferencedAssemblies @('System.dll', 'System.Core.dll', $jsonAssembly.Location) -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Web.Script.Serialization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Security.Cryptography;
using System.Text;

public sealed class OmsLpacResult {
    public string Mode;
    public string ExecutableSha256;
    public string ExpectedCodexHome;
    public bool InitializeResponseObserved;
    public string Stage = "initial";
    public string Error;
    public int? NativeErrorCode;
    public string StartedUtc = DateTime.UtcNow.ToString("o");
    public string FinishedUtc;
    public string ProfileSid;
    public string ChildSid;
    public string CallerSid;
    public string Executable;
    public string CommandLine;
    public string ChildLocalAppData;
    public uint ProcessId;
    public int IsAppContainer;
    public bool CallerAccessCheckReturned, CallerAccessStatus;
    public uint CallerGrantedAccess;
    public bool ChildAccessCheckReturned, ChildAccessStatus;
    public uint ChildGrantedAccess;
    public int CapabilityCount;
    public string[] CapabilitySids;
    public uint[] CapabilityAttributes;
    public int SessionId;
    public bool ProfileCreated;
    public bool Resumed;
    public bool TimedOut;
    public bool KillAttempted;
    public bool Reaped;
    public uint? ExitCode;
    public bool Passed;
}

public static class OmsLpacProbe {
    const string CodexSource = @"C:\Users\conbr\AppData\Local\OMSStudyHub\acceptance\runtime-build-734bbdfad4a9\target\codex-no-lto-20260913\x86_64-pc-windows-msvc\release\codex.exe";
    const string CodexSha256 = "74d7706f403336b693853eb8582e0424d9f765ac6c2d98e408206bf03e5ecf4f";
    // Documented TOKEN_INFORMATION_CLASS values (winnt.h).
    const int TokenElevation = 20, TokenIsAppContainer = 29, TokenCapabilities = 30;
    const int TokenAppContainerSid = 31;
    // Microsoft's documented LPAC cmd.exe startup requirements, fixed to this synthetic probe.
    // https://raw.githubusercontent.com/microsoft/SandboxSecurityTools/f6263b76dbf77305969aa599ff8a66579aae5a54/LaunchAppContainer/README.md
    static readonly string[] CmdCapabilitySids = {
        "S-1-15-3-1024-2405443489-874036122-4286035555-1823921565-1746547431-2453885448-3625952902-991631256", // lpacCom
        "S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681" // registryRead
    };
    [StructLayout(LayoutKind.Sequential)] struct SidAndAttributes {
        public IntPtr Sid; public uint Attributes;
    }
    [StructLayout(LayoutKind.Sequential)] struct TokenGroupsHeader {
        public uint Count; public SidAndAttributes First;
    }
    const uint WAIT_TIMEOUT = 258, INFINITE_ERROR = 0xffffffff;
    [StructLayout(LayoutKind.Sequential)] struct SecurityAttributes {
        public int Length; public IntPtr Descriptor; public int Inherit;
    }
    [StructLayout(LayoutKind.Sequential)] struct SecurityCapabilities {
        public IntPtr Sid, Capabilities; public uint Count, Reserved;
    }
    [StructLayout(LayoutKind.Sequential)] struct GenericMapping {
        public uint Read, Write, Execute, All;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] struct StartupInfo {
        public int cb; public string Reserved, Desktop, Title;
        public uint X, Y, XSize, YSize, XCountChars, YCountChars, FillAttribute, Flags;
        public ushort ShowWindow, ReservedBytes; public IntPtr ReservedPointer;
        public IntPtr StdInput, StdOutput, StdError;
    }
    [StructLayout(LayoutKind.Sequential)] struct StartupInfoEx {
        public StartupInfo StartupInfo; public IntPtr AttributeList;
    }
    [StructLayout(LayoutKind.Sequential)] struct ProcessInformation {
        public IntPtr Process, Thread; public uint ProcessId, ThreadId;
    }
    [DllImport("userenv.dll", CharSet = CharSet.Unicode)] static extern int CreateAppContainerProfile(
        string name, string displayName, string description, IntPtr capabilities, uint count, out IntPtr sid);
    [DllImport("advapi32.dll")] static extern IntPtr FreeSid(IntPtr sid);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr process, uint access, out IntPtr token);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool GetTokenInformation(IntPtr token, int kind, IntPtr data, int length, out int needed);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool DuplicateTokenEx(
        IntPtr token, uint access, IntPtr attributes, int level, int type, out IntPtr duplicate);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool AccessCheck(
        IntPtr descriptor, IntPtr token, uint desired, ref GenericMapping mapping,
        IntPtr privileges, ref uint privilegeLength, out uint granted, out bool status);
    [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool CloseHandle(IntPtr handle);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool InitializeProcThreadAttributeList(IntPtr list, int count, uint flags, ref IntPtr size);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool UpdateProcThreadAttribute(IntPtr list, uint flags, IntPtr attribute, IntPtr value, IntPtr size, IntPtr previous, IntPtr returnedSize);
    [DllImport("kernel32.dll")] static extern void DeleteProcThreadAttributeList(IntPtr list);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] static extern bool CreateProcessW(
        string application, StringBuilder command, IntPtr processAttributes, IntPtr threadAttributes,
        bool inherit, uint flags, IntPtr environment, string cwd, ref StartupInfoEx startup, out ProcessInformation process);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] static extern IntPtr CreateFileW(
        string path, uint access, uint share, ref SecurityAttributes security, uint disposition, uint flags, IntPtr template);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool CreatePipe(
        out IntPtr read, out IntPtr write, IntPtr security, uint size);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool SetHandleInformation(IntPtr handle, uint mask, uint flags);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool WriteFile(
        IntPtr handle, byte[] bytes, uint count, out uint written, IntPtr overlapped);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] static extern uint GetFinalPathNameByHandleW(
        IntPtr handle, StringBuilder path, uint capacity, uint flags);
    [DllImport("kernel32.dll", SetLastError = true)] static extern uint ResumeThread(IntPtr thread);
    [DllImport("kernel32.dll", SetLastError = true)] static extern uint WaitForSingleObject(IntPtr handle, uint milliseconds);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool TerminateProcess(IntPtr process, uint code);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool GetExitCodeProcess(IntPtr process, out uint code);

    static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
    static void Win32(bool ok, int error, string operation) {
        if (!ok) throw new Win32Exception(error, operation + " failed with Win32 error " + error);
    }
    static IntPtr TokenData(IntPtr token, int kind, out int length) {
        length = 0;
        int needed;
        bool first = GetTokenInformation(token, kind, IntPtr.Zero, 0, out needed);
        int sizeError = Marshal.GetLastWin32Error();
        int minimum = kind == TokenAppContainerSid ? IntPtr.Size : 4;
        Require(!first && (sizeError == 24 || sizeError == 122) && needed >= minimum && needed <= 65536,
            "Token size query: kind=" + kind + ", return=" + first + ", error=" + sizeError + ", needed=" + needed);
        IntPtr data = Marshal.AllocHGlobal(needed);
        int capacity = needed;
        try {
            bool ok = GetTokenInformation(token, kind, data, capacity, out needed);
            int error = Marshal.GetLastWin32Error();
            Require(ok && needed >= minimum && needed <= capacity,
                "Token data query: kind=" + kind + ", return=" + ok + ", error=" + error + ", needed=" + needed);
            length = needed;
            return data;
        }
        catch { Marshal.FreeHGlobal(data); throw; }
    }
    static int TokenInt(IntPtr token, int kind) {
        // These information classes return a documented DWORD, not a variable TOKEN_GROUPS.
        IntPtr data = Marshal.AllocHGlobal(4);
        try {
            int needed;
            bool ok = GetTokenInformation(token, kind, data, 4, out needed);
            int error = Marshal.GetLastWin32Error();
            Require(ok && needed == 4,
                "Token DWORD query: kind=" + kind + ", return=" + ok + ", error=" + error + ", needed=" + needed);
            return Marshal.ReadInt32(data);
        } finally { Marshal.FreeHGlobal(data); }
    }
    static string TokenSid(IntPtr token) {
        int length;
        IntPtr data = TokenData(token, TokenAppContainerSid, out length);
        try {
            IntPtr sid = Marshal.ReadIntPtr(data);
            Require(sid != IntPtr.Zero, "Child has no AppContainer SID.");
            return new SecurityIdentifier(sid).Value;
        } finally { Marshal.FreeHGlobal(data); }
    }
    static void VerifyCmdCapabilities(IntPtr token, OmsLpacResult result) {
        int length;
        IntPtr data = TokenData(token, TokenCapabilities, out length);
        try {
            result.CapabilityCount = Marshal.ReadInt32(data);
            Require(result.CapabilityCount == CmdCapabilitySids.Length, "Unexpected capability count.");
            int first = Marshal.OffsetOf(typeof(TokenGroupsHeader), "First").ToInt32();
            int stride = Marshal.SizeOf(typeof(SidAndAttributes));
            Require(length >= first + stride * result.CapabilityCount, "Truncated capability array.");
            result.CapabilitySids = new string[result.CapabilityCount];
            result.CapabilityAttributes = new uint[result.CapabilityCount];
            bool[] seen = new bool[CmdCapabilitySids.Length];
            long start = data.ToInt64(), end = checked(start + length);
            for (int i = 0; i < result.CapabilityCount; i++) {
                SidAndAttributes entry = (SidAndAttributes)Marshal.PtrToStructure(
                    IntPtr.Add(data, first + stride * i), typeof(SidAndAttributes));
                long address = entry.Sid.ToInt64();
                Require(address >= start && address <= end - 8, "Capability SID outside returned buffer.");
                int sidLength = 8 + 4 * Marshal.ReadByte(entry.Sid, 1);
                Require(address <= end - sidLength, "Truncated capability SID.");
                string actual = new SecurityIdentifier(entry.Sid).Value;
                result.CapabilitySids[i] = actual;
                result.CapabilityAttributes[i] = entry.Attributes;
                int expected = Array.IndexOf(CmdCapabilitySids, actual);
                Require(expected >= 0 && !seen[expected] && entry.Attributes == 4,
                    "Unexpected, duplicate or non-enabled capability: " + actual + " attributes=" + entry.Attributes);
                seen[expected] = true;
            }
        } finally { Marshal.FreeHGlobal(data); }
    }
    static void DuplicateForAccessCheck(IntPtr token, out IntPtr duplicate) {
        // TOKEN_QUERY, SecurityIdentification, TokenImpersonation; never impersonate a thread.
        bool ok = DuplicateTokenEx(token, 8, IntPtr.Zero, 1, 2, out duplicate);
        int error = Marshal.GetLastWin32Error();
        Win32(ok, error, "Duplicate token for AccessCheck");
    }
    static void CheckLpacAccess(IntPtr token, out bool returned, out bool status, out uint granted) {
        // Chromium CheckLpacToken: in-memory descriptor only, never applied to a filesystem object.
        // https://chromium.googlesource.com/chromium/src/+/04d774d3827c8532b1b7d3966629f9193a35dd0e/sandbox/win/src/app_container_test.cc
        RawSecurityDescriptor descriptor = new RawSecurityDescriptor(
            "O:SYG:SYD:(A;;0x3;;;WD)(A;;0x1;;;S-1-15-2-1)(A;;0x2;;;S-1-15-2-2)");
        byte[] bytes = new byte[descriptor.BinaryLength];
        descriptor.GetBinaryForm(bytes, 0);
        IntPtr data = IntPtr.Zero, privileges = IntPtr.Zero;
        try {
            data = Marshal.AllocHGlobal(bytes.Length);
            Marshal.Copy(bytes, 0, data, bytes.Length);
            // Bounded privilege buffer; an insufficient buffer fails closed without replay.
            uint privilegeLength = 1024;
            privileges = Marshal.AllocHGlobal((int)privilegeLength);
            GenericMapping mapping = new GenericMapping();
            returned = AccessCheck(data, token, 0x02000000, ref mapping, privileges,
                ref privilegeLength, out granted, out status); // MAXIMUM_ALLOWED
            int error = Marshal.GetLastWin32Error();
            Win32(returned, error, "LPAC AccessCheck");
            Require(privilegeLength <= 1024, "AccessCheck privilege result exceeds its buffer.");
        } finally {
            if (privileges != IntPtr.Zero) Marshal.FreeHGlobal(privileges);
            if (data != IntPtr.Zero) Marshal.FreeHGlobal(data);
        }
    }
    static void Attribute(IntPtr list, long key, IntPtr value, int size) {
        bool ok = UpdateProcThreadAttribute(list, 0, new IntPtr(key), value, new IntPtr(size), IntPtr.Zero, IntPtr.Zero);
        int error = Marshal.GetLastWin32Error();
        Win32(ok, error, "UpdateProcThreadAttribute " + key);
    }
    static IntPtr StdioFile(string path, bool input) {
        SecurityAttributes security = new SecurityAttributes { Length = Marshal.SizeOf(typeof(SecurityAttributes)), Inherit = 1 };
        IntPtr handle = CreateFileW(path, input ? 0x80000000u : 0x40000000u, 1, ref security, 1, 0x80, IntPtr.Zero);
        int error = Marshal.GetLastWin32Error();
        Win32(handle != new IntPtr(-1), error, "Create new stdio file");
        return handle;
    }
    static void GrantDirectory(string path, SecurityIdentifier sid, FileSystemRights rights, InheritanceFlags inheritance) {
        DirectorySecurity acl = Directory.GetAccessControl(path);
        acl.AddAccessRule(new FileSystemAccessRule(sid, rights, inheritance, PropagationFlags.None, AccessControlType.Allow));
        Directory.SetAccessControl(path, acl);
    }

    static string FileSha256(string path) {
        using (var file = File.OpenRead(path))
        using (var hash = SHA256.Create())
            return BitConverter.ToString(hash.ComputeHash(file)).Replace("-", "").ToLowerInvariant();
    }

    // Fixed, one-response handshake; no request or command is caller-configurable.
    const string InitializeRequest = "{\"id\":1,\"method\":\"initialize\",\"params\":{\"clientInfo\":{\"name\":\"oms_lpac_probe\",\"version\":\"0.1.0\"},\"capabilities\":{\"experimentalApi\":false,\"optOutNotificationMethods\":[\"remoteControl/status/changed\"]}}}\n";
    const string InitializedNotification = "{\"method\":\"initialized\"}\n";
    const int InitializeOutputLimit = 65536;
    static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);

    static void WriteFixedFrame(IntPtr writer, string frame) {
        byte[] bytes = StrictUtf8.GetBytes(frame);
        // Both fixed frames together fit in the otherwise empty 4096-byte pipe.
        uint written;
        bool ok = WriteFile(writer, bytes, (uint)bytes.Length, out written, IntPtr.Zero);
        int error = Marshal.GetLastWin32Error();
        Win32(ok, error, "Write fixed initialize frame");
        Require(written == bytes.Length, "Incomplete fixed stdin write.");
    }
    static byte[] ReadSharedOutput(string path) {
        using (var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)) {
            long length = file.Length;
            Require(length <= InitializeOutputLimit, "Initialize output exceeds 64 KiB.");
            byte[] bytes = new byte[(int)length];
            int read = 0;
            while (read < bytes.Length) {
                int count = file.Read(bytes, read, bytes.Length - read);
                Require(count > 0, "Initialize output was truncated during read.");
                read += count;
            }
            return bytes;
        }
    }
    static bool ValidateInitializeOutput(byte[] bytes, string expectedHome, bool final) {
        int lastNewline = Array.LastIndexOf(bytes, (byte)'\n');
        if (final) Require(bytes.Length > 0 && lastNewline == bytes.Length - 1, "Incomplete initialize stdout frame.");
        if (lastNewline < 0) return false;
        // Decode only complete lines, never an incomplete UTF-8 character at the live file tail.
        string output = StrictUtf8.GetString(bytes, 0, lastNewline + 1);
        string[] lines = output.Split('\n');
        Require(lines.Length == 2, "Expected exactly one initialize response and no other stdout frames.");
        var parser = new JavaScriptSerializer { MaxJsonLength = InitializeOutputLimit, RecursionLimit = 16 };
        var frame = parser.DeserializeObject(lines[0]) as Dictionary<string, object>;
        Require(frame != null && frame.Count == 2 && frame.ContainsKey("id") && frame.ContainsKey("result")
            && frame["id"] is int && (int)frame["id"] == 1, "Expected id=1 success response only.");
        var result = frame["result"] as Dictionary<string, object>;
        Require(result != null && result.Count == 4 && result.ContainsKey("userAgent")
            && result.ContainsKey("codexHome") && result.ContainsKey("platformFamily") && result.ContainsKey("platformOs"),
            "Unexpected initialize result fields.");
        string userAgent = result["userAgent"] as string;
        Require(userAgent != null && userAgent.StartsWith("oms_lpac_probe/0.153.4 ", StringComparison.Ordinal)
            && (result["platformFamily"] as string) == "windows" && (result["platformOs"] as string) == "windows"
            && String.Equals(result["codexHome"] as string, expectedHome, StringComparison.OrdinalIgnoreCase),
            "Initialize runtime, platform or exact canonical private home mismatch.");
        return true;
    }
    static string CanonicalPrivateHome(string home) {
        // Parent-only read of the newly created directory: normalized NT volume name avoids MountPointManager.
        SecurityAttributes security = new SecurityAttributes { Length = Marshal.SizeOf(typeof(SecurityAttributes)) };
        IntPtr handle = CreateFileW(home, 0x80, 7, ref security, 3, 0x02000000, IntPtr.Zero);
        int error = Marshal.GetLastWin32Error();
        Win32(handle != new IntPtr(-1), error, "Open private home for identity");
        try {
            StringBuilder path = new StringBuilder(32768);
            uint length = GetFinalPathNameByHandleW(handle, path, (uint)path.Capacity, 2); // VOLUME_NAME_NT | FILE_NAME_NORMALIZED
            error = Marshal.GetLastWin32Error();
            Win32(length != 0, error, "Get private home NT path");
            Require(length < path.Capacity && path.ToString().StartsWith(@"\Device\", StringComparison.Ordinal),
                "Unexpected private home NT path.");
            return @"\\?\GLOBALROOT" + path.ToString();
        } finally {
            bool closed = CloseHandle(handle);
            error = Marshal.GetLastWin32Error();
            Win32(closed, error, "Close private home identity handle");
        }
    }
    static void WriteInitializeConfig(string home) {
        // Fixed private configuration derived from probe-codex-windows-registry.py; no provider is started.
        string config = @"model = ""gpt-5.5""
model_provider = ""policy_fixture""
cli_auth_credentials_store = ""file""
sandbox_mode = ""read-only""
approval_policy = ""on-request""
windows.sandbox = ""elevated""
analytics.enabled = false
web_search = ""disabled""
apps._default.enabled = false
tools.experimental_request_user_input.enabled = false
orchestrator.skills.enabled = false
orchestrator.mcp.enabled = false
otel.exporter = ""none""
otel.trace_exporter = ""none""
otel.metrics_exporter = ""none""
model_providers.policy_fixture.name = ""Auth-free unserved loopback""
model_providers.policy_fixture.base_url = ""http://127.0.0.1:9/v1""
model_providers.policy_fixture.wire_api = ""responses""
model_providers.policy_fixture.requires_openai_auth = false
model_providers.policy_fixture.supports_websockets = false
model_providers.policy_fixture.request_max_retries = 0
model_providers.policy_fixture.stream_max_retries = 0
";
        const string disabledFeatures = @"apply_patch_preserve_line_endings apply_patch_streaming_events apps artifact auth_elicitation
background_paginated_rollout_migration bedrock_setup_wizard browser_use browser_use_external
browser_use_full_cdp_access chronicle code_mode code_mode_host code_mode_interrupt
code_mode_only code_mode_prewarm compaction_image_budget computer_use
concurrent_reasoning_summaries content_item_kinds context_management current_time_reminder
cwd_relative_turn_diffs default_mode_request_user_input deferred_executor
deferred_tool_world_state enable_mcp_apps enable_request_compression exec_permission_approvals
executed_tool_call_metadata executor_capability_discovery external_agent_memory_import fast_mode
goals guardian_approval guardian_enhanced_node_repl_transcripts guardian_ext
guardian_node_repl_transcript_images guardian_reuse_parent_compaction guardianv2 hooks
image_generation image_resize_notice in_app_browser in_app_chat in_app_dictation
in_app_local_automation in_app_updates local_thread_store_compression mcp_2026_07_28
mcp_oauth_refresh_coordination memories mentions_v2 multi_agent multi_agent_v2 network_proxy
non_prefixed_mcp_tool_names omit_app_server_notification_media personality plugin_sharing
plugins powershell_shell_version prevent_idle_sleep psp realtime_conversation
recommended_plugins remote_compaction_v2 remote_plugin request_permissions_tool
respect_system_proxy retain_client_developer_messages rollout_budget runtime_metrics
secret_auth_storage shell_snapshot shell_snapshot_v2 shell_tool shell_zsh_fork
skill_mcp_dependency_install skill_search skip_host_skill_discovery sleep_tool
standalone_web_search step_model_switching terminal_visualization_instructions token_budget
tool_call_mcp_elicitation tool_suggest transcript_v2 unbounded_connection_retries unified_exec
unified_image_budget use_agent_identity use_legacy_landlock view_image web_search_cached
web_search_request workspace_dependencies write_stdin_approval";
        foreach (string feature in disabledFeatures.Split((char[])null, StringSplitOptions.RemoveEmptyEntries))
            config += "features." + feature + " = false\n";
        File.WriteAllText(Path.Combine(home, "config.toml"), config, new UTF8Encoding(false));
    }

    public static OmsLpacResult Run(string fixture, string profileName, bool codexVersion, bool codexInitialize) {
        OmsLpacResult result = new OmsLpacResult();
        bool codex = codexVersion || codexInitialize;
        result.Mode = codexInitialize ? "codex-initialize" : codexVersion ? "codex-version" : "read-boundary";
        IntPtr sid = IntPtr.Zero, callerToken = IntPtr.Zero, childToken = IntPtr.Zero;
        IntPtr callerCheckToken = IntPtr.Zero, childCheckToken = IntPtr.Zero;
        IntPtr attributes = IntPtr.Zero, capsData = IntPtr.Zero, policy = IntPtr.Zero, handlesData = IntPtr.Zero, environment = IntPtr.Zero;
        IntPtr stdin = IntPtr.Zero, stdinWriter = IntPtr.Zero, stdout = IntPtr.Zero, stderr = IntPtr.Zero;
        IntPtr capabilityEntries = IntPtr.Zero;
        IntPtr[] capabilitySids = new IntPtr[CmdCapabilitySids.Length];
        ProcessInformation process = new ProcessInformation();
        bool attributesInitialized = false;
        string inside = Path.Combine(fixture, "inside");
        string stdoutPath = Path.Combine(fixture, "child.stdout");
        string stderrPath = Path.Combine(fixture, "child.stderr");
        string insideMarker = "OMS_LPAC_INSIDE_" + Guid.NewGuid().ToString("N");
        string outsideMarker = "OMS_LPAC_OUTSIDE_" + Guid.NewGuid().ToString("N");
        try {
            result.Stage = "caller";
            bool opened = OpenProcessToken(GetCurrentProcess(), 10, out callerToken); // QUERY | DUPLICATE
            int openError = Marshal.GetLastWin32Error();
            Win32(opened, openError, "Open caller token");
            Require(TokenInt(callerToken, TokenElevation) == 0, "Elevated caller forbidden.");
            result.CallerSid = WindowsIdentity.GetCurrent().User.Value;
            result.Stage = "caller-access-control";
            Require(TokenInt(callerToken, TokenIsAppContainer) == 0, "Caller control must not be an AppContainer.");
            DuplicateForAccessCheck(callerToken, out callerCheckToken);
            CheckLpacAccess(callerCheckToken, out result.CallerAccessCheckReturned,
                out result.CallerAccessStatus, out result.CallerGrantedAccess);
            Require(result.CallerAccessStatus && result.CallerGrantedAccess == 3,
                "Ordinary caller AccessCheck control must grant exactly mask 3.");
            result.Stage = "child-environment";
            string localAppData = Environment.GetEnvironmentVariable("LOCALAPPDATA");
            Require(!String.IsNullOrWhiteSpace(localAppData) && localAppData.Length >= 3
                && Char.IsLetter(localAppData[0]) && localAppData[1] == ':' && localAppData[2] == '\\'
                && localAppData.IndexOf('\0') < 0, "Caller LOCALAPPDATA must be an absolute local path.");
            result.ChildLocalAppData = Path.GetFullPath(localAppData);
            result.Stage = "fixture";
            Directory.CreateDirectory(inside);
            if (codex) {
                result.Stage = "stage-pinned-codex";
                Require(FileSha256(CodexSource) == CodexSha256, "Source Codex hash mismatch.");
                result.Executable = Path.Combine(inside, "codex.exe");
                File.Copy(CodexSource, result.Executable, false);
                result.ExecutableSha256 = FileSha256(result.Executable);
                Require(result.ExecutableSha256 == CodexSha256, "Staged Codex hash mismatch.");
                Directory.CreateDirectory(Path.Combine(inside, "home", "temp"));
                if (codexInitialize) {
                    WriteInitializeConfig(Path.Combine(inside, "home"));
                    result.ExpectedCodexHome = CanonicalPrivateHome(Path.Combine(inside, "home"));
                }
            }
            File.WriteAllText(Path.Combine(inside, "inside.txt"), insideMarker + "\r\n", Encoding.ASCII);
            File.WriteAllText(Path.Combine(fixture, "outside.txt"), outsideMarker + "\r\n", Encoding.ASCII);
            result.Stage = "profile";
            int hr = CreateAppContainerProfile(profileName, profileName, "Retained network-free OMS LPAC probe", IntPtr.Zero, 0, out sid);
            // Never derive/reuse an existing profile, and never delete it on failure.
            if (hr != 0) Marshal.ThrowExceptionForHR(hr);
            Require(hr == 0, "Profile creation did not return S_OK.");
            Require(sid != IntPtr.Zero, "Profile returned no SID.");
            result.ProfileCreated = true;
            SecurityIdentifier packageSid = new SecurityIdentifier(sid);
            result.ProfileSid = packageSid.Value;
            File.WriteAllText(Path.Combine(fixture, "profile.txt"), profileName + "\r\n" + result.ProfileSid + "\r\n", Encoding.ASCII);
            result.Stage = "new-fixture-grants";
            GrantDirectory(fixture, packageSid, FileSystemRights.Traverse, InheritanceFlags.None);
            GrantDirectory(inside, packageSid, FileSystemRights.ReadAndExecute, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit);
            if (codex) {
                // Codex may initialize its own temporary state; only this new empty home is writable.
                GrantDirectory(Path.Combine(inside, "home"), packageSid, FileSystemRights.Modify,
                    InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit);
            }
            result.Stage = "stdio";
            if (codexInitialize) {
                // Pinned windows-sandbox-rs pattern: both endpoints start non-inheritable; mark only child read.
                bool pipeCreated = CreatePipe(out stdin, out stdinWriter, IntPtr.Zero, 4096);
                int pipeError = Marshal.GetLastWin32Error();
                Win32(pipeCreated, pipeError, "Create fixed initialize stdin pipe");
                bool inherited = SetHandleInformation(stdin, 1, 1);
                int inheritError = Marshal.GetLastWin32Error();
                Win32(inherited, inheritError, "Inherit only child stdin read handle");
                File.WriteAllText(Path.Combine(fixture, "child.stdin"), InitializeRequest, StrictUtf8);
            } else stdin = StdioFile(Path.Combine(fixture, "child.stdin"), true);
            stdout = StdioFile(stdoutPath, false);
            stderr = StdioFile(stderrPath, false);
            result.Stage = "attributes";
            IntPtr size = IntPtr.Zero;
            bool sized = InitializeProcThreadAttributeList(IntPtr.Zero, 4, 0, ref size);
            int sizeError = Marshal.GetLastWin32Error();
            Require(!sized && sizeError == 122 && size.ToInt64() > 0,
                "Attribute size query: return=" + sized + ", error=" + sizeError + ", needed=" + size);
            attributes = Marshal.AllocHGlobal(size);
            bool initialized = InitializeProcThreadAttributeList(attributes, 4, 0, ref size);
            int initializeError = Marshal.GetLastWin32Error();
            Win32(initialized, initializeError, "Initialize attributes");
            attributesInitialized = true;
            int capabilityStride = Marshal.SizeOf(typeof(SidAndAttributes));
            capabilityEntries = Marshal.AllocHGlobal(capabilityStride * CmdCapabilitySids.Length);
            for (int i = 0; i < CmdCapabilitySids.Length; i++) {
                SecurityIdentifier capability = new SecurityIdentifier(CmdCapabilitySids[i]);
                byte[] bytes = new byte[capability.BinaryLength];
                capability.GetBinaryForm(bytes, 0);
                capabilitySids[i] = Marshal.AllocHGlobal(bytes.Length);
                Marshal.Copy(bytes, 0, capabilitySids[i], bytes.Length);
                Marshal.StructureToPtr(new SidAndAttributes { Sid = capabilitySids[i], Attributes = 4 },
                    IntPtr.Add(capabilityEntries, i * capabilityStride), false); // SE_GROUP_ENABLED
            }
            SecurityCapabilities caps = new SecurityCapabilities {
                Sid = sid, Capabilities = capabilityEntries, Count = (uint)CmdCapabilitySids.Length
            };
            capsData = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(SecurityCapabilities)));
            Marshal.StructureToPtr(caps, capsData, false);
            Attribute(attributes, 0x20009, capsData, Marshal.SizeOf(typeof(SecurityCapabilities)));
            policy = Marshal.AllocHGlobal(4);
            Marshal.WriteInt32(policy, 1);
            // LPAC opt-out and no descendant processes. Both are mandatory; no fallback.
            Attribute(attributes, 0x2000f, policy, 4);
            Attribute(attributes, 0x2000e, policy, 4);
            handlesData = Marshal.AllocHGlobal(IntPtr.Size * 3);
            Marshal.WriteIntPtr(handlesData, 0, stdin);
            Marshal.WriteIntPtr(handlesData, IntPtr.Size, stdout);
            Marshal.WriteIntPtr(handlesData, IntPtr.Size * 2, stderr);
            Attribute(attributes, 0x20002, handlesData, IntPtr.Size * 3);
            if (!codex) result.Executable = Path.Combine(Environment.SystemDirectory, "cmd.exe");
            // Fixed relative filenames avoid caller-controlled shell text. TYPE is a cmd builtin.
            result.CommandLine = "\"" + result.Executable + (codexInitialize
                ? "\" app-server --strict-config --listen stdio://" : codexVersion
                ? "\" --version" : "\" /d /v:off /c \"type inside.txt & type ..\\outside.txt\"");
            string windows = Directory.GetParent(Environment.SystemDirectory).FullName;
            // Single-variable hypothesis for error 203; Windows documents AppContainer LOCALAPPDATA rerouting.
            // https://learn.microsoft.com/en-us/windows/win32/secauthz/implementing-an-appcontainer
            string env = "COMSPEC=" + result.Executable + "\0LOCALAPPDATA=" + result.ChildLocalAppData
                + "\0SystemRoot=" + windows + "\0TEMP=" + inside + "\0TMP=" + inside + "\0WINDIR=" + windows + "\0\0";
            if (codex) {
                // No ambient auth/config home: only this new empty fixture is named.
                string home = Path.Combine(inside, "home");
                string temp = Path.Combine(home, "temp");
                env = "APPDATA=" + home + "\0CODEX_HOME=" + home + "\0HOME=" + home
                    + "\0LOCALAPPDATA=" + result.ChildLocalAppData + "\0SystemRoot=" + windows
                    + "\0TEMP=" + temp + "\0TMP=" + temp + "\0USERPROFILE=" + home
                    + "\0WINDIR=" + windows + "\0\0";
            }
            environment = Marshal.StringToHGlobalUni(env);
            StartupInfoEx startup = new StartupInfoEx();
            startup.StartupInfo.cb = Marshal.SizeOf(typeof(StartupInfoEx));
            startup.StartupInfo.Flags = 0x100; // STARTF_USESTDHANDLES
            startup.StartupInfo.StdInput = stdin; startup.StartupInfo.StdOutput = stdout; startup.StartupInfo.StdError = stderr;
            startup.AttributeList = attributes;
            result.Stage = "create-suspended";
            // DETACHED_PROCESS avoids console allocation during KERNELBASE initialization.
            // CREATE_NO_WINDOW still attempted allocation, which returned 0xc000049d during startup.
            // Explicit file stdio remains inherited; no console or descendant process is needed.
            // EXTENDED_STARTUPINFO_PRESENT | CREATE_UNICODE_ENVIRONMENT | CREATE_SUSPENDED | DETACHED_PROCESS
            bool created = CreateProcessW(result.Executable, new StringBuilder(result.CommandLine), IntPtr.Zero, IntPtr.Zero, true,
                0x0008040c, environment, inside, ref startup, out process);
            int createError = Marshal.GetLastWin32Error();
            Win32(created, createError, "Create LPAC child");
            result.ProcessId = process.ProcessId;
            result.Stage = "verify-suspended-token";
            bool childOpened = OpenProcessToken(process.Process, 10, out childToken); // QUERY | DUPLICATE
            int childOpenError = Marshal.GetLastWin32Error();
            Win32(childOpened, childOpenError, "Open child token");
            result.IsAppContainer = TokenInt(childToken, TokenIsAppContainer);
            VerifyCmdCapabilities(childToken, result);
            result.SessionId = TokenInt(childToken, 12);
            result.ChildSid = TokenSid(childToken);
            DuplicateForAccessCheck(childToken, out childCheckToken);
            CheckLpacAccess(childCheckToken, out result.ChildAccessCheckReturned,
                out result.ChildAccessStatus, out result.ChildGrantedAccess);
            File.WriteAllText(Path.Combine(fixture, "token.txt"), "pid=" + result.ProcessId
                + "\r\nTokenIsAppContainer=" + result.IsAppContainer
                + "\r\nCallerAccessCheck.Returned=" + result.CallerAccessCheckReturned
                + "\r\nCallerAccessCheck.AccessStatus=" + result.CallerAccessStatus
                + "\r\nCallerAccessCheck.GrantedMask=" + result.CallerGrantedAccess
                + "\r\nChildAccessCheck.Returned=" + result.ChildAccessCheckReturned
                + "\r\nChildAccessCheck.AccessStatus=" + result.ChildAccessStatus
                + "\r\nChildAccessCheck.GrantedMask=" + result.ChildGrantedAccess
                + "\r\nTokenCapabilities.Count=" + result.CapabilityCount
                + "\r\nTokenCapabilities.Sids=" + String.Join(";", result.CapabilitySids)
                + "\r\nTokenSessionId=" + result.SessionId
                + "\r\nTokenAppContainerSid=" + result.ChildSid + "\r\n", Encoding.ASCII);
            Require(result.IsAppContainer == 1 && result.ChildAccessStatus && result.ChildGrantedAccess == 2
                && result.CapabilityCount == CmdCapabilitySids.Length && result.ChildSid == result.ProfileSid && result.SessionId == 1,
                "Suspended token does not match the LPAC profile with the two fixed cmd capabilities.");
            result.Stage = "resume";
            Stopwatch childDeadline = Stopwatch.StartNew();
            uint previousCount = ResumeThread(process.Thread);
            int resumeError = Marshal.GetLastWin32Error();
            Win32(previousCount != INFINITE_ERROR, resumeError, "ResumeThread");
            Require(previousCount == 1, "Unexpected suspend count.");
            result.Resumed = true;
            if (codexInitialize) {
                result.Stage = "initialize-handshake";
                WriteFixedFrame(stdinWriter, InitializeRequest);
                while (!result.InitializeResponseObserved) {
                    result.TimedOut = childDeadline.ElapsedMilliseconds >= 15000;
                    Require(!result.TimedOut, "Initialize exceeded total 15-second child deadline.");
                    Require(new FileInfo(stderrPath).Length <= InitializeOutputLimit, "Initialize stderr exceeds 64 KiB.");
                    result.InitializeResponseObserved = ValidateInitializeOutput(ReadSharedOutput(stdoutPath), result.ExpectedCodexHome, false);
                    if (result.InitializeResponseObserved) break;
                    uint alive = WaitForSingleObject(process.Process, (uint)Math.Max(0, Math.Min(25, 15000 - childDeadline.ElapsedMilliseconds)));
                    int aliveError = Marshal.GetLastWin32Error();
                    Win32(alive != INFINITE_ERROR, aliveError, "Wait for initialize response");
                    Require(alive == WAIT_TIMEOUT, "Child exited before initialize response was observed.");
                }
                result.TimedOut = childDeadline.ElapsedMilliseconds >= 15000;
                Require(!result.TimedOut, "Initialize response exceeded total 15-second child deadline.");
                WriteFixedFrame(stdinWriter, InitializedNotification);
                File.AppendAllText(Path.Combine(fixture, "child.stdin"), InitializedNotification, StrictUtf8);
                bool closed = CloseHandle(stdinWriter);
                int closeError = Marshal.GetLastWin32Error();
                if (closed) stdinWriter = IntPtr.Zero;
                Win32(closed, closeError, "Close fixed initialize stdin writer after response");
            }
            result.Stage = "wait";
            long remaining = Math.Max(0, 15000 - childDeadline.ElapsedMilliseconds);
            result.TimedOut = remaining <= 0;
            Require(!result.TimedOut, "Child exceeded total 15-second deadline before reap.");
            uint wait = WaitForSingleObject(process.Process, (uint)remaining);
            int waitError = Marshal.GetLastWin32Error();
            Win32(wait != INFINITE_ERROR, waitError, "WaitForSingleObject");
            result.TimedOut = wait == WAIT_TIMEOUT;
            Require(wait == 0, "Child wait failed or exceeded 15 seconds: " + wait);
            result.Reaped = true;
            uint exit;
            bool exited = GetExitCodeProcess(process.Process, out exit);
            int exitError = Marshal.GetLastWin32Error();
            Win32(exited, exitError, "Child exit code");
            result.ExitCode = exit;
        } catch (Exception error) {
            result.Error = error.ToString();
            Win32Exception native = error as Win32Exception;
            if (native != null) result.NativeErrorCode = native.NativeErrorCode;
        }
        finally {
            if (process.Process != IntPtr.Zero && !result.Reaped) {
                result.KillAttempted = true;
                bool killed = TerminateProcess(process.Process, 0xe0000001);
                int killError = Marshal.GetLastWin32Error();
                uint cleanupWait = WaitForSingleObject(process.Process, 5000);
                int cleanupWaitError = Marshal.GetLastWin32Error();
                result.Reaped = cleanupWait == 0;
                uint exit;
                if (result.Reaped) {
                    bool gotExit = GetExitCodeProcess(process.Process, out exit);
                    int cleanupExitError = Marshal.GetLastWin32Error();
                    if (gotExit) result.ExitCode = exit;
                    else result.Error += "\nCleanup GetExitCodeProcess failed with Win32 error " + cleanupExitError;
                }
                if (!result.Reaped) result.Error += "\nOWNED CHILD NOT REAPED; TerminateProcess=" + killed + ", error=" + killError
                    + ", wait=" + cleanupWait + ", wait error=" + cleanupWaitError;
            }
            foreach (IntPtr handle in new IntPtr[] { childCheckToken, callerCheckToken, childToken, callerToken, process.Thread, process.Process, stdinWriter, stdin, stdout, stderr }) {
                if (handle == IntPtr.Zero) continue;
                bool closed = CloseHandle(handle);
                int closeError = Marshal.GetLastWin32Error();
                if (!closed) result.Error += "\nCloseHandle failed with Win32 error " + closeError;
            }
            if (attributesInitialized) DeleteProcThreadAttributeList(attributes);
            foreach (IntPtr allocation in new IntPtr[] { attributes, capsData, capabilityEntries, policy, handlesData, environment })
                if (allocation != IntPtr.Zero) Marshal.FreeHGlobal(allocation);
            foreach (IntPtr capabilitySid in capabilitySids)
                if (capabilitySid != IntPtr.Zero) Marshal.FreeHGlobal(capabilitySid);
            if (sid != IntPtr.Zero) FreeSid(sid);
        }
        if (result.Error == null) {
            try {
                result.Stage = codexInitialize ? "assert-codex-initialize" : codexVersion ? "assert-codex-version" : "assert-read-boundary";
                string output = codexInitialize ? null : File.ReadAllText(stdoutPath, Encoding.ASCII);
                string errors = codexInitialize ? StrictUtf8.GetString(ReadSharedOutput(stderrPath)) : File.ReadAllText(stderrPath, Encoding.ASCII);
                if (codexInitialize) {
                    Require(result.ExitCode == 0 && errors.Length == 0 && result.InitializeResponseObserved,
                        "Expected initialize response, empty stderr and exit 0.");
                    Require(ValidateInitializeOutput(ReadSharedOutput(stdoutPath), result.ExpectedCodexHome, true),
                        "Missing final initialize response.");
                    Require(FileSha256(result.Executable) == CodexSha256, "Staged Codex changed.");
                } else if (codexVersion) {
                    Require(result.ExitCode == 0 && output.Replace("\r\n", "\n") == "codex-cli 0.153.4\n"
                        && errors.Length == 0, "Expected exact Codex version, empty stderr and exit 0.");
                    Require(FileSha256(result.Executable) == CodexSha256, "Staged Codex changed.");
                } else {
                    Require(result.ExitCode == 1 && output == insideMarker + "\r\n" && !output.Contains(outsideMarker)
                        && errors.Trim() == "Access is denied.", "Expected inside-only stdout, English Access is denied stderr and cmd exit 1.");
                }
                Require(File.ReadAllText(Path.Combine(inside, "inside.txt"), Encoding.ASCII) == insideMarker + "\r\n"
                    && File.ReadAllText(Path.Combine(fixture, "outside.txt"), Encoding.ASCII) == outsideMarker + "\r\n", "Canary content changed.");
                result.Passed = true;
                result.Stage = "passed";
            } catch (Exception error) { result.Error = error.ToString(); }
        }
        result.FinishedUtc = DateTime.UtcNow.ToString("o");
        return result;
    }
}
'@
    $report.native_result = [OmsLpacProbe]::Run($fixture, $ProfileName, $CodexVersion.IsPresent, $CodexInitialize.IsPresent)
    if ($report.native_result.Passed) { $report.status = 'passed' }
} catch { $report.error = $_.Exception.ToString() }
finally {
    $env:TEMP = $savedTemp
    $env:TMP = $savedTmp
    $report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $fixture 'result.json') -Encoding UTF8
}
Write-Output (Join-Path $fixture 'result.json')
if ($report.status -ne 'passed') { throw 'LPAC probe failed; inspect retained result.json and raw child output. No retry or weaker fallback.' }
