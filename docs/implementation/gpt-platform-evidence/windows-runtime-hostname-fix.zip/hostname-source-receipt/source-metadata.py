from pathlib import Path
import hashlib,json
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/c2-734b-20260913/registry/src/index.crates.io-1949cf8c6b5b557f/gethostname-1.1.0')
print(json.dumps({'entries':[x.name for x in p.iterdir()],'files':{n:({'exists':True,'bytes':(p/n).stat().st_size,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} if (p/n).is_file() else {'exists':False}) for n in ['src/lib.rs','Cargo.toml','.cargo-checksum.json']}}))