from pathlib import Path
import json,hashlib
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/c2-734b-20260913/registry/src/index.crates.io-1949cf8c6b5b557f/winapi-util-0.1.11')
print(json.dumps({n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['src/sysinfo.rs', 'Cargo.toml']}))