if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-97dc2cb53348';$files=@{
  'probe-windows-lpac.ps1'='28fbed328ad7086f38cb5a463708259e8a1cbd8addabf6f187eb2aa88eb0fa7d'
  'probe-interactive.ps1'='1036c207a535fa8aa88ec606059b2e027bf62d7e68f5302f6d9f12eb1f9d8e57'
  'run-lpac-task.ps1'='4a977fe596f1d2c22bfdd4fdfb4f9f4bb143044871283bf7866b5dbec76f94fb'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
