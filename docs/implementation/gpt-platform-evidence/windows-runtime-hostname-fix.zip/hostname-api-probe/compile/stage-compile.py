"""Stage exact reviewed compile inputs only. Does not launch a task or executable."""
from pathlib import Path
import base64,json,hashlib,subprocess,ast
p=Path(__file__).resolve().parent
root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9'
pins={'hostname-api-20260913.c': '5a93a41514e875e9f58af4f1d280d160ba6aa9481dde969ec291f1472127b42b', 'hostname-api-compile-20260913.py': '1d22752a9035b9abb12bf3ee4bf7144e29a0e8619937599a22f08a17b3291727', 'hostname-api-compile-20260913-guard.py': '98a64166677b9974967838d722104dacdb55ce61d3f158f7f31c99f352dd87f5', 'launch-hostname-api-compile-20260913.ps1': 'bec3a0a97806a7ce147f7ecb08413be88ab3ec54406436a0d55f1cfdd2d1ac2a'}
for n,h in pins.items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n
ast.parse((p/'hostname-api-compile-20260913.py').read_text())
def remote(label,source):
 cmd=['ssh','nuc','C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe -B -I -c "import base64;exec(base64.b64decode('+repr(base64.b64encode(source.encode()).decode())+'))"']
 with (p/(label+'.command.json')).open('x') as f:json.dump(cmd,f,indent=2)
 r=subprocess.run(cmd,capture_output=True,timeout=30);(p/(label+'.stdout')).write_bytes(r.stdout);(p/(label+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,r.stderr
remote('stage-precheck',"from pathlib import Path\np=Path("+repr(root)+")\nfor n in "+repr(list(pins)+['hostname-api-compile-20260913-once.json','target/hostname-api-20260913'])+":assert not (p/n).exists(),n\nfor a in [p,*p.parents]:assert not (a.lstat().st_file_attributes & 0x400),str(a)\nprint('fresh paths confirmed')")
cmd=['scp','-q',*[str(p/n) for n in pins],'nuc:'+root+'/'];(p/'stage-copy.command.json').write_text(json.dumps(cmd,indent=2)+'\n');r=subprocess.run(cmd,capture_output=True,timeout=30);(p/'stage-copy.stdout').write_bytes(r.stdout);(p/'stage-copy.stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr
remote('stage-verify',"from pathlib import Path\nimport hashlib,ast,json\np=Path("+repr(root)+")\nhashes="+repr(pins)+"\nfor n,h in hashes.items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n\nfor n in hashes:\n if n.endswith('.py'):ast.parse((p/n).read_text())\nprint(json.dumps(hashes))")
