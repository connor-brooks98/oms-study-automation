"""Dispatch the reviewed fresh Limited compiler task once. Never execute the output."""
from pathlib import Path
import json,hashlib,subprocess,base64,datetime
p=Path(__file__).resolve().parent
name='launch-hostname-api-compile-20260913.ps1'
assert hashlib.sha256((p/name).read_bytes()).hexdigest()=='bec3a0a97806a7ce147f7ecb08413be88ab3ec54406436a0d55f1cfdd2d1ac2a'
assert (p/'stage-verify.stdout').is_file()
with (p/'launch-once.json').open('x') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},f)
cmd=['ssh','nuc','powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode((p/name).read_text().encode('utf-16-le')).decode()]
(p/'launch.command.json').write_text(json.dumps(cmd,indent=2)+'\n');r=subprocess.run(cmd,capture_output=True,timeout=30);(p/'launch.stdout').write_bytes(r.stdout);(p/'launch.stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr;print(r.stdout.decode())
