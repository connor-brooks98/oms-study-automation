#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0602
#include <windows.h>
/* No CRT, hostname buffer, environment read, filesystem or network operation. */
static char *append(char *p, const char *s) { while (*s) *p++ = *s++; return p; }
static char *number(char *p, DWORD n) {
    char digits[10]; unsigned int i = 0;
    do { digits[i++] = (char)('0' + n % 10); n /= 10; } while (n);
    while (i) *p++ = digits[--i];
    return p;
}
void mainCRTStartup(void) {
    DWORD size = 0;
    BOOL returned = GetComputerNameExW(ComputerNamePhysicalDnsHostname, NULL, &size);
    DWORD error = GetLastError();
    char output[128]; char *end = output; DWORD written = 0;
    end = append(end, "{\"format\":5,\"returned\":");
    end = number(end, returned != 0);
    end = append(end, ",\"size\":"); end = number(end, size);
    end = append(end, ",\"last_error\":"); end = number(end, error);
    end = append(end, "}\n");
    if (!WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), output, (DWORD)(end-output), &written, NULL)
        || written != (DWORD)(end-output)) ExitProcess(2);
    ExitProcess(0);
}
