use std::io;

#[cfg(any(windows, test))]
fn remote_control_display_name(hostname: io::Result<std::ffi::OsString>) -> String {
    // This is a display label, not the hostname used to select configuration policy.
    hostname
        .ok()
        .map(|name| name.to_string_lossy().trim().to_string())
        .filter(|name| !name.is_empty())
        .unwrap_or_else(|| "Codex app-server".to_string())
}

#[test]
fn remote_control_display_name_preserves_hostname() {
    assert_eq!(
        remote_control_display_name(Ok(std::ffi::OsString::from("  WORKSTATION-Ω  "))),
        "WORKSTATION-Ω",
    );
}

#[test]
fn remote_control_display_name_handles_hostname_errors() {
    for error in [5, 87] {
        assert_eq!(
            remote_control_display_name(Err(io::Error::from_raw_os_error(error))),
            "Codex app-server",
        );
    }
}

#[test]
fn remote_control_display_name_handles_empty_hostname() {
    for name in ["", "  "] {
        assert_eq!(
            remote_control_display_name(Ok(std::ffi::OsString::from(name))),
            "Codex app-server",
        );
    }
}
