# Windows remote-control display-name patch review

Scope: one new patch against pinned Codex 0.153.4 source commit 3d2ee51ca2d5db578f328aa75e20aa22c0197c9a, after the accepted workspace version normalization and arg0 path patch. The original source snapshot is not edited. This directory contains only the seven relevant baseline/candidate files, not a runnable full Cargo workspace.

The Windows remote-control display-name lookup now uses existing winapi-util 0.1.11's fallible `get_computer_name(PhysicalDnsHostname)`. Successful nonempty names preserve the old lossy Unicode conversion and whitespace trimming. Failed or empty lookup yields the contextual label `Codex app-server`. Non-Windows production behavior is unchanged. No shared gethostname, config hostname policy, OTEL, authorization, endpoint, persistence key, or remote enablement code changes. The source audit proves separation of display label from identity/routing only within this pinned client; backend behavior is not tested.

Four changed upstream files: app-server-transport/Cargo.toml, Cargo.lock, app-server-transport/src/transport/remote_control/mod.rs, and that module's existing tests.rs. Root workspace manifest already declares winapi-util 0.1.11 and Cargo.lock already contains its package/checksum; lock semantic comparison proves only the transport -> winapi-util edge is added. The target-specific dependency applies only on Windows.

## Local proof

`final-local-validation.json` records exact final harness compile with Homebrew rustc 1.95.0, three passing tests, rustfmt checks, and whitespace check. `focused-tests.rs` contains the exact candidate pure result-to-label helper and exact three new test bodies with only `use std::io` prepended; extraction equality was asserted. This is not a full module Cargo test, Windows compile, or native startup proof. The early `local-validation.json` retains an initial harness-only trailing blank-line formatting failure; the final receipt supersedes it after removing that blank line. The no-index whitespace command returns 1 for an existing diff, with no diagnostics; that is expected. Existing tests outside this focused set still call gethostname and are not claimed LPAC compatible.

A fresh application to `apply-verification` was byte-compared against all candidate files. Root Cargo.toml, .cargo/config.toml, and accepted patched arg0/src/lib.rs remain byte-identical. The new patch does not include those unchanged files. Baseline lock SHA is a2cb91dfb2e8112bc81d05158fa00b9698e2df8cc1ae0547b5dc5606a44904d3; candidate lock SHA is 4a662fefd012e445ac8789f3a4376550acaa7ba901b6c62f2309078dca8fe8c6. All file hashes are in manifest.json.

## Native gates still required

Independent exact-patch review, exact cached winapi-util source receipt, and reviewed build pins must precede native compilation. Reuse the accepted patched Rust 1.95, existing cache and no-LTO profile; no dependency version or clean rebuild is required by this patch, though Cargo must rebuild transport and affected dependents and relink Codex. New source and lock hashes must be bound honestly. Do not reuse the prior executable hash as acceptance for this change.

A successful new artifact must pass fresh strict LPAC --version then fixed stdio initialize with empty stderr, correct response id, normal exit, and preservation/cleanup receipts. No provider, auth, thread, tool or live Hub acceptance is implied. Arg0 native tests remain gated by successful version/initialize. GLOBALROOT PathUri/no-follow limitations remain unchanged and unaccepted. No Windows operations were performed by this patch author.

Primary API source inspected: https://docs.rs/winapi-util/latest/src/winapi_util/sysinfo.rs.html (fallible API and name kind). Exact 0.1.11 native-cache receipt is required before native rebuild; latest documentation alone is not an exact source pin. Microsoft GetComputerNameExW reference: https://learn.microsoft.com/en-us/windows/win32/api/sysinfoapi/nf-sysinfoapi-getcomputernameexw . Parent/operator separately own the native API discriminator receipts; this preparation does not declare their final preservation review outcome.
