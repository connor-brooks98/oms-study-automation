# Completed 9.5 GiB final CLI failure

The final codex CLI compile failed with LLVM OOM near the 9.5 GiB owned-job cap. All 109 memory checks and 18 Hub guards passed; reserve floors did not trigger. Independent cleanup/preservation passed. No accepted executable or runtime probe. This snapshot excludes any later profile-adjusted build.
