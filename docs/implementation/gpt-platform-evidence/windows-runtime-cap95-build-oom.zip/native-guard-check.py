import runpy,json,hashlib
from pathlib import Path
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/codex-build-cap95-20260913-guard.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='aae3fe7e23610f628ae923729fa16f64635392f776d2acd3aa2204aaa7514248'
g=runpy.run_path(str(p))
print(json.dumps(g["health"]("preflight"),indent=2))
