"""Compile the pinned private Codex CLI only; never execute the build output."""
from pathlib import Path
import ctypes,ctypes.wintypes as w,json,hashlib,os,subprocess,msvcrt,_winapi,datetime,time
root=Path(__file__).resolve().parent
k=ctypes.WinDLL('kernel32',use_last_error=True)
class BASIC(ctypes.Structure):_fields_=[('ProcessTime',ctypes.c_int64),('JobTime',ctypes.c_int64),('Flags',w.DWORD),('Min',ctypes.c_size_t),('Max',ctypes.c_size_t),('Active',w.DWORD),('Affinity',ctypes.c_size_t),('Priority',w.DWORD),('Scheduling',w.DWORD)]
class IO(ctypes.Structure):_fields_=[(n,ctypes.c_uint64) for n in ['ReadOp','WriteOp','OtherOp','ReadBytes','WriteBytes','OtherBytes']]
class EXT(ctypes.Structure):_fields_=[('Basic',BASIC),('Io',IO),('ProcessMemory',ctypes.c_size_t),('JobMemory',ctypes.c_size_t),('PeakProcess',ctypes.c_size_t),('PeakJob',ctypes.c_size_t)]
k.CreateJobObjectW.argtypes=[ctypes.c_void_p,w.LPCWSTR];k.CreateJobObjectW.restype=w.HANDLE
k.SetInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD];k.SetInformationJobObject.restype=w.BOOL
k.QueryInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD,ctypes.POINTER(w.DWORD)];k.QueryInformationJobObject.restype=w.BOOL
k.AssignProcessToJobObject.argtypes=[w.HANDLE,w.HANDLE];k.AssignProcessToJobObject.restype=w.BOOL
k.TerminateJobObject.argtypes=[w.HANDLE,w.UINT];k.TerminateJobObject.restype=w.BOOL
k.ResumeThread.argtypes=[w.HANDLE];k.ResumeThread.restype=w.DWORD
k.CloseHandle.argtypes=[w.HANDLE];k.CloseHandle.restype=w.BOOL
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
guard=__import__('runpy').run_path(str(root/'codex-build-cap95-20260913-guard.py'))
records=[]
def bounded(label,args,env,cwd='C:/',timeout=5400):
 rec=dict(label=label,argv=args,cwd=cwd,environment=env,started_utc=utc(),timeout_seconds=timeout,priority='BELOW_NORMAL_PRIORITY_CLASS',kill_on_close_job=True,job_memory_limit_bytes=19*1024**3//2)
 (root/(label+'-invocation.json')).write_text(json.dumps(rec,indent=2)+'\n')
 guard['memory']('preflight')
 job=k.CreateJobObjectW(None,None)
 if not job:raise ctypes.WinError(ctypes.get_last_error())
 hp=ht=None
 try:
  info=EXT();info.Basic.Flags=0x2200;info.JobMemory=19*1024**3//2
  if not k.SetInformationJobObject(job,9,ctypes.byref(info),ctypes.sizeof(info)):raise ctypes.WinError(ctypes.get_last_error())
  with (root/(label+'.stdout')).open('xb') as out,(root/(label+'.stderr')).open('xb') as err,open(os.devnull,'rb') as inp:
   handles=[msvcrt.get_osfhandle(f.fileno()) for f in [inp,out,err]]
   for h in handles:os.set_handle_inheritable(h,True)
   si=subprocess.STARTUPINFO();si.dwFlags=subprocess.STARTF_USESTDHANDLES;si.hStdInput,si.hStdOutput,si.hStdError=handles;si.lpAttributeList={'handle_list':handles}
   try:hp,ht,pid,tid=_winapi.CreateProcess(args[0],subprocess.list2cmdline(args),None,None,True,0x00004004,env,cwd,si)
   finally:
    for h in handles:os.set_handle_inheritable(h,False)
   rec.update(pid=pid,tid=tid)
   if not k.AssignProcessToJobObject(job,int(hp)):raise ctypes.WinError(ctypes.get_last_error())
   if k.ResumeThread(int(ht))==0xffffffff:raise ctypes.WinError(ctypes.get_last_error())
   (root/'codex-build-cap95-20260913-progress.json').write_text(json.dumps(dict(state='running',pid=pid,started_utc=rec['started_utc']))+'\n')
   deadline=time.monotonic()+timeout;next_health=time.monotonic()
   while True:
    remaining=deadline-time.monotonic()
    if remaining<=0:status=258;break
    status=_winapi.WaitForSingleObject(hp,min(5000,max(1,int(remaining*1000))))
    if status!=258:break
    guard['memory']('during')
    if time.monotonic()>=next_health:
     guard['health']('during');next_health=time.monotonic()+30
   rec['timed_out']=status==258
   if rec['timed_out']:
    if not k.TerminateJobObject(job,124):raise ctypes.WinError(ctypes.get_last_error())
    _winapi.WaitForSingleObject(hp,5000)
   rec['returncode']=_winapi.GetExitCodeProcess(hp)
 finally:
  cleanup_errors=[]
  try:
   observed=EXT();returned=w.DWORD()
   if not k.QueryInformationJobObject(job,9,ctypes.byref(observed),ctypes.sizeof(observed),ctypes.byref(returned)):raise ctypes.WinError(ctypes.get_last_error())
   assert returned.value==ctypes.sizeof(observed), 'job memory query length mismatch'
   rec['job_memory_observed']=dict(peak_process_bytes=observed.PeakProcess,peak_job_bytes=observed.PeakJob,limit_bytes=observed.JobMemory,limit_flags=observed.Basic.Flags)
  except BaseException as e:rec['job_memory_query_error']=repr(e)
  try:
   if hp is not None and _winapi.GetExitCodeProcess(hp)==259:_winapi.TerminateProcess(hp,125)
  except BaseException as e:cleanup_errors.append('terminate root: '+repr(e))
  finally:
   try:
    if ht is not None:_winapi.CloseHandle(ht)
   except BaseException as e:cleanup_errors.append('close thread: '+repr(e))
   finally:
    try:
     if hp is not None:_winapi.CloseHandle(hp)
    except BaseException as e:cleanup_errors.append('close process: '+repr(e))
    finally:
     try:
      if not k.CloseHandle(job):raise ctypes.WinError(ctypes.get_last_error())
     except BaseException as e:cleanup_errors.append('close owned job: '+repr(e))
     finally:
      rec['cleanup_errors']=cleanup_errors;rec['finished_utc']=utc();records.append(rec)
      (root/(label+'-result.json')).write_text(json.dumps(rec,indent=2)+'\n')
 assert rec.get('returncode')==0 and not rec.get('timed_out') and not rec['cleanup_errors'] and 'job_memory_query_error' not in rec,label

def build():
 pins=json.loads((root/'codex-build-cap95-20260913-pins.json').read_text())
 for rel,h in pins['files'].items():assert sha(root/rel)==h,rel
 assert sha(root/'source/codex/codex-rs/arg0/src/lib.rs')==pins['arg0_patched_sha256']
 assert sha(root/'sysroot/lib/rustlib/src/rust/library/std/src/sys/fs/windows.rs')=='370abe5e4236878194a6e5c5bf4d11366a1b3ed23dd8235c6852ee7e0904f3f4'
 for f in json.loads((root/'v8/manifest.json').read_text()):assert sha(root/'v8'/f['file'])==f['sha256']
 env=json.loads((root/'codex-build-cap95-20260913-environment.json').read_text())
 guard['health']('preflight')
 cache=Path(env['CARGO_HOME']);assert cache==Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/c2-734b-20260913') and cache.is_dir()
 for ancestor in cache.parents:assert not (ancestor.lstat().st_file_attributes & 0x400),str(ancestor)
 assert not (cache.lstat().st_file_attributes & 0x400)
 owner_script="$ErrorActionPreference='Stop';$p='"+str(cache)+"';$o=(Get-Acl -LiteralPath $p).GetOwner([System.Security.Principal.SecurityIdentifier]).Value;$c=[System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value;if($o -ne $c){throw 'private cache owner mismatch'};@{owner_sid=$o;caller_sid=$c;path=$p;owner_matches=$true}|ConvertTo-Json"
 owner=subprocess.run(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-Command',owner_script],env=env,cwd='C:/',capture_output=True,timeout=15)
 (root/'codex-cap95-20260913-cache-owner.stdout').write_bytes(owner.stdout);(root/'codex-cap95-20260913-cache-owner.stderr').write_bytes(owner.stderr)
 assert owner.returncode==0 and json.loads(owner.stdout)['owner_matches'] is True
 for name in ['HOME','USERPROFILE','APPDATA','LOCALAPPDATA','TEMP','TMP','CARGO_HOME','CARGO_TARGET_DIR']:
  path=Path(env[name])
  if name=='CARGO_HOME':
   assert path==Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/c2-734b-20260913') and path.is_dir()
   assert not (path.lstat().st_file_attributes & 0x400), 'cache reparse point'
  else:assert path.is_relative_to(root)
  path.mkdir(parents=True,exist_ok=True)
 cargo=str(root/'sysroot/bin/cargo.exe');workspace=root/'source/codex/codex-rs'
 args=[cargo,'build','--locked','--manifest-path',str(workspace/'Cargo.toml'),'--config',str(workspace/'.cargo/config.toml'),'--target','x86_64-pc-windows-msvc','--release','--timings','-j','1','--bin','codex','-Z','build-std=core,alloc,std,proc_macro,panic_unwind']
 bounded('codex-build-cap95-20260913',args,env,timeout=5400)
 exe=root/'target/codex-short-20260913/x86_64-pc-windows-msvc/release/codex.exe';assert exe.is_file()
 return dict(path=str(exe),bytes=exe.stat().st_size,sha256=sha(exe),executed=False)
if __name__=='__main__':
 with (root/'codex-build-cap95-20260913-once.json').open('x') as f:json.dump({'started_utc':utc()},f)
 result={}
 try:result.update(output=build(),build_passed=True)
 except BaseException as e:result.update(build_passed=False,error=repr(e))
 finally:
  try:result['postflight']=guard['health']('postflight')
  except BaseException as e:result['postflight_error']=repr(e)
  try:
   proc=subprocess.run(['C:/Windows/System32/schtasks.exe','/Change','/TN','OMS GPT Private Runtime Build 734bbdfad4a9 cap95 20260913','/DISABLE'],cwd='C:/',env=json.loads((root/'private-build-environment.json').read_text()),capture_output=True,timeout=10)
   (root/'codex-cap95-20260913-task-disable.stdout').write_bytes(proc.stdout);(root/'codex-cap95-20260913-task-disable.stderr').write_bytes(proc.stderr);result['task_disable_returncode']=proc.returncode
  except BaseException as e:result['task_disable_error']=repr(e)
  result['finished_utc']=utc();(root/'codex-build-cap95-20260913-summary.json').write_text(json.dumps(result,indent=2)+'\n')
  (root/'codex-build-cap95-20260913-progress.json').write_text(json.dumps(dict(state='finished',**result))+'\n')
