# LPAC retest: proven defects and minimal correction

First executed probe SHA256:
`f51e6e4369b10f35385abb2c5b94904dd09892eeb782d34778e6a19aaec45010`.
Its retained native result stopped at `caller`, with ProfileCreated=false and
native ProcessId=0. C# compiled; LPAC/profile creation was never reached.
The original evidence directory remains immutable.

O's `token-query.stdout` proves both the original and immediately captured
size queries returned false/error24/Needed4. Direct DWORD queries20/12/29 returned
true/Needed4. Their LastError24 is stale success-call state, not failure.
The exact executed query source SHA256 is
`7c2247fb93136726e6ccedb5fb45447e170158be076b47b474f0d13f021087c2`.
The current caller was elevated/session0; this is API behavior proof only.

Fix: scalar classes use fixed four-byte buffers, require BOOL success and
returned length4, and retain actual BOOL/error/length on failure. Capability
count comes from a separate bounded variable TOKEN_GROUPS query. AppContainer
SID remains a bounded structure query. The size stage accepts only24/122 with a
valid bounded length; the second read must succeed and fit the allocation.

O's `ledger-query.stdout` separately proves the old wrapped ConvertFrom-Json
pipeline produced one Object[] item and Object[] PID. Assignment before array
normalization produces two PSCustomObject records with Int32 PIDs22308/18608.
Fix: deserialize first, normalize second, then validate scalar positive PID,
executable name and exact UTC roundtrip start time before process lookup/cleanup.

Fresh script, stage, no-trigger task and profile are pinned in stage.json.
Original task/profile names are not reused. No LPAC retest has been performed by
the preparing agent. O owns review, native parsing and the single new launch.
The original outer preservation flag is false because cleanup failed; the inner
check and later independent reconciliation established unchanged Hub state and
no remaining diagnostic wrapper processes. Do not relabel the original run as a
passing outer check or LPAC acceptance.
