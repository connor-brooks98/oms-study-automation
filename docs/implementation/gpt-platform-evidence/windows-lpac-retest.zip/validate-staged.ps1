$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-b3cbbcf8ca2b';$files=@{
  'probe-windows-lpac.ps1'='eb113b2ae7e5d002bb6c58664c3cbe193c6cc20e408f7d7f753e9a2b55783f6d'
  'probe-interactive.ps1'='dfd542206d78555d41bb08072579891c73a4f18f79ebb5508391e5d4123a22d6'
  'run-lpac-task.ps1'='e55055fac558e7074731fa4a092bc651314c2d291faca8a33b6355bd458df08e'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
