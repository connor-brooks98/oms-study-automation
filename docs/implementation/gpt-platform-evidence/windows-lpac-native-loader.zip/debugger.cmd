.echo OMS_NATIVE_LOADER_BEGIN
.symopt+ 0x80000000
.catch { .reload /f ntdll.dll; lmv m ntdll; dt ntdll!_PEB NtGlobalFlag; !gflag }
sxe -c "sxe -c \"$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-213490c1ead3/enable-loader.cmd\" ld:ntdll.dll;g" cpr:cmd.exe
sxe -c ".lastevent;g" ibp
sxe -c ".exr -1;kb;gn" -c2 ".exr -1;kb;gn" 0xc0000142
sxn -c ".lastevent" epr
g
