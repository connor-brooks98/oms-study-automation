.lastevent
.catch { .reload /f ntdll.dll; lmv m ntdll; !gflag; !gflag +sls; !gflag }
g
