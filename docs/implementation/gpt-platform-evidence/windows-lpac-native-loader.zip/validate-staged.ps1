$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-213490c1ead3';$files=@{
  'probe-windows-lpac.ps1'='e0f721e87a521cedb8100bd682badee0c8220082c372cb02d69e1174a4a05123'
  'probe-interactive.ps1'='6f0926a3cf6545c6ade976a25237cd515039a28ec3cd287f15e554b2d9e96434'
  'run-lpac-task.ps1'='0fb2507591cbaffba30b6e4fb44f46ebc6821e7d8fff59b92bd21b04df18b20a'
}
if((Get-FileHash -LiteralPath (Join-Path $root 'debugger.cmd') -Algorithm SHA256).Hash.ToLower() -ne 'a927dc798ce58252fcc77ebf2ff966a0b1bc803662ea0317dfc77138f176098d'){throw 'debugger command staged hash mismatch'};$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
