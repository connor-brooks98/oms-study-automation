$ErrorActionPreference='Stop'
$os=Get-CimInstance Win32_OperatingSystem
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
@{utc=(Get-Date).ToUniversalTime().ToString('o');os=@{total_physical_kib=$os.TotalVisibleMemorySize;free_physical_kib=$os.FreePhysicalMemory;total_virtual_kib=$os.TotalVirtualMemorySize;free_virtual_kib=$os.FreeVirtualMemory};memory=$m | Select-Object AvailableBytes,CommittedBytes,CommitLimit,PercentCommittedBytesInUse;pagefiles=@(Get-CimInstance Win32_PageFileUsage | Select-Object AllocatedBaseSize,CurrentUsage,PeakUsage)} | ConvertTo-Json -Depth 5
