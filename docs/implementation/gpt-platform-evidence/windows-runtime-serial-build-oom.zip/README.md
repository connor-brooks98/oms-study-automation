Serial compile discriminator after proven concurrent compiler OOM. Only job concurrency changes2→1; same8GiB/90min/BelowNormal cap and pinned source/compiler/std/arg0/lock/release flags. A documented QueryInformationJobObject(ExtendedLimitInformation) records peak process/job memory before unconditional owned-job close. Query failure is retained and fails acceptance without skipping cleanup.

Reuse the Cargo-managed short c2 cache and target/codex-short-20260913; previous full stderr/result/summary are retained locally and pinned remotely. No application output exists/executes. All fresh task/once/log/owner/health receipts use serial-20260913 identity. Existing cache remains owner-checked and reparse-rejected. No policy/system/config mutations.

Exact command is the preceding --locked release build with -j1 and CARGO_BUILD_JOBS=1. Source, external dependency graph, std patch, arg0 patch, V8 artifacts, linker and all resource/preservation controls remain unchanged. Stage→verify→launch only after independent review.

Microsoft API: https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-queryinformationjobobject and https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information
