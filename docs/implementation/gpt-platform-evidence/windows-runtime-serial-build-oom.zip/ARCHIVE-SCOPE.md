# Completed serial Windows build failure

This snapshot preserves the completed one-job build: earlier failing crates compiled successfully, but final codex CLI compilation failed with LLVM OOM. Native job-memory peak reached the configured 8 GiB cap. All 121 health guards and independent cleanup/preservation checks passed. Includes the read-only post-failure host-memory evidence; it is not fresh launch authorization. Excludes any successor build and native Codex acceptance. No final executable was produced.
