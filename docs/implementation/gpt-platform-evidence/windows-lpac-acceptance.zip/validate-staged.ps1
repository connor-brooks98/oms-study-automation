$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-6ea739f1a574';$files=@{
  'probe-windows-lpac.ps1'='f51e6e4369b10f35385abb2c5b94904dd09892eeb782d34778e6a19aaec45010'
  'probe-interactive.ps1'='998e54a732d905f45114dd3f3e6654b73e35b5631350b0d3fb1927f155c9316d'
  'run-lpac-task.ps1'='a81132de85cf197a9a8843e5c3b600e050f148bd3b03769739724653a32b5b3b'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
