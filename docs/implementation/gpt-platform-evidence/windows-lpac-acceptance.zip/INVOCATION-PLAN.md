# LPAC acceptance invocation plan

Prepared artifacts only. The implementation agent made no remote staging,
Windows parsing, task registration or native launch calls. O owns staging,
independent review, execution and reconciliation. Keep O's raw staging/parsing
outputs alongside these artifacts; do not overwrite them.

The exact task, stage, profile and three script hashes are in `stage.json`.
The profile and fixture are never reused. The native probe SHA remains
`f51e6e4369b10f35385abb2c5b94904dd09892eeb782d34778e6a19aaec45010`.

1. Review the pinned source, `probe-interactive.ps1`, `run-lpac-task.ps1`,
   `invocation.ps1` and `launch.py`. Recheck the three hashes against stage.json.
2. In the unique remote stage, place only the three reviewed probe/inner/outer
   scripts. Run `validate-staged.ps1` through the existing SSH EncodedCommand
   pattern. It only checks SHA256 and PowerShell parsing; it does not compile C#,
   register tasks or create an AppContainer. Any changed script needs a new
   retained parsing receipt and matching dependent hashes before launch.
3. After approval of those exact bytes, run once from this local evidence folder:

   ```sh
   python3 launch.py
   ```

   This executes `invocation.ps1` through SSH. The outer creates exactly one
   no-trigger conbr/Interactive/Limited task and starts it once. A launch record
   is exclusively created before dispatch; never delete it to retry. The inner
   verifies conbr/session1/non-admin, cmd and PowerShell hashes, then launches the
   one LPAC probe in a separately captured PowerShell process. It retains raw
   stdout/stderr, including compilation failure output. No Codex/provider call
   occurs.
4. Collect evidence using `collect-evidence.ps1` via the same EncodedCommand
   pattern, even after a failed task or ambiguous SSH return. It reads only the
   fixed new-fixture artifacts and task state. Preserve its raw stdout/stderr
   before decoding the JSON/base64 items into a new local `native` directory.
   No automatic retry or relaunch follows a collection result.

## Limits and preservation

- Probe-owned cmd wait: 15 seconds, then 5 seconds for termination/reaping.
- Inner wrapper: 60 seconds before cleanup of only recorded owned processes.
  Its explicit process handle also covers failure before ledger publication.
- Outer task execution limit: 110 seconds; outer watcher deadline: 115 seconds.
  SSH transport timeout: 145 seconds. A transport timeout stops only local SSH;
  it does not claim the remote task stopped or completed.
- Ownership adoption requires a parent present in the same CIM snapshot with
  matching creation time, and a child no older than that parent. Cleanup checks
  the retained PID, name and exact process start time before killing that owned
  process. A mismatch refuses the kill and reports failure.
- The outer independently attempts task stop/disable, owned cleanup and health
  postflight. Task API failure does not skip later checks. A postflight read
  failure produces an error-bearing outer-postflight.json and fails acceptance.
- Both wrappers bind Hub revision f487c6229b91d2b1ac11729e465561f6c1ffe997,
  tree a9f7cc7f9c03040cb63ccea3ef05b70add443e6a, schema31, listener PID8268 and
  three healthy workers with unchanged start counts. Snapshots include existing
  Codex/Python processes plus cmd/csc/compiler activity; new or missing observed
  processes fail preservation. No unrelated process kill is permitted.

A passing scheduled-task result is insufficient alone: require inner passed,
probe passed, both postflights preserved, no residual owned process and a disabled
new task. Retain the fresh AppContainer profile and all artifacts. A canary pass
is only LPAC feasibility, not Codex isolation/login/provider/activation proof.
