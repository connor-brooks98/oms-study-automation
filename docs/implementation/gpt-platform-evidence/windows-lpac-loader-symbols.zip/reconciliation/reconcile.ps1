$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$decoded=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('W3sic3RhcnRfdXRjIjogIjIwMjYtMDktMTJUMjE6MTE6NTEuMjIzMjg2NloiLCAicGlkIjogMTU0MDQsICJuYW1lIjogImNkYi5leGUiLCAiY3JlYXRpb25fdXRjIjogIjIwMjYtMDktMTJUMjE6MTE6NTEuMjIzMjg2MFoiLCAicGFyZW50X3BpZCI6IDIzODUyfSwgeyJzdGFydF91dGMiOiAiMjAyNi0wOS0xMlQyMToxMTo1MS40MzkwNTU4WiIsICJwaWQiOiAxODg5MiwgIm5hbWUiOiAiY29uaG9zdC5leGUiLCAiY3JlYXRpb25fdXRjIjogIjIwMjYtMDktMTJUMjE6MTE6NTEuNDM5MDU1MFoiLCAicGFyZW50X3BpZCI6IDE1NDA0fSwgeyJzdGFydF91dGMiOiAiMjAyNi0wOS0xMlQyMToxMTo1MS42MTAyODI0WiIsICJwaWQiOiAxMzIzMiwgIm5hbWUiOiAicG93ZXJzaGVsbC5leGUiLCAiY3JlYXRpb25fdXRjIjogIjIwMjYtMDktMTJUMjE6MTE6NTEuNjEwMjgyMFoiLCAicGFyZW50X3BpZCI6IDE1NDA0fSwgeyJzdGFydF91dGMiOiAiMjAyNi0wOS0xMlQyMToxMTo1NC4zMDA1NDkyWiIsICJwaWQiOiA3MTM2LCAibmFtZSI6ICJjc2MuZXhlIiwgImNyZWF0aW9uX3V0YyI6ICIyMDI2LTA5LTEyVDIxOjExOjU0LjMwMDU0OTBaIiwgInBhcmVudF9waWQiOiAxMzIzMn1d')) | ConvertFrom-Json
$expected=@($decoded)
$snapshot=@(Get-CimInstance Win32_Process)
$observed=(Get-Date).ToUniversalTime().ToString('o')
$records=@()
foreach($record in $expected){
  $matches=@($snapshot | Where-Object {$_.ProcessId -eq [int]$record.pid})
  $current=@($matches | ForEach-Object {@{pid=[int]$_.ProcessId;name=$_.Name;creation_utc=$_.CreationDate.ToUniversalTime().ToString('o');parent_pid=[int]$_.ParentProcessId}})
  $records+=@{expected=$record;pid_present=($matches.Count -gt 0);current=$current}
}
$health=$null;$healthError=$null;$listeners=@();$listenerError=$null;$taskState=$null;$taskError=$null
try{$health=Invoke-RestMethod -TimeoutSec 5 http://127.0.0.1:8765/health}catch{$healthError=$_.Exception.ToString()}
try{$listeners=@(Get-NetTCPConnection -LocalPort 8765 -State Listen | Select-Object LocalAddress,LocalPort,OwningProcess)}catch{$listenerError=$_.Exception.ToString()}
try{$task=Get-ScheduledTask -TaskName 'OMS GPT LPAC Loader Symbols b7d3cac81661';$taskState=[string]$task.State}catch{$taskError=$_.Exception.ToString()}
$hubProcess=@($snapshot | Where-Object {$_.ProcessId -eq 8268} | ForEach-Object {@{pid=[int]$_.ProcessId;name=$_.Name;creation_utc=$_.CreationDate.ToUniversalTime().ToString('o');parent_pid=[int]$_.ParentProcessId}})
@{snapshot_utc=$observed;finished_utc=(Get-Date).ToUniversalTime().ToString('o');owned_records=$records;all_owned_pids_absent=(@($records | Where-Object {$_.pid_present}).Count -eq 0);health=$health;health_error=$healthError;listeners=$listeners;listener_error=$listenerError;hub_process=$hubProcess;task_state=$taskState;task_error=$taskError} | ConvertTo-Json -Depth 12
