.lastevent
.reload /f ntdll.dll
.if (@$ptrsize != 8) { .echo OMS_LOADER_WRONG_ARCH; q }
.if (@$peb == 0) { .echo OMS_LOADER_MISSING_PEB; q }
r $t0 = 0
r $t0 = @@c++((unsigned __int64)&(((ntdll!_PEB*)@$peb)->NtGlobalFlag))
.if ((@$t0 - @$peb) != 0xbc) { .echo OMS_LOADER_FIELD_LOOKUP_FAILED; q }
r $t3 = 0
r $t3 = @@c++(sizeof(((ntdll!_PEB*)0)->NtGlobalFlag))
.if (@$t3 != 4) { .echo OMS_LOADER_FIELD_SIZE_FAILED; q }
.if ($vvalid(@$t0,4) == 0) { .echo OMS_LOADER_FIELD_UNREADABLE; q }
r $t1 = dwo(@$t0)
ed @$t0 (@$t1 | 2)
r $t2 = dwo(@$t0)
.if (@$t2 != (@$t1 | 2)) { .echo OMS_LOADER_FLAG_WRITE_FAILED; q }
.printf "OMS_LOADER_FLAG pid=%x address=%p before=%x after=%x\n", @$tpid, @$t0, @$t1, @$t2
g
