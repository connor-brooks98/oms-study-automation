.echo OMS_LOADER_SYMBOL_TRACE_BEGIN
sxe -c "$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-b7d3cac81661/enable-loader.cmd" ld:ntdll.dll
sxe -c ".lastevent;g" cpr
sxe -c ".lastevent;g" ibp
sxe -c ".exr -1;kb;gn" -c2 ".exr -1;kb;gn" 0xc0000142
sxn -c ".lastevent" epr
g
