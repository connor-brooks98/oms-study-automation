Fresh resume after the user reported disabling Smart App Control. Read-only preflight at 2026-09-13T13:24:38.9479483Z confirms the two SAC policies are not enforced; exact live Hub identity and both old disabled tasks are preserved. Other system policies remain active. Any new policy block stops the build.

This preparation mechanically derives from the independently reviewed consumed v2 build. It retains the same source/tool/std/arg0/locked dependency pins, private caches and environment, and official Cargo config. New target directory target/codex-resume-20260913 preserves all previous target bytes, including the blocked parking_lot_core helper. All log, result, health, task, once, progress and disable filenames are fresh. Task: OMS GPT Private Runtime Build 734bbdfad4a9 resume 20260913.

Exact Cargo invocation expands the existing private root C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9:

    sysroot/bin/cargo.exe build --locked --manifest-path source/codex/codex-rs/Cargo.toml --config source/codex/codex-rs/.cargo/config.toml --target x86_64-pc-windows-msvc --release --timings -j 2 --bin codex -Z build-std=core,alloc,std,proc_macro,panic_unwind

Cwd C:/; explicit absolute paths, BelowNormal, two jobs, 8 GiB owned job assigned before resume, kill-on-close with unconditional cleanup, 5400-second build bound, 92-minute Limited Interactive task, unchanged recurring health guard. Driver hashes source inputs before compilation. Output is not executed. Launcher is one-shot and does not replay consumed identities. Stage and launch only after independent review.
