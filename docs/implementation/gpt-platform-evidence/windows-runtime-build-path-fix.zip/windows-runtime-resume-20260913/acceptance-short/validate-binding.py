"""Local-only reproducible binder check in a disposable copy; no Windows actions."""
from pathlib import Path
import base64
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
before = sorted(path.name for path in root.glob("bound-*"))
manifest = json.loads((root / "preparation.json").read_text())
pin = "a" * 64  # Dummy test value, never a runtime artifact claim.
with tempfile.TemporaryDirectory(prefix="oms-lpac-binding-check-") as directory:
    copy = Path(directory)
    for name in ["preparation.json", "bind-artifact.py", *manifest["template_hashes"]]:
        target = copy / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / name, target)
    command = [sys.executable, str(copy / "bind-artifact.py"), "--runtime-sha256", pin]
    first = subprocess.run(command, capture_output=True, text=True, timeout=10)
    assert first.returncode == 0, first.stderr
    bound = copy / ("bound-" + pin[:16])
    for mode in ("version", "initialize"):
        stage = json.loads((bound / mode / "stage.json").read_text())
        assert stage["binding_finalized"] and stage["prepared_only"] and stage["executable_sha256"] == pin
        for name, expected in stage["files"].items():
            text = (bound / mode / name).read_text()
            assert hashlib.sha256(text.encode()).hexdigest() == expected
            assert re.search(r"__[A-Z_0-9]+__", text) is None
        outer = (bound / mode / "run-lpac-task.ps1").read_text()
        encoded = re.search(r"-EncodedCommand ([A-Za-z0-9+/=]+)", outer).group(1)
        decoded = base64.b64decode(encoded).decode("utf-16-le")
        assert decoded + "\n" == (bound / mode / "scheduled-action.decoded.txt").read_text()
        assert stage["inner_sha256"] in decoded
        assert stage["script_sha256"] in (bound / mode / "probe-interactive.ps1").read_text()
    snapshot = {str(path.relative_to(bound)): hashlib.sha256(path.read_bytes()).hexdigest() for path in bound.rglob("*") if path.is_file()}
    second = subprocess.run(command, capture_output=True, text=True, timeout=10)
    assert second.returncode != 0 and "do not overwrite or reuse test identities" in second.stderr
    assert snapshot == {str(path.relative_to(bound)): hashlib.sha256(path.read_bytes()).hexdigest() for path in bound.rglob("*") if path.is_file()}
assert before == sorted(path.name for path in root.glob("bound-*"))
print(json.dumps({"status": "passed", "dummy_hash_only": True, "temporary_copy_removed": True, "modes": ["version", "initialize"], "all_hash_layers_match": True, "decoded_action_matches": True, "unresolved_tokens_absent": True, "second_bind_refused_overwrite": True, "second_bind_preserved_all_files": True, "real_preparation_bound_directories_unchanged": True, "windows_actions": False, "runtime_or_arg0_tests_run": False}, indent=2))
