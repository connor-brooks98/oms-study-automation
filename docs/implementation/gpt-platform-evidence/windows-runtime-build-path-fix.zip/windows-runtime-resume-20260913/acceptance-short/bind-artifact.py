"""Bind the fixed two-probe preparation to one completed build hash. Local file work only."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import re

parser = argparse.ArgumentParser()
parser.add_argument("--runtime-sha256", required=True)
args = parser.parse_args()
pin = args.runtime_sha256.lower()
if not re.fullmatch(r"[0-9a-f]{64}", pin) or pin == "0" * 64:
    parser.error("expected a nonzero exact SHA-256 from the completed build receipt")
root = Path(__file__).resolve().parent
manifest = json.loads((root / "preparation.json").read_text())
for name, expected in manifest["template_hashes"].items():
    if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
        raise SystemExit("Preparation drift: " + name)
bound = root / ("bound-" + pin[:16])
if bound.exists():
    raise SystemExit("Bound evidence exists; do not overwrite or reuse test identities")
prepared = {}
sha = lambda text: hashlib.sha256(text.encode()).hexdigest()
for mode in ("version", "initialize"):
    stage = json.loads((root / mode / "stage.template.json").read_text())
    tokens = {"__BINDING_FINALIZED__": "true", "__RUNTIME_SHA256__": pin}
    def render(name):
        text = (root / mode / (name + ".template")).read_text()
        for old, new in tokens.items():
            text = text.replace(old, new)
        if re.search(r"__[A-Z_0-9]+__", text):
            raise SystemExit("Unresolved binding: " + name)
        return text
    probe = render("probe-windows-lpac.ps1")
    tokens["__PROBE_SHA256__"] = sha(probe)
    inner = render("probe-interactive.ps1")
    tokens["__INNER_SHA256__"] = sha(inner)
    text = "$p='" + stage["remote_root"] + "/probe-interactive.ps1'; if((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower() -ne '" + sha(inner) + "'){throw 'inner hash mismatch'}; & ([scriptblock]::Create([IO.File]::ReadAllText($p)))"
    tokens["__INNER_ENCODED_COMMAND__"] = base64.b64encode(text.encode("utf-16-le")).decode()
    outer = render("run-lpac-task.ps1")
    tokens["__OUTER_SHA256__"] = sha(outer)
    scripts = {"probe-windows-lpac.ps1": probe, "probe-interactive.ps1": inner, "run-lpac-task.ps1": outer}
    for name in ("stage-create.ps1", "validate-staged.ps1", "collect-evidence.ps1", "independent-console.ps1", "invocation.ps1"):
        scripts[name] = render(name)
    stage.update(binding_finalized=True, executable_sha256=pin, script_sha256=sha(probe), inner_sha256=sha(inner), outer_sha256=sha(outer), files={name: sha(body) for name, body in scripts.items()})
    stage["prepared_only"] = True  # Binding does not stage or execute anything.
    prepared.update({mode + "/" + name: body for name, body in scripts.items()})
    prepared[mode + "/stage.json"] = json.dumps(stage, indent=2) + "\n"
    prepared[mode + "/scheduled-action.decoded.txt"] = text + "\n"
bound.mkdir()
for name, body in prepared.items():
    path = bound / name
    path.parent.mkdir(exist_ok=True)
    with path.open("x") as stream:
        stream.write(body)
print(json.dumps({"prepared_only": True, "runtime_sha256": pin, "bound_directory": str(bound), "windows_actions_performed": False}, indent=2))
