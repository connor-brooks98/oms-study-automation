from pathlib import Path
import json,hashlib,datetime
root=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9')
crate=root/'cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/aws-lc-sys-0.39.0'
names=['aws-lc/third_party/jitterentropy/jitterentropy-library/jitterentropy.h','aws-lc/crypto/fipsmodule/rand/entropy/tree_drbg_jitter_entropy.c','aws-lc/crypto/fipsmodule/bcm.c']
rows=[]
for n in names:
 f=crate/n
 rows.append(dict(path=str(f),chars=len(str(f)),exists=f.exists(),bytes=f.stat().st_size if f.exists() else None,sha256=hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None))
print(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=rows),indent=2))
