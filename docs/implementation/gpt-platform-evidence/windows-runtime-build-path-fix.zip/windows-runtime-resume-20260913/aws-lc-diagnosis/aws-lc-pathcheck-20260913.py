"""Compare CL syntax checks of byte-identical AWS-LC source paths; no output execution."""
from pathlib import Path
import shutil,ctypes,ctypes.wintypes as w,json,hashlib,os,subprocess,msvcrt,_winapi,datetime,time
root=Path(__file__).resolve().parent
k=ctypes.WinDLL('kernel32',use_last_error=True)
class BASIC(ctypes.Structure):_fields_=[('ProcessTime',ctypes.c_int64),('JobTime',ctypes.c_int64),('Flags',w.DWORD),('Min',ctypes.c_size_t),('Max',ctypes.c_size_t),('Active',w.DWORD),('Affinity',ctypes.c_size_t),('Priority',w.DWORD),('Scheduling',w.DWORD)]
class IO(ctypes.Structure):_fields_=[(n,ctypes.c_uint64) for n in ['ReadOp','WriteOp','OtherOp','ReadBytes','WriteBytes','OtherBytes']]
class EXT(ctypes.Structure):_fields_=[('Basic',BASIC),('Io',IO),('ProcessMemory',ctypes.c_size_t),('JobMemory',ctypes.c_size_t),('PeakProcess',ctypes.c_size_t),('PeakJob',ctypes.c_size_t)]
k.CreateJobObjectW.argtypes=[ctypes.c_void_p,w.LPCWSTR];k.CreateJobObjectW.restype=w.HANDLE
k.SetInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD];k.SetInformationJobObject.restype=w.BOOL
k.AssignProcessToJobObject.argtypes=[w.HANDLE,w.HANDLE];k.AssignProcessToJobObject.restype=w.BOOL
k.TerminateJobObject.argtypes=[w.HANDLE,w.UINT];k.TerminateJobObject.restype=w.BOOL
k.ResumeThread.argtypes=[w.HANDLE];k.ResumeThread.restype=w.DWORD
k.CloseHandle.argtypes=[w.HANDLE];k.CloseHandle.restype=w.BOOL
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
guard=__import__('runpy').run_path(str(root/'aws-lc-pathcheck-20260913-guard.py'))
records=[]
def bounded(label,args,env,cwd='C:/',timeout=5400):
 rec=dict(label=label,argv=args,cwd=cwd,environment=env,started_utc=utc(),timeout_seconds=timeout,priority='BELOW_NORMAL_PRIORITY_CLASS',kill_on_close_job=True,job_memory_limit_bytes=8*1024**3)
 (root/(label+'-invocation.json')).write_text(json.dumps(rec,indent=2)+'\n')
 job=k.CreateJobObjectW(None,None)
 if not job:raise ctypes.WinError(ctypes.get_last_error())
 hp=ht=None
 try:
  info=EXT();info.Basic.Flags=0x2200;info.JobMemory=8*1024**3
  if not k.SetInformationJobObject(job,9,ctypes.byref(info),ctypes.sizeof(info)):raise ctypes.WinError(ctypes.get_last_error())
  with (root/(label+'.stdout')).open('xb') as out,(root/(label+'.stderr')).open('xb') as err,open(os.devnull,'rb') as inp:
   handles=[msvcrt.get_osfhandle(f.fileno()) for f in [inp,out,err]]
   for h in handles:os.set_handle_inheritable(h,True)
   si=subprocess.STARTUPINFO();si.dwFlags=subprocess.STARTF_USESTDHANDLES;si.hStdInput,si.hStdOutput,si.hStdError=handles;si.lpAttributeList={'handle_list':handles}
   try:hp,ht,pid,tid=_winapi.CreateProcess(args[0],subprocess.list2cmdline(args),None,None,True,0x00004004,env,cwd,si)
   finally:
    for h in handles:os.set_handle_inheritable(h,False)
   rec.update(pid=pid,tid=tid)
   if not k.AssignProcessToJobObject(job,int(hp)):raise ctypes.WinError(ctypes.get_last_error())
   if k.ResumeThread(int(ht))==0xffffffff:raise ctypes.WinError(ctypes.get_last_error())
   (root/'aws-lc-pathcheck-20260913-progress.json').write_text(json.dumps(dict(state='running',pid=pid,started_utc=rec['started_utc']))+'\n')
   deadline=time.monotonic()+timeout;next_health=time.monotonic()
   while True:
    remaining=deadline-time.monotonic()
    if remaining<=0:status=258;break
    status=_winapi.WaitForSingleObject(hp,min(5000,max(1,int(remaining*1000))))
    if status!=258:break
    if time.monotonic()>=next_health:
     guard['health']('during');next_health=time.monotonic()+30
   rec['timed_out']=status==258
   if rec['timed_out']:
    if not k.TerminateJobObject(job,124):raise ctypes.WinError(ctypes.get_last_error())
    _winapi.WaitForSingleObject(hp,5000)
   rec['returncode']=_winapi.GetExitCodeProcess(hp)
 finally:
  cleanup_errors=[]
  try:
   if hp is not None and _winapi.GetExitCodeProcess(hp)==259:_winapi.TerminateProcess(hp,125)
  except BaseException as e:cleanup_errors.append('terminate root: '+repr(e))
  finally:
   try:
    if ht is not None:_winapi.CloseHandle(ht)
   except BaseException as e:cleanup_errors.append('close thread: '+repr(e))
   finally:
    try:
     if hp is not None:_winapi.CloseHandle(hp)
    except BaseException as e:cleanup_errors.append('close process: '+repr(e))
    finally:
     try:
      if not k.CloseHandle(job):raise ctypes.WinError(ctypes.get_last_error())
     except BaseException as e:cleanup_errors.append('close owned job: '+repr(e))
     finally:
      rec['cleanup_errors']=cleanup_errors;rec['finished_utc']=utc();records.append(rec)
      (root/(label+'-result.json')).write_text(json.dumps(rec,indent=2)+'\n')
 assert not rec.get('timed_out') and not rec['cleanup_errors'],label
 return rec


GUARD_SHA='6536cbaa8daa912b392660cb79512d8744538e0ee7979226848b5c800a0857cc'
ARGV_SHA='60dd7f29311d369cb9cbfc685a2d869f61d864a4d723300ec987b53b7a4a64e0'
ENV_SHA='fd8250bc4abbccd1f2173dc92aabcbcbd8327714033a80d2f145292d1fe7cdec'
CL_SHA='88c8344236a27a6e727e0a8edc49aaa2690bdc7a9464b9d18cc7abe70a9f1c0d'

def compare():
 env=json.loads((root/'codex-build-resume-20260913-environment.json').read_text())
 assert sha(root/'aws-lc-pathcheck-20260913-guard.py')==GUARD_SHA
 assert sha(root/'bcm-original-argv.json')==ARGV_SHA
 assert sha(root/'codex-build-resume-20260913-environment.json')==ENV_SHA
 args=json.loads((root/'bcm-original-argv.json').read_text());assert sha(Path(args[0]))==CL_SHA
 guard['health']('preflight')
 original=root/'cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/aws-lc-sys-0.39.0'
 short=root/'hdr-check-20260913'/'s';assert not short.parent.exists();short.parent.mkdir()
 shutil.copytree(original,short)
 inputs={x.relative_to(original).as_posix():sha(x) for x in original.rglob('*') if x.is_file()}
 assert inputs=={x.relative_to(short).as_posix():sha(x) for x in short.rglob('*') if x.is_file()}
 assert inputs['aws-lc/third_party/jitterentropy/jitterentropy-library/jitterentropy.h']=='313dc69cd1596239b01b1819098829735965d9e619636c4aa47e1e7b326e1843'
 (root/'aws-lc-pathcheck-20260913-source-hashes.json').write_text(json.dumps(inputs,indent=2)+'\n')
 # /Zs checks syntax without producing object code. All other compiler options are retained.
 syntax=[x for x in args if not x.startswith('-Fo') and x!='-c']+['/Zs']
 results=[]
 for label,argv in [('long',syntax),('short',[x.replace(str(original),str(short)) for x in syntax])]:
  rec=bounded('aws-lc-pathcheck-20260913-'+label,argv,env,timeout=120);results.append(rec)
 assert results[0]['returncode']!=0
 assert "jitterentropy.h" in (root/'aws-lc-pathcheck-20260913-long.stdout').read_text(errors='replace')
 assert results[1]['returncode']==0
 return dict(comparison_passed=True,source_count=len(inputs),original=str(original),short=str(short))
if __name__=='__main__':
 with (root/'aws-lc-pathcheck-20260913-once.json').open('x') as f:json.dump({'started_utc':utc()},f)
 result={}
 try:result.update(compare())
 except BaseException as e:result.update(comparison_passed=False,error=repr(e))
 finally:
  try:result['postflight']=guard['health']('postflight')
  except BaseException as e:result['postflight_error']=repr(e)
  try:
   proc=subprocess.run(['C:/Windows/System32/schtasks.exe','/Change','/TN','OMS GPT AWS LC Path Check 20260913','/DISABLE'],cwd='C:/',env=json.loads((root/'private-build-environment.json').read_text()),capture_output=True,timeout=10)
   (root/'aws-lc-pathcheck-20260913-disable.stdout').write_bytes(proc.stdout);(root/'aws-lc-pathcheck-20260913-disable.stderr').write_bytes(proc.stderr);result['task_disable_returncode']=proc.returncode
  except BaseException as e:result['task_disable_error']=repr(e)
  result['finished_utc']=utc();(root/'aws-lc-pathcheck-20260913-summary.json').write_text(json.dumps(result,indent=2)+'\n')
