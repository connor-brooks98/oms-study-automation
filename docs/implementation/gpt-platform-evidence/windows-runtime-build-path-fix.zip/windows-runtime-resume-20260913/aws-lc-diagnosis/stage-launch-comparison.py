"""Stage and launch only the reviewed one-shot syntax comparison."""
from pathlib import Path
import base64,json,subprocess,datetime
p=Path(__file__).resolve().parent
root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9'
hashes=json.loads((p/'comparison-hashes.json').read_text())
def run(label,cmd):
 (p/(label+'.command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 with (p/(label+'.stdout')).open('xb') as out,(p/(label+'.stderr')).open('xb') as err:r=subprocess.run(cmd,stdout=out,stderr=err,timeout=60)
 assert r.returncode==0,(label,r.returncode)
def query(label,s):
 run(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','nuc','C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe -B -I -c "import base64;exec(base64.b64decode('+repr(base64.b64encode(s.encode()).decode())+'))"'])
with (p/'comparison-launch-once.json').open('x') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},f)
query('comparison-stage-precheck',f"from pathlib import Path\np=Path({root!r})\nassert all(not (p/n).exists() for n in {list(hashes)!r})\nassert not (p/'hdr-check-20260913').exists()\nprint('fresh')")
run('comparison-stage-upload',['scp','-q',*[str(p/n) for n in hashes],'nuc:'+root+'/'])
query('comparison-stage-verify',f"from pathlib import Path\nimport json,hashlib,ast\np=Path({root!r});expected={hashes!r}\nfor n,h in expected.items():\n assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n\n if n.endswith('.py'):ast.parse((p/n).read_text())\nprint(json.dumps(expected))")
f=root+'/launch-aws-lc-pathcheck-20260913.ps1'
s="$ErrorActionPreference='Stop';$p='"+f+"';if((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower() -ne '"+hashes['launch-aws-lc-pathcheck-20260913.ps1']+"'){throw 'task wrapper hash mismatch'};& ([scriptblock]::Create([IO.File]::ReadAllText($p)))"
run('comparison-task-launch',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','nuc','powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(s.encode('utf-16le')).decode()])
