$ErrorActionPreference='Stop'
$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9'
$name='OMS GPT AWS LC Path Check 20260913'
if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){throw 'fresh build task already exists'}
if(Test-Path -LiteralPath "$root/aws-lc-pathcheck-20260913-once.json"){throw 'build launch already consumed'}
if((Get-FileHash -LiteralPath "$root/aws-lc-pathcheck-20260913.py" -Algorithm SHA256).Hash.ToLower() -ne '575acefff1651e1c5926659bad3f9951cc0c80c7e80ddbf2a47bfb00e26894c1'){throw 'build script hash mismatch'}
$action=New-ScheduledTaskAction -Execute 'C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe' -Argument ('-B -I "'+$root+'/aws-lc-pathcheck-20260913.py"') -WorkingDirectory 'C:/'
$principal=New-ScheduledTaskPrincipal -UserId 'conbr' -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 6) -MultipleInstances IgnoreNew -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$task=New-ScheduledTask -Action $action -Principal $principal -Settings $settings
$null=Register-ScheduledTask -TaskName $name -InputObject $task
Export-ScheduledTask -TaskName $name | Set-Content -Encoding UTF8 "$root/aws-lc-pathcheck-20260913-task.xml"
Start-ScheduledTask -TaskName $name
@{task_name=$name;state=[string](Get-ScheduledTask -TaskName $name).State;script_sha256='575acefff1651e1c5926659bad3f9951cc0c80c7e80ddbf2a47bfb00e26894c1';utc=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json
