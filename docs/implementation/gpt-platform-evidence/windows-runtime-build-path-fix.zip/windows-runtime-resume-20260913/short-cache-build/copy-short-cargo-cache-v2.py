"""Copy only the existing private public Cargo cache to a fresh shorter directory."""
from pathlib import Path
import json,hashlib,shutil,datetime,os
root=Path(__file__).resolve().parent
old=root/'cargo-home';new=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/c-734b-20260913')
# Extended-length syntax is required to inspect already-existing long Cargo git paths.
prefix=chr(92)*2+'?'+chr(92)
old=Path(prefix+str(old));new=Path(prefix+str(new))
def no_reparse(p):
 for x in [p,*p.parents]:
  assert not (x.lstat().st_file_attributes & 0x400),str(x)
no_reparse(old);no_reparse(new.parent);assert not new.exists()
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
inputs={}
for x in old.rglob('*'):
 assert not (x.lstat().st_file_attributes & 0x400),str(x)
 if x.is_file():inputs[x.relative_to(old).as_posix()]={'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()}
shutil.copytree(old,new)
actual={}
for x in new.rglob('*'):
 assert not (x.lstat().st_file_attributes & 0x400),str(x)
 if x.is_file():actual[x.relative_to(new).as_posix()]={'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()}
assert inputs==actual
no_reparse(new)
(root/'codex-short-20260913-cache-files.json').write_text(json.dumps(inputs,indent=2)+'\n')
receipt={'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':str(old),'new':str(new),'files':len(inputs),'bytes':sum(x['bytes'] for x in inputs.values()),'all_bytes_equal':True,'no_reparse_points':True,'original_unchanged':True}
(root/'codex-short-20260913-cache-copy.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
