$ErrorActionPreference='Stop'
$rows=@(@{pid=10108;name='python';ms=1789307750192},@{pid=26296;name='python';ms=1789307750163},@{pid=5980;name='bash';ms=1789307750021},@{pid=5156;name='bash';ms=1789307749942})
$out=@()
foreach($row in $rows){
 $proc=$null
 try {
  try {$proc=[Diagnostics.Process]::GetProcessById([int]$row.pid)} catch [ArgumentException] {$out+=@{pid=$row.pid;result='already gone'};continue}
  $handle=$proc.Handle
  $started=[DateTimeOffset]::new($proc.StartTime.ToUniversalTime()).ToUnixTimeMilliseconds()
  if($started -ne $row.ms -or $proc.ProcessName -ne $row.name){throw 'owned identity mismatch; not terminated'}
  $proc.Kill();if(!$proc.WaitForExit(5000)){throw 'owned process did not exit'}
  $out+=@{pid=$row.pid;started_ms=$started;result='terminated after staging timeout'}
 } catch {$out+=@{pid=$row.pid;error=$_.Exception.Message}}
 finally {if($proc){$proc.Dispose()}}
}
@{utc=(Get-Date).ToUniversalTime().ToString('o');results=$out} | ConvertTo-Json -Depth 4
