from pathlib import Path
import json,hashlib,datetime
name='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/cargo-home/git/checkouts/mxc-2dea3fbc8fb244f2/6cd3d58/src/core/generated/process_security_environment_specification/src/process_security_environment_layout/destination_rule_generated.rs'
name=name.replace('/',chr(92));rows=[]
for kind,n in [('plain',name),('extended',chr(92)*2+'?'+chr(92)+name)]:
 try:
  p=Path(n);st=p.lstat();rows.append(dict(kind=kind,chars=len(n),exists=True,attributes=st.st_file_attributes,bytes=st.st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 except OSError as e:rows.append(dict(kind=kind,chars=len(n),error=str(e),winerror=e.winerror))
print(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),path=name,rows=rows),indent=2))
