$ErrorActionPreference='Stop'
$h=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/health' -TimeoutSec 5
$l=@(Get-NetTCPConnection -State Listen -LocalPort 8765 | Select-Object LocalAddress,OwningProcess)
if($h.status -ne 'ok' -or !$h.database_reachable -or $h.build_revision -ne 'f487c6229b91d2b1ac11729e465561f6c1ffe997' -or $h.build_tree -ne 'a9f7cc7f9c03040cb63ccea3ef05b70add443e6a' -or $h.schema_version -ne 31){throw 'health identity changed'}
if($l.Count -ne 1 -or $l[0].LocalAddress -ne '127.0.0.1' -or $l[0].OwningProcess -ne 8268){throw 'listener changed'}
foreach($entry in $h.workers.PSObject.Properties){$v=$entry.Value;if(!$v.alive -or $v.start_count -ne 1 -or $v.current_error -or $v.recovery_error -or $v.heartbeat_age_seconds -ge 30){throw 'worker unhealthy'}}
@{utc=(Get-Date).ToUniversalTime().ToString('o');passed=$true;health=$h;listeners=$l} | ConvertTo-Json -Depth 6
