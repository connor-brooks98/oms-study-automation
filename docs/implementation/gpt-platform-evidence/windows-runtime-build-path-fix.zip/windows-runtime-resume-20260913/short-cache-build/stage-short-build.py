"""Stage new build files and copy verified private dependency bytes; do not launch."""
from pathlib import Path
import json,base64,subprocess
p=Path(__file__).resolve().parent;root=json.loads((p/'manifest.json').read_text())['remote_root'];hashes=json.loads((p/'stage-hashes.json').read_text())
def run(label,cmd,timeout=120):
 (p/(label+'.command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 with (p/(label+'.stdout')).open('xb') as out,(p/(label+'.stderr')).open('xb') as err:r=subprocess.run(cmd,stdout=out,stderr=err,timeout=timeout)
 assert r.returncode==0,(label,r.returncode)
def query(label,s,timeout=120):
 run(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','nuc','C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe -B -I -c "import base64;exec(base64.b64decode('+repr(base64.b64encode(s.encode()).decode())+'))"'],timeout)
query('stage-precheck',f"from pathlib import Path\nimport hashlib,json\np=Path({root!r})\nassert all(not (p/n).exists() for n in {list(hashes)!r})\nassert not (p/'target/codex-short-20260913').exists()\nassert not Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/c-734b-20260913').exists()\npins={json.loads((p/'codex-build-short-20260913-pins.json').read_text())!r}\nfor n,h in pins['files'].items():\n if n not in {list(hashes)!r}:assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n\nprint('fresh; existing pins match')")
run('stage-upload',['scp','-q',*[str(p/n) for n in hashes],'nuc:'+root+'/'])
query('stage-verify',f"from pathlib import Path\nimport hashlib,json,ast\np=Path({root!r});expected={hashes!r}\nfor n,h in expected.items():\n assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n\n if n.endswith('.py'):ast.parse((p/n).read_text())\nprint(json.dumps(expected))")
query('cache-copy',f"import runpy\nrunpy.run_path({(root+'/copy-short-cargo-cache.py')!r},run_name='__main__')",600)
s=r"""$ErrorActionPreference='Stop'
$p='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/c-734b-20260913'
$sid=(Get-Acl -LiteralPath $p).GetOwner([System.Security.Principal.SecurityIdentifier]).Value
$caller=[System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
if($sid -ne $caller){throw 'new cache owner differs from caller'}
if((Get-Item -LiteralPath $p).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'cache is reparse point'}
@{utc=(Get-Date).ToUniversalTime().ToString('o');path=$p;owner_sid=$sid;caller_sid=$caller;owner_matches=$true;reparse=$false} | ConvertTo-Json
"""
run('cache-owner',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','nuc','powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(s.encode('utf-16le')).decode()])
