Superseded preparation — no launch

Do not bind, stage, or launch this acceptance bundle. Its expected codex-resume-20260913 build failed before producing an executable, and no native acceptance run occurred.

The successor is ../acceptance-short/REVIEW.md. It uses the expected codex-short-20260913 output and distinct fresh stage/task/profile identities. All existing files in this folder remain retained unchanged. This marker does not authorize any runtime launch.
