Prepared acceptance only — 2026-09-13

No Windows commands, scheduling, staging, native probes, provider requests, credential reads, or shared changes were performed by this preparation. The rebuilt executable is still pending. Version must pass before initialize is launched. There is no automatic two-test launcher.

The two fresh identities and remote roots are listed in preparation.json. Reuse the previous patched canonicalization wrapper unchanged except fresh IDs, probe hash, mode switch, bound scheduled-action hash, and a prepared-only gate. The probe comes from the reviewed initialize draft; only its fixed executable source/hash and prepared-only gate differ. The files ending .review.diff show these changes. No weaker policy fallback is present. The unused debugger symbols directory from the old staging command is omitted.

Binding after the successful build:
1. Read the final build receipt and verify the expected output path in preparation.json, exact executable SHA-256, pinned Codex/Rust source and intended patch hashes. Build success is distinct from native acceptance. Original installed Codex must remain unchanged.
2. Run the local bind-artifact.py with --runtime-sha256 set to the executable SHA-256 reported by the completed build receipt. This creates a new bound-<hash-prefix> directory, resolves all hash layers and the encoded scheduled action, and performs no Windows work. It refuses overwritten evidence. Review both final stage.json files and decoded scheduled-action text. Do not run templates.
3. O must refresh read-only host preflight immediately before each launch: the Hub health/build/tree/schema/worker counts and sole listener PID match the pinned wrapper, SAC remains unenforced as changed by the user, the original Codex pin is unchanged, and the private build process has finished. If any value drifts, stop; do not silently rebase expectations or change policy.
4. For VERSION only, run its stage-create.ps1 to create the fresh staging directory, transfer its three probe/inner/outer scripts without changing bytes, and run validate-staged.ps1. It verifies all hashes and PowerShell parsing. Its C# body is the previously Windows-compiled initialize body plus only the fixed Codex source/hash; source compile proof is not a probe result.
5. Execute only that version driver's hash-checked invocation.ps1 through the established O-owned limited interactive task route. It creates one fresh no-trigger limited task, checks session 1 and identity, launches one fresh LPAC child, and disables the diagnostic task afterward. The child has a 15-second total deadline plus 5-second reap cleanup; prior inner/outer diagnostic deadlines and owned PID/start-time cleanup remain unchanged.
6. Collect explicit evidence with collect-evidence.ps1 into a NEW local remote/ directory. Also perform the retained read-only independent-console.ps1 check. Review the raw oracle below and both independent postflights. Failure consumes that test identity; no same-profile retry.
7. Only after version acceptance, repeat steps 3–6 separately for INITIALIZE with its distinct stage/task/profile. Initialize is the entire app-server scope: no thread, turn, setup, readiness, tool, account or config RPC is sent.

Version oracle:
- Native mode codex-version, exact rebuilt SHA before/after copy and after reap, exit 0, resumed, normally reaped, no timeout/kill/errors.
- Raw child stdout bytes are exactly codex-cli 0.153.4 plus LF (existing probe also permits CRLF normalization); raw child stderr is empty. Inspect bytes, not only Passed.
- Exact child AppContainer profile SID, TokenIsAppContainer=1, session=1, two fixed capability SIDs each attrs=4 with no duplicates, caller AccessCheck mask=3 and child mask=2. Mandatory no-descendant/LPAC attributes and explicit three inherited handles remain in source.
- New inside/outside canary contents are unchanged. These version canaries do not prove a fresh read-denial execution; the prior cmd read-boundary evidence remains separate.

Initialize oracle:
- Same identity, capabilities, binary hash and exit/cleanup assertions, native mode codex-initialize and InitializeResponseObserved=true.
- Raw stdout contains exactly one newline-terminated JSON success response id=1 with four result fields. userAgent begins oms_lpac_probe/0.153.4 followed by space; platformFamily/platformOs are windows; codexHome equals the expected normalized NT GLOBALROOT path of the exact newly created private home. No error/action/extra frame is accepted; stderr must be empty.
- Raw child.stdin contains exactly the fixed initialize request and initialized notification from the draft. The parent observes and validates the matching response before sending initialized and closing its non-inherited stdin writer. The child still inherits only read-pipe/stdout-file/stderr-file handles.
- Private config retains file-only auth, fixed auth-free unserved loopback provider, existing disabled-feature list, all OTEL exporters none, and windows.sandbox=elevated. Source review found no Windows setup/account/ACL preparation call before a setup or execution request. No server/listener/provider fixture is started.
- Preserve private config and raw errors on failure; do not modify capabilities, ACLs, registry, CODEX_HOME, output oracle or pinned runtime to make this pass.

Both postflights must explicitly show health/listener/worker preservation, no new or missing tracked processes, no helper, no cleanup/postflight errors, and the owned scheduled task disabled. Wrapper/task success alone is insufficient.

Limits: these are native version/startup/initialize acceptance only. No Windows arg0 unit tests are added or run by this scope; the two committed Windows tests remain unrun. GLOBALROOT PathUri lexical-hierarchy and no-follow limitations remain fail-closed and unaccepted for later execution. No provider, production generation, live Hub configuration, broader filesystem policy, or source quality acceptance is implied.
