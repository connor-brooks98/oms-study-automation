$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-3092ba4a06da';$files=@{
  'probe-windows-lpac.ps1'='e04780505e9e8ad42b7eb52792cfd89b9b3fac09653719f9977f8516154fe4d1'
  'probe-interactive.ps1'='6874ceb33bd507fb50ba6ebc1ae00ec05fc437ace2ca8bf5f35e563d00a77321'
  'run-lpac-task.ps1'='4a4af92a3f15b2b3e3cbeec9d864af9e3cb2c903b1f01d0caea4a6393e0491b3'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
