$ErrorActionPreference='Stop'
$from=[DateTime]::Parse('2026-09-13T15:07:00Z').ToLocalTime()
$to=[DateTime]::Parse('2026-09-13T15:11:00Z').ToLocalTime()
$records=@();$queries=@()
foreach($q in @(@{LogName='System';ProviderName='Microsoft-Windows-Resource-Exhaustion-Detector';Id=2004},@{LogName='Application';Id=1000,1001})) {
$q.StartTime=$from;$q.EndTime=$to
try {$events=@(Get-WinEvent -FilterHashtable $q -ErrorAction Stop);foreach($e in $events){if($e.ProviderName -eq 'Microsoft-Windows-Resource-Exhaustion-Detector' -or $e.Message -match 'rustc.exe|rust-lld.exe|cargo.exe'){$records+=@{id=$e.Id;provider=$e.ProviderName;time=$e.TimeCreated.ToUniversalTime().ToString('o');record=$e.RecordId;message=$e.Message;xml=$e.ToXml()}}};$queries+=@{log=$q.LogName;status='queried'}} catch {$queries+=@{log=$q.LogName;error=$_.Exception.Message;id=$_.FullyQualifiedErrorId}}
}
$os=Get-CimInstance Win32_OperatingSystem
@{utc=(Get-Date).ToUniversalTime().ToString('o');window=@{from='2026-09-13T15:07:00Z';to='2026-09-13T15:11:00Z'};queries=$queries;events=$records;current_memory=@{total_visible_kib=$os.TotalVisibleMemorySize;free_physical_kib=$os.FreePhysicalMemory;total_virtual_kib=$os.TotalVirtualMemorySize;free_virtual_kib=$os.FreeVirtualMemory}}|ConvertTo-Json -Depth 8
