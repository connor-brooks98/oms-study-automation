$ErrorActionPreference='Stop'
$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9'
$name='OMS GPT Private Runtime Build 734bbdfad4a9 fetch 20260913'
if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){throw 'fresh build task already exists'}
if(Test-Path -LiteralPath "$root/codex-build-fetch-20260913-once.json"){throw 'build launch already consumed'}
if((Get-FileHash -LiteralPath "$root/build-codex-fetch-20260913.py" -Algorithm SHA256).Hash.ToLower() -ne '242aa4fa1da22ac52b6ae6f45211461c1a0158b3c0900b927e0d9b5942b15311'){throw 'build script hash mismatch'}
$action=New-ScheduledTaskAction -Execute 'C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe' -Argument ('-B -I "'+$root+'/build-codex-fetch-20260913.py"') -WorkingDirectory 'C:/'
$principal=New-ScheduledTaskPrincipal -UserId 'conbr' -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 92) -MultipleInstances IgnoreNew -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$task=New-ScheduledTask -Action $action -Principal $principal -Settings $settings
$null=Register-ScheduledTask -TaskName $name -InputObject $task
Export-ScheduledTask -TaskName $name | Set-Content -Encoding UTF8 "$root/codex-build-fetch-20260913-task.xml"
Start-ScheduledTask -TaskName $name
@{task_name=$name;state=[string](Get-ScheduledTask -TaskName $name).State;script_sha256='242aa4fa1da22ac52b6ae6f45211461c1a0158b3c0900b927e0d9b5942b15311';utc=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json
