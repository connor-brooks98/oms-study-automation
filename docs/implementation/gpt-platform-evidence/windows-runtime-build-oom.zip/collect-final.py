"""Collect completed fresh build receipts without executing build outputs."""
from pathlib import Path
import base64,json,subprocess,hashlib
p=Path(__file__).resolve().parent;r=json.loads((p/'manifest.json').read_text())['remote_root']
source=f"""from pathlib import Path
import json,base64
p=Path({r!r})
assert (p/'codex-build-fetch-20260913-summary.json').exists()
names=[x for x in p.iterdir() if x.name.startswith('codex-build-fetch-20260913') and x.suffix in ['.json','.jsonl','.stdout','.stderr','.xml']]+[p/'codex-fetch-20260913-task-disable.stdout',p/'codex-fetch-20260913-task-disable.stderr',p/'codex-fetch-20260913-cache-owner.stdout',p/'codex-fetch-20260913-cache-owner.stderr']
print(json.dumps({{x.name:base64.b64encode(x.read_bytes()).decode() for x in names if x.is_file()}}))
"""
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','nuc','C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe -B -I -c "import base64;exec(base64.b64decode('+repr(base64.b64encode(source.encode()).decode())+'))"']
(p/'collect-final.command.json').write_text(json.dumps(cmd,indent=2)+'\n')
result=subprocess.run(cmd,capture_output=True,timeout=60)
(p/'collect-final.stdout').write_bytes(result.stdout);(p/'collect-final.stderr').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode()
out=p/'final-receipts';out.mkdir(exist_ok=False)
for n,b in json.loads(result.stdout).items():(out/n).write_bytes(base64.b64decode(b))
(p/'final-receipt-hashes.json').write_text(json.dumps({x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in out.iterdir()},indent=2)+'\n')
print((out/'codex-build-fetch-20260913-summary.json').read_text())
