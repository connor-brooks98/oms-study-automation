This run is complete and failed during compilation at 2026-09-13T15:09:20Z. Source/cache path correction passed the earlier AWS-LC failure. Concurrent codex-core and codex-app-server compilers then reported allocation failure and LLVM out of memory. No Codex artifact was accepted or executed.

The configured job cap was 8 GiB; peak job memory was not captured, so cap versus system commit remains unproven. Bounded OS events and exact stderr are retained under oom-diagnosis. Do not infer an exploitable stack error from the generic c0000409 exit label.

All 116 build guards passed. Independent reconciliation at15:14:04Z confirms the task disabled, owned processes absent, and exact Hub preservation. No acceptance probe ran. Subsequent attempts must use fresh driver/task/once/log identities. This completed directory is frozen for archival.
