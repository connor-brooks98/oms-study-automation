"""Apply only four reviewed private-source files, preserving their originals and the prior executable."""
from pathlib import Path
import json,hashlib,shutil,datetime
inputs=Path(__file__).resolve().parent
root=inputs.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((inputs/'source-patch-manifest.json').read_text())
assert sha(inputs/'source-patch-manifest.json')=='74ee6ff4b7b4d06c337dff1324c5d3a71d63ab0b8924befb07abfa4d892f8bdc'
assert sha(inputs/'codex-0.153.4-remote-control-name.patch')=='d3de282dc3839ad69aca064eb6882fa071a267b09c01b16d4cbd9f95152ccb51'
expected={'codex-rs/Cargo.lock','codex-rs/app-server-transport/Cargo.toml','codex-rs/app-server-transport/src/transport/remote_control/mod.rs','codex-rs/app-server-transport/src/transport/remote_control/tests.rs'}
assert set(manifest['files'])==expected
backup=root/'retained-hostname1-before';assert not backup.exists()
receipt=root/'hostname1-source-application.json';assert not receipt.exists()
exe=root/'target/codex-no-lto-20260913/x86_64-pc-windows-msvc/release/codex.exe'
assert sha(exe)=='74d7706f403336b693853eb8582e0424d9f765ac6c2d98e408206bf03e5ecf4f'
for n,pins in manifest['files'].items():
 original=root/'source/codex'/n;replacement=inputs/'source-after'/n
 for f in [original,replacement,exe]:
  for a in [f,*f.parents]:assert not (a.lstat().st_file_attributes & 0x400),str(a)
 assert sha(original)==pins['before'],n
 assert sha(replacement)==pins['after'],n
for a in [root,*root.parents]:assert not (a.lstat().st_file_attributes & 0x400),str(a)
result={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'patch_sha256':manifest['patch_sha256'],'candidate_commit':manifest['candidate_commit'],'passed':False,'files':manifest['files']}
backup.mkdir()
try:
 for n,pins in manifest['files'].items():
  dest=backup/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'source/codex'/n,dest);assert sha(dest)==pins['before'],n
 shutil.copyfile(exe,backup/'codex.exe');assert sha(backup/'codex.exe')=='74d7706f403336b693853eb8582e0424d9f765ac6c2d98e408206bf03e5ecf4f'
 for n,pins in manifest['files'].items():
  shutil.copyfile(inputs/'source-after'/n,root/'source/codex'/n);assert sha(root/'source/codex'/n)==pins['after'],n
 result.update(passed=True,prior_executable_sha256=sha(backup/'codex.exe'),source_application='exact reviewed patch-derived bytes; four paths only')
except BaseException as e:
 result['error']=repr(e);raise
finally:
 result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
