# Hostname fallback private build — completed

The one-shot incremental build finished successfully with Cargo exit 0 in 80m56s. The new executable is 294,002,688 bytes, SHA-256 d6eb90b7409dc22f407a9dfa44ec629a8a5a6bf3ca001493aef13dd85a75dbda. It was copied read-only and independently hashed locally; no output execution occurred in this build.

Source candidate 146df998b88cd31c561cf8339b8c90abc95369ea adds only the reviewed remote-control display-name patch d3de282dc3839ad69aca064eb6882fa071a267b09c01b16d4cbd9f95152ccb51 to the previously accepted private source. All four patched source hashes and original backups were verified after compilation. The old executable 74d7706f403336b693853eb8582e0424d9f765ac6c2d98e408206bf03e5ecf4f remains frozen locally in the prior build and in the remote retained-hostname1-before directory.

Private Rust 1.95.0, patched std/arg0, locked dependencies, release opt3/CGU4/panic unwind and Cargo LTO=false remain pinned. The final invocation and explicit environment are retained. The job retained j1, BelowNormal, 9.5 GiB, 90-minute timeout and unchanged reserve guards. No policy, pagefile, account, shared ACL, live Hub or provider changes occurred.

All 165 Hub and 1,134 memory checks passed. Peak job committed memory was 9,361,584,128 bytes below the 10,200,547,328-byte cap. Minimum system commit reserve was 4,722,372,608 bytes; minimum available physical memory was 15,385,935,872 bytes. Cleanup errors were empty and no timeout occurred. Independent 23:31:48.9038151Z reconciliation confirmed the task disabled, no owned processes, and the exact original Hub listener/build/tree/schema/workers.

The first local SCP copy timed out after 120 seconds; its partial bytes and metadata are retained. A separate compressed read-only copy completed and matched the native hash. This transfer issue did not rerun or change the build. Earlier pre-upload transport failure and reviewed zlib-only correction are also retained.

This is private build success only. Fresh LPAC version and initialize acceptance remain separately gated. For a thin evidence archive, exclude build-output binaries (including the retained partial transfer) while retaining their hashes and all source, preparation and final receipts.
