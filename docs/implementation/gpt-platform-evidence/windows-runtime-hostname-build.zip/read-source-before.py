from pathlib import Path
import json,hashlib,base64
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/source/codex')
print(json.dumps({n:{"sha256":hashlib.sha256((p/n).read_bytes()).hexdigest(),"base64":base64.b64encode((p/n).read_bytes()).decode()} for n in ['codex-rs/Cargo.lock', 'codex-rs/app-server-transport/Cargo.toml', 'codex-rs/app-server-transport/src/transport/remote_control/mod.rs', 'codex-rs/app-server-transport/src/transport/remote_control/tests.rs']}))