import runpy,json,hashlib
from pathlib import Path
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/codex-build-hostname1-20260913-guard.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='2ffbb5cd2d85065e46c1172724a7747896a961640e2063bf11877c82246625d6'
g=runpy.run_path(str(p))
print(json.dumps(g["health"]("preflight"),indent=2))
