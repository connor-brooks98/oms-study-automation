"""Apply the exact reviewed four-file private-source update once; no build/output execution."""
from pathlib import Path
import json,hashlib,base64,subprocess,datetime
p=Path(__file__).resolve().parent
assert json.loads((p/'source-stage-verify.stdout').read_text())['passed'] is True
assert hashlib.sha256((p/'apply-source.py').read_bytes()).hexdigest()=='2a5289724d1ca3400b4fc0b0ac383da513926b6770ce64170b21e2c997ff23b6'
with (p/'source-application-once.json').open('x') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},f)
src="from pathlib import Path;import hashlib,runpy;p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/hostname1-source-inputs/apply-source.py');assert hashlib.sha256(p.read_bytes()).hexdigest()=="+repr('2a5289724d1ca3400b4fc0b0ac383da513926b6770ce64170b21e2c997ff23b6')+";runpy.run_path(str(p),run_name='__main__')"
cmd=['ssh','nuc','C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe -B -I -c "import base64;exec(base64.b64decode('+repr(base64.b64encode(src.encode()).decode())+'))"']
(p/'source-apply.command.json').write_text(json.dumps(cmd,indent=2))
r=subprocess.run(cmd,capture_output=True,timeout=120);(p/'source-apply.stdout').write_bytes(r.stdout);(p/'source-apply.stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr;print(r.stdout.decode())
