$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-8d17cd127e5e';$files=@{
  'probe-windows-lpac.ps1'='eb1589ee41b4c04aa0bedb3dc455968a5d859ffd5d583732245dbfa6fdeb0887'
  'probe-interactive.ps1'='dc1bb425a230b6b7efeaaf21c5b3a81327c7e0c1559b2cbf4214d9581f27ebcc'
  'run-lpac-task.ps1'='13a7094a5dd651dc8d905b45ac6e4bbeca0a041f6cb0ff6a7be505a7fd9c1a3e'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
