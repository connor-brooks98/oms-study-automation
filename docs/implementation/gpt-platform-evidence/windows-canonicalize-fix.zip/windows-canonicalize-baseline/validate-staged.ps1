$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-b82d75827f74';$files=@{
  'probe-windows-lpac.ps1'='57426d3e105f255453b820bc75aff0848c7a9e6b3a838ca2875cd1d24bb8327e'
  'probe-interactive.ps1'='c3e152dc57aa726f3dd92baaf894ef35ef85621f59fdc022fc057a8aad99e708'
  'run-lpac-task.ps1'='fe4f67e4f5baafffda5f3c0a8c6e21c73213bb420764ce1247a9e3760f21e460'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
