This 10 GiB attempt was consumed and stopped BEFORE creating the job or Cargo. External native preflight passed at16:28:05Z; the in-task check at16:28:25Z measured commit headroom12,830,498,816bytes below the exact12,884,901,888byte threshold. The emergency reserves were not weakened. No compiler invocation/result/stdout was created.

Postflight passed, task disabled, and independent16:29:58Z reconciliation confirmed no owned processes and exact Hub preservation. All raw receipts and pins are retained. This completed directory is frozen; do not reuse the consumed task or once marker.
