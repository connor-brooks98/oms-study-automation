import runpy,json,hashlib
from pathlib import Path
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/codex-build-cap10-20260913-guard.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='08e8ca50e9f20b79e971f5b5e9f167198859a92d51291e849c9536f9ac317603'
g=runpy.run_path(str(p))
print(json.dumps(g["health"]("preflight"),indent=2))
