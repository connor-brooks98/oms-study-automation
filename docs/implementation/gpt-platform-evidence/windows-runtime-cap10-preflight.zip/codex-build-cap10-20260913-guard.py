"""Read-only live Hub guard for the owned private compilation job."""
import ctypes,ctypes.wintypes as w,json,socket,struct,urllib.request,datetime
from pathlib import Path
root=Path(__file__).resolve().parent
identity=None
ip=ctypes.WinDLL('iphlpapi');ip.GetExtendedTcpTable.argtypes=[ctypes.c_void_p,ctypes.POINTER(w.DWORD),w.BOOL,w.ULONG,ctypes.c_int,w.ULONG];ip.GetExtendedTcpTable.restype=w.DWORD
class PERFORMANCE(ctypes.Structure):
 _fields_=[('cb',w.DWORD)]+[(n,ctypes.c_size_t) for n in ['CommitTotal','CommitLimit','CommitPeak','PhysicalTotal','PhysicalAvailable','SystemCache','KernelTotal','KernelPaged','KernelNonpaged','PageSize']]+[(n,w.DWORD) for n in ['HandleCount','ProcessCount','ThreadCount']]
ps=ctypes.WinDLL('psapi',use_last_error=True)
ps.GetPerformanceInfo.argtypes=[ctypes.POINTER(PERFORMANCE),w.DWORD];ps.GetPerformanceInfo.restype=w.BOOL
def memory(stage):
 receipt={'stage':stage,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  info=PERFORMANCE();info.cb=ctypes.sizeof(info)
  if not ps.GetPerformanceInfo(ctypes.byref(info),ctypes.sizeof(info)):raise ctypes.WinError(ctypes.get_last_error())
  assert info.PageSize>0 and info.CommitLimit>=info.CommitTotal
  commit_free=(info.CommitLimit-info.CommitTotal)*info.PageSize;physical_free=info.PhysicalAvailable*info.PageSize
  commit_floor=(12 if stage=='preflight' else 2)*1024**3;physical_floor=(14 if stage=='preflight' else 4)*1024**3
  receipt.update(commit_total_bytes=info.CommitTotal*info.PageSize,commit_limit_bytes=info.CommitLimit*info.PageSize,commit_headroom_bytes=commit_free,physical_available_bytes=physical_free,commit_floor_bytes=commit_floor,physical_floor_bytes=physical_floor)
  assert commit_free>=commit_floor and physical_free>=physical_floor,'system memory reserve below required floor'
  receipt['passed']=True
 except BaseException as e:
  receipt.update(passed=False,error=repr(e));raise
 finally:
  with (root/'codex-build-cap10-20260913-memory.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(receipt)+'\n')
 return receipt
def health(stage):
 global identity
 receipt={'stage':stage,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  with opener.open('http://127.0.0.1:8765/health',timeout=5) as f:h=json.load(f)
  receipt['health']=h
  assert h['status']=='ok' and h['database_reachable'] is True
  assert h['build_revision']=='f487c6229b91d2b1ac11729e465561f6c1ffe997' and h['build_tree']=='a9f7cc7f9c03040cb63ccea3ef05b70add443e6a' and h['schema_version']==31
  assert set(h['workers'])=={'generation_worker','ingestion_worker','studio_worker'}
  worker_identity={}
  for name,v in h['workers'].items():
   assert v['alive'] is True and v['start_count']==1 and v['current_error'] is None and v['recovery_error'] is None and v['heartbeat_age_seconds']<30
   worker_identity[name]=v['thread_id']
  size=w.DWORD();code=ip.GetExtendedTcpTable(None,ctypes.byref(size),False,2,3,0)
  assert code==122 and 4<=size.value<=1048576,(code,size.value)
  buf=ctypes.create_string_buffer(size.value);code=ip.GetExtendedTcpTable(buf,ctypes.byref(size),False,2,3,0);assert code==0,code
  raw=buf.raw;count=struct.unpack_from('<I',raw)[0];assert 4+24*count<=len(raw)
  listeners=[]
  for i in range(count):
   state,addr,port,_,_,pid=struct.unpack_from('<6I',raw,4+24*i)
   if socket.ntohs(port&65535)==8765:listeners.append([socket.inet_ntoa(struct.pack('<I',addr)),pid])
  receipt['listeners']=listeners;assert listeners==[['127.0.0.1',8268]],listeners
  current={'workers':worker_identity,'listeners':listeners}
  if identity is None:identity=current
  else:assert current==identity
  receipt['memory']=memory(stage)
  receipt['passed']=True
 except BaseException as e:
  receipt.update(passed=False,error=repr(e));raise
 finally:
  with (root/'codex-build-cap10-20260913-health.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(receipt)+'\n')
 return receipt
