.lastevent
.catch { .reload /f ntdll.dll; lmv m ntdll; !gflag; !gflag +sls; !gflag }
sxe -c "$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-3c58ad75a48d/kernelbase.cmd" ld:kernelbase.dll
g
