.lastevent
.catch { .reload /f kernelbase.dll; lmv m kernelbase; uf kernelbase!BaseDllInitialize; uf kernelbase+0x5060 }
g
