$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-3c58ad75a48d';$files=@{
  'probe-windows-lpac.ps1'='e0f721e87a521cedb8100bd682badee0c8220082c372cb02d69e1174a4a05123'
  'probe-interactive.ps1'='44ad95177c3fadf191a09b3a9e26d471ac7cb77a0a153d14097c28254c34f2c5'
  'run-lpac-task.ps1'='02da57a7d529b4db43353d177f6ad1203abd84eb133b3ae841ccbe795641e012'
}
if((Get-FileHash -LiteralPath (Join-Path $root 'debugger.cmd') -Algorithm SHA256).Hash.ToLower() -ne 'eeb6321f088d53b517163d0b53ece068092d832198f430f966b4d37691767467'){throw 'debugger command staged hash mismatch'};$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
