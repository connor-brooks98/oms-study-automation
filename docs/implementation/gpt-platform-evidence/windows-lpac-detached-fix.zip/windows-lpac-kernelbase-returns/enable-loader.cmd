.lastevent
.catch { .reload /f ntdll.dll; lmv m ntdll; !gflag; !gflag +sls; !gflag }
sxe -c "$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-37240a4300b8/kernelbase.cmd" ld:kernelbase.dll
g
