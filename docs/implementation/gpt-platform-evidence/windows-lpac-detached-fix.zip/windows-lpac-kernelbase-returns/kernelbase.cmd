.lastevent
.catch { .reload /f kernelbase.dll; lmv m kernelbase }
.catch { bp /1 kernelbase+0x4e901 ".echo OMS_AFTER_NtQuerySystemInformation;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0x4e999 ".echo OMS_AFTER_CsrClientConnectToServer;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0x4eba6 ".echo OMS_AFTER_BaseNlsDllInitialize;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0x4ebc8 ".echo OMS_AFTER_RtlInitializeCriticalSection;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0x4ebe6 ".echo OMS_AFTER_ConsoleInitialize;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0xbec1d ".echo OMS_AFTER_ConsoleShouldAllocateConsole;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0xbecab ".echo OMS_AFTER_ConsoleAllocate;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0x506d ".echo OMS_AFTER_KernelBaseBaseDllInitialize;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0x5138 ".echo OMS_AFTER_ARI_Globals_Initialize;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0xbeba9 ".echo OMS_AFTER_ConsoleCriticalSection;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0xbecff ".echo OMS_AFTER_ConsoleCreateConnectionObject;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0xbed48 ".echo OMS_AFTER_ConsoleIsCallerInLowbox;r eax;!gle;k 4;g" }
.catch { bp /1 kernelbase+0xbed98 ".echo OMS_AFTER_ConsoleSanitizeStandardIoObjects;r eax;!gle;k 4;g" }
g
