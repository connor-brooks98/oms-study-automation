$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-37240a4300b8';$files=@{
  'probe-windows-lpac.ps1'='e0f721e87a521cedb8100bd682badee0c8220082c372cb02d69e1174a4a05123'
  'probe-interactive.ps1'='98521a8622c490be5490093a6ab9a610b89d10408a7688095cdbc78287f72602'
  'run-lpac-task.ps1'='7ecb2c638222a674c97fc24679412ed1a6684c4922963ffca5eeb82ccb03ceb0'
}
if((Get-FileHash -LiteralPath (Join-Path $root 'debugger.cmd') -Algorithm SHA256).Hash.ToLower() -ne 'ce1f999bc5d7a56da7c5b9ee60dc1e6c6c3ff6442bc74afc4e18d7d3c7375907'){throw 'debugger command staged hash mismatch'};$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
