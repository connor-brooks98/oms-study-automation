.lastevent
.catch { .reload /f ntdll.dll; lmv m ntdll; !gflag; !gflag +sls; !gflag }
sxe -c "$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-8a24c7529b13/kernelbase.cmd" ld:kernelbase.dll
g
