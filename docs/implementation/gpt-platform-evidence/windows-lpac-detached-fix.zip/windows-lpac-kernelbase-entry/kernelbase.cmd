.lastevent
.catch { .reload /f kernelbase.dll; lmv m kernelbase }
.catch { uf kernelbase+0x5060 }
.catch { uf kernelbase!KernelBaseBaseDllInitialize }
.catch { uf kernelbase!_KernelBaseBaseDllInitialize }
.catch { uf kernelbase!ConsoleInitialize }
g
