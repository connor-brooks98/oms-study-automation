$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-8a24c7529b13';$files=@{
  'probe-windows-lpac.ps1'='e0f721e87a521cedb8100bd682badee0c8220082c372cb02d69e1174a4a05123'
  'probe-interactive.ps1'='a7a2360f7e795044718fcdc925e1bf6ed699567753c84e629f3f0eb4f19f531b'
  'run-lpac-task.ps1'='ccec72d4ec6cdacb28f5dc57f9d6dc8171c1564078a451c0ba0c299c75cd1bba'
}
if((Get-FileHash -LiteralPath (Join-Path $root 'debugger.cmd') -Algorithm SHA256).Hash.ToLower() -ne '00e41f6e97b1e072bee3979fae45146c5494993470f67a62c2e43de6a1ad7b0b'){throw 'debugger command staged hash mismatch'};$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
