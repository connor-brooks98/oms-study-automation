$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-88db6b957b31';$files=@{
  'probe-windows-lpac.ps1'='c3a6831cba9295e7e233f2e0125d18a62cb5a0e60cfd71fb254978287f69a1bd'
  'probe-interactive.ps1'='97dcde81423eee427e554c73ae32c4f3ffccb69098f45e87ef72072e52654bd5'
  'run-lpac-task.ps1'='01accc691b44097ec7b65e05decc251439c5eac7439e2c977b30d2b8756cc120'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
