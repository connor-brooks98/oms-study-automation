from pathlib import Path
import datetime,hashlib,json,struct,urllib.request,uuid
root=Path(__file__).parent
dll=json.loads((root/'readonly.stdout').read_text(encoding='utf-8-sig'))
c=dll['codeview'];relative=c['pdb_name']+'/'+c['symsrv_key']+'/'+c['pdb_name']
url='https://msdl.microsoft.com/download/symbols/'+relative
out=root/'store'/relative;out.parent.mkdir(parents=True)
with urllib.request.urlopen(url,timeout=45) as response:
    receipt={'official_url':url,'resolved_url':response.url,'status':response.status,'headers':dict(response.headers)}
    assert response.status==200
    length=int(response.headers['Content-Length']);assert 0<length<=64*1024*1024
    (root/'download-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    with out.open('xb') as f:
        count=0
        while True:
            chunk=response.read(1024*1024)
            if not chunk:break
            count+=len(chunk);assert count<=length;f.write(chunk)
    assert count==length
b=out.read_bytes();assert b[:32]==b'Microsoft C/C++ MSF 7.00\r\n\x1aDS\0\0\0'
block,free,nblocks,dirbytes,unused,mapblock=struct.unpack_from('<6I',b,32)
assert block in (512,1024,2048,4096,8192) and len(b)==nblocks*block
n=(dirbytes+block-1)//block;assert n*4<=block
pages=struct.unpack_from('<'+'I'*n,b,mapblock*block)
directory=b''.join(b[x*block:(x+1)*block] for x in pages)[:dirbytes]
streams=struct.unpack_from('<I',directory)[0];sizes=struct.unpack_from('<'+'I'*streams,directory,4)
q=4+4*streams;selected={}
for index,size in enumerate(sizes):
    if size==0xffffffff:continue
    n=(size+block-1)//block;pages=struct.unpack_from('<'+'I'*n,directory,q);q+=4*n
    if index in (1,3):selected[index]=b''.join(b[x*block:(x+1)*block] for x in pages)[:size]
info=selected[1];dbi=selected[3]
version,stamp,age=struct.unpack_from('<III',info);guid=uuid.UUID(bytes_le=info[12:28]);dbi_age=struct.unpack_from('<I',dbi,8)[0]
# Microsoft's actual PDB matching rule: GUID equal, Info age >= image age, DBI age equal image age.
# https://github.com/microsoft/microsoft-pdb/blob/master/PDB/dbi/pdb.cpp#L783-L816
assert str(guid)==c['guid'] and age>=c['age'] and dbi_age==c['age']
manifest={'dll':dll,'pdb':{'path':str(out),'symsrv_relative_path':relative,'official_url':'https://msdl.microsoft.com/download/symbols/'+relative,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'stream1_guid':str(guid),'stream1_age':age,'dbi_age':dbi_age,'microsoft_identity_rule_passed':True},'matching_rule_source':'https://github.com/microsoft/microsoft-pdb/blob/master/PDB/dbi/pdb.cpp#L783-L816','validation_method':'PDB InfoStream GUID equality and Info age >= image age, with DBI age equal image age, following the Microsoft PDB implementation.','read_only_source_sha256':hashlib.sha256((root/'read-kernelbase-codeview.py').read_bytes()).hexdigest(),'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only SSH Python -B -I inspection of System32 KERNELBASE.dll only; local Microsoft public-symbol download and validation. No target execution, debugger execution, installer, registry/settings changes or remote file writes.','native_debugger_symbol_validation':'Pending; this receipt proves file identity under the Microsoft PDB matching rule.'}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
rows=[]
for f in sorted(root.rglob('*')):
    if f.is_file() and f.name!='SHA256SUMS':rows.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(root)))
(root/'SHA256SUMS').write_text('\n'.join(rows)+'\n')
print(json.dumps(manifest,indent=2))
