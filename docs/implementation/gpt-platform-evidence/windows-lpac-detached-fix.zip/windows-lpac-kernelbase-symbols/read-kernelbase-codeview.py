import struct,uuid,json,hashlib,datetime
from pathlib import Path
path=Path(r'C:\Windows\System32\KERNELBASE.dll');b=path.read_bytes()
def u16(o):return struct.unpack_from('<H',b,o)[0]
def u32(o):return struct.unpack_from('<I',b,o)[0]
assert b[:2]==b'MZ'
pe=u32(60);assert b[pe:pe+4]==b'PE\0\0'
assert u16(pe+4)==0x8664
opt=pe+24;assert u16(opt)==0x20b
section=opt+u16(pe+20);count=u16(pe+6)
def offset(rva):
 if rva<u32(opt+60):return rva
 for i in range(count):
  vs,va,rs,rp=struct.unpack_from('<IIII',b,section+i*40+8)
  if va<=rva<va+max(vs,rs):
   d=rva-va;assert d<rs;return rp+d
 raise ValueError(('RVA not file backed',rva))
rva,size=struct.unpack_from('<II',b,opt+112+6*8)
assert rva and 0<size<=28*1024 and size%28==0
records=[]
for i in range(size//28):
 entry=struct.unpack_from('<IIHHIIII',b,offset(rva)+i*28)
 if entry[4]!=2:continue
 n,raw=entry[5],entry[7];assert 24<n<=65536 and raw+n<=len(b)
 data=b[raw:raw+n];assert data[:4]==b'RSDS'
 guid=uuid.UUID(bytes_le=data[4:20]);age=struct.unpack_from('<I',data,20)[0]
 name=data[24:].split(b'\0',1)[0].decode('utf8')
 assert name.lower()=='kernelbase.pdb'
 records.append({'pdb_name':name,'guid':str(guid),'age':age,'symsrv_key':guid.hex.upper()+format(age,'X')})
assert len(records)==1
signature=b'\xbd\x04\xef\xfe\x00\x00\x01\x00';matches=[];o=0
while True:
 o=b.find(signature,o)
 if o<0:break
 vals=struct.unpack_from('<13I',b,o)
 matches.append('.'.join(str(x) for v in vals[2:4] for x in (v>>16,v&65535)));o+=8
assert len(matches)==1,matches
print(json.dumps({'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'machine':'AMD64','file_version':matches[0],'codeview':records[0],'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
