if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-da5dfc8c88a8';$files=@{
  'probe-windows-lpac.ps1'='ee2c4fb1bf1d2ff929f87ce17f97abbe6f98b8a65d536a02a175b6d1e2253046'
  'probe-interactive.ps1'='76e1c3836f242311b926a7c6b3faf1758d3fdd7571a22b3f24cfedabe661ca7f'
  'run-lpac-task.ps1'='c1a43fa98866a1046aee67eb127c17f3b1e95cd2f2264d5830eab322ad48da6f'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
