$ErrorActionPreference='Stop'
$ci = & 'C:/Windows/System32/CiTool.exe' -lp -json
$ciExit=$LASTEXITCODE
if($ciExit -ne 0){throw "CiTool read failed: $ciExit"}
$policy=($ci -join "`n") | ConvertFrom-Json
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
$h=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/health' -TimeoutSec 5
$listeners=@(Get-NetTCPConnection -State Listen -LocalPort 8765 | Select-Object LocalAddress,OwningProcess)
$owned=@(Get-CimInstance Win32_Process | Where-Object {$_.ExecutablePath -like '*runtime-build-734bbdfad4a9*' -or $_.CommandLine -like '*runtime-build-734bbdfad4a9*'} | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine)
$tasks=@(Get-ScheduledTask -TaskName 'OMS GPT Private Runtime Build 734bbdfad4a9*' | ForEach-Object {@{name=$_.TaskName;state=[string]$_.State;enabled=$_.Settings.Enabled}})
$original=Get-FileHash -LiteralPath 'C:/Users/conbr/.local/bin/codex.exe' -Algorithm SHA256
$rebuilt=Get-FileHash -LiteralPath 'C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/target/codex-no-lto-20260913/x86_64-pc-windows-msvc/release/codex.exe' -Algorithm SHA256
$freshTask=Get-ScheduledTask -TaskName 'OMS GPT LPAC Rebuilt Version da5dfc8c88a8' -ErrorAction SilentlyContinue
$freshStage=Test-Path -LiteralPath 'C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-da5dfc8c88a8'
@{original_codex_sha256=$original.Hash.ToLower();rebuilt_sha256=$rebuilt.Hash.ToLower();fresh_task_absent=($null -eq $freshTask);fresh_stage_absent=(-not $freshStage);utc=(Get-Date).ToUniversalTime().ToString('o');disk=(Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" | Select-Object Size,FreeSpace);policy=$policy;memory=($m | Select-Object AvailableBytes,CommittedBytes,CommitLimit);health=$h;listeners=$listeners;owned_processes=$owned;tasks=$tasks} | ConvertTo-Json -Depth 12
