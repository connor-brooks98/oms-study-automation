if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-479d1248e92e';$files=@{
  'probe-windows-lpac.ps1'='ee2c4fb1bf1d2ff929f87ce17f97abbe6f98b8a65d536a02a175b6d1e2253046'
  'probe-interactive.ps1'='c43cbb50acf2138d1b05953a96ea05331cda2cf563be76e506092182694152d4'
  'run-lpac-task.ps1'='ebe67c0f1e7eee0b97b0f3cf9acf85fca1b7e0d4bf61e4ba4efcaa7016cb27a3'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
