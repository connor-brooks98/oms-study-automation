$ErrorActionPreference='Stop'
$decoded=Get-Content -Raw -LiteralPath 'C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-479d1248e92e/run/owned-processes.json' | ConvertFrom-Json
$ledger=@($decoded)
$snapshot=@(Get-CimInstance Win32_Process)
$remaining=@($snapshot | Where-Object {$_.ProcessId -in @($ledger | ForEach-Object {[int]$_.pid})} | Select-Object Name,ProcessId,CreationDate)
$task=Get-ScheduledTask -TaskName 'OMS GPT LPAC Rebuilt Initialize 479d1248e92e'
$h=Invoke-RestMethod -TimeoutSec 5 http://127.0.0.1:8765/health
@{utc=(Get-Date).ToUniversalTime().ToString('o');recorded=$ledger;remaining=$remaining;task_state=[string]$task.State;task_enabled=$task.Settings.Enabled;health=$h;listeners=@(Get-NetTCPConnection -LocalPort 8765 -State Listen | Select-Object LocalAddress,OwningProcess);original_sha256=(Get-FileHash -LiteralPath 'C:/Users/conbr/.local/bin/codex.exe' -Algorithm SHA256).Hash.ToLower()} | ConvertTo-Json -Depth 10
