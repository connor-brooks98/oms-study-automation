$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-c7c9e2ca0657';$files=@{
  'probe-windows-lpac.ps1'='4dbcd2e33311689bf9d8f06c86d76809260b0f4dd32950a4b726408a816ff294'
  'probe-interactive.ps1'='3a4c1dba59d953b5953a084aac62e239fec32fc989c94cfab4da44f62396e777'
  'run-lpac-task.ps1'='595182804a9683bbd596ecfbf0efd8f1e009ed2e390e64556accecdb9b383507'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
