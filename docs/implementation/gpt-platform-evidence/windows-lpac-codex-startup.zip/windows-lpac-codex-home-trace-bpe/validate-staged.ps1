$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-13f6094b41db';$files=@{
  'loader-break.cmd'='43f7a6096cba14e835249ceadf1567fbca68e7c373ebcb4d0cf7aa1a3e142512'
  'probe-windows-lpac.ps1'='4dbcd2e33311689bf9d8f06c86d76809260b0f4dd32950a4b726408a816ff294'
  'probe-interactive.ps1'='1059720b3a91492440cce69fbe63722ba53d1f1959ad90272142d2d9755beac4'
  'run-lpac-task.ps1'='be1903e41af110556dfd044d3376465e6fd60c1479e64da1e9a44d55f1e6fe3d'
  'debugger.cmd'='cd17dd66e8af3b7101a6cf41da58b1864aad965e22436cde83f1fd33789a4a39'
  'arm-home-trace.cmd'='b73585a4d2671fd069c07e4087e70c64ed5ab2ee82304f91d61a393de787052b'
  'kernelbase.cmd'='ffe26a4baa6c22f91cef6b969b6b849aaae7ab947616cb419806f99c3c3b232a'
  'createfile-entry.cmd'='51c1d17fb5b8e3b95db988e48ac7582f811937e0c66fdc6fea6d0350eb2a112d'
  'finalpath-entry.cmd'='2b66bdec62b72df3665585c1e15d35f912ac13b708976417db1399b90a0f1018'
  'symbols/ntdll.pdb'='879596b54dc0b944e47160dcba01bac56fbc13eaed41fcad50897c6fdd730d1f'
  'symbols/kernelbase.pdb'='a440229ee962ea3034f3c282ad0dd9dd3b912855af21672b9ed67ea7787f4c90'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$parseErrors=$null;if($name.EndsWith('.ps1')){$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);$parseErrors=@($errors).Count;if($parseErrors){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"}};$result+=@{name=$name;sha256=$hash;parse_errors=$parseErrors}};ConvertTo-Json -InputObject $result -Depth 3
