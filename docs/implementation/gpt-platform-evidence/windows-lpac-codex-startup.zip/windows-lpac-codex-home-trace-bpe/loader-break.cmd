.if ((@$tpid == @$t19) && (@rip == ntdll!LdrpDoDebuggerBreak+0x35)) { .catch { .echo OMS_OWNED_LOADER_BREAK_RESUMED; sxe -c "" bpe };g } .else { .echo OMS_UNEXPECTED_BREAK_STOPPED }
