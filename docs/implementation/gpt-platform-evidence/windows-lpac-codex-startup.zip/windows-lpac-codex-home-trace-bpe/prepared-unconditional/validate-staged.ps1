$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-13f6094b41db';$files=@{
  'probe-windows-lpac.ps1'='4dbcd2e33311689bf9d8f06c86d76809260b0f4dd32950a4b726408a816ff294'
  'probe-interactive.ps1'='c87e00e392643d8645e6a16a84d125390d44655d42418c3465a1a452bc5fdca4'
  'run-lpac-task.ps1'='04ec8480dbc5094a6217820010b1b28a8541c8232e16a6263850645c605ea01d'
  'debugger.cmd'='dc325f8fede463a70df4bc153875bfa153f735b27f63c1eeac5bfb49709415ce'
  'arm-home-trace.cmd'='99232cc5d8b944a6315553771472b615449f3ff814775550aa3a457b3e258a80'
  'kernelbase.cmd'='ffe26a4baa6c22f91cef6b969b6b849aaae7ab947616cb419806f99c3c3b232a'
  'createfile-entry.cmd'='51c1d17fb5b8e3b95db988e48ac7582f811937e0c66fdc6fea6d0350eb2a112d'
  'finalpath-entry.cmd'='2b66bdec62b72df3665585c1e15d35f912ac13b708976417db1399b90a0f1018'
  'symbols/ntdll.pdb'='879596b54dc0b944e47160dcba01bac56fbc13eaed41fcad50897c6fdd730d1f'
  'symbols/kernelbase.pdb'='a440229ee962ea3034f3c282ad0dd9dd3b912855af21672b9ed67ea7787f4c90'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$parseErrors=$null;if($name.EndsWith('.ps1')){$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);$parseErrors=@($errors).Count;if($parseErrors){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"}};$result+=@{name=$name;sha256=$hash;parse_errors=$parseErrors}};ConvertTo-Json -InputObject $result -Depth 3
