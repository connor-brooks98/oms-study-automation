.catch { .lastevent; .echo OMS_OWNED_CODEX_TRACE_ARMED; sxe -c "$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-13f6094b41db/kernelbase.cmd" ld:kernelbase.dll }
g
