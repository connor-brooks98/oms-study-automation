$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-bf68b23436db';$files=@{
  'probe-windows-lpac.ps1'='4dbcd2e33311689bf9d8f06c86d76809260b0f4dd32950a4b726408a816ff294'
  'probe-interactive.ps1'='b280fb2eb09ecaf2b7b6676d3f911879cb6732d455373ed47105b7fda8301128'
  'run-lpac-task.ps1'='65fbbc4238cad7b16adb73c74f2e50d32b3686cb28cda6c49c58287e6cb7a61c'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
