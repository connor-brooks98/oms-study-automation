.catch { .lastevent; .echo OMS_OWNED_CODEX_TRACE_ARMED; r $t19 = @$tpid; sxe -c "$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-1c725e6b7d86/loader-break.cmd" bpe; sxe -c "$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-1c725e6b7d86/kernelbase.cmd" ld:kernelbase.dll }
g
