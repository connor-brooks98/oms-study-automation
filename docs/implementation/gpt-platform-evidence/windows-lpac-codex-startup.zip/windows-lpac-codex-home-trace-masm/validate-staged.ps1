$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-1c725e6b7d86';$files=@{
  'loader-break.cmd'='faf2013649a50e7f137b499ad12fd1c5edb103974ea116d63ab904ff8e388f8d'
  'probe-windows-lpac.ps1'='4dbcd2e33311689bf9d8f06c86d76809260b0f4dd32950a4b726408a816ff294'
  'probe-interactive.ps1'='ecbe8518f1e926fd7ace8282c7cd434e532aea24e0b8b62a11b17b772fb0f486'
  'run-lpac-task.ps1'='330cfbe4917473525fbb857045e0bba79f70191806fb72fb0a85755d01b9ee37'
  'debugger.cmd'='7296ec661f0f65ffe3f31dd79be448cd173ab76bcbb3d53158c76865a52f5b27'
  'arm-home-trace.cmd'='a14a0934eaec0f651c0380fc9b82910619a4a3bc73cc0364ebf82a4e35614c54'
  'kernelbase.cmd'='560044c9d9cea63f8c982763f231954391da81f0b083e1b0bd5c98548106a52d'
  'createfile-entry.cmd'='51c1d17fb5b8e3b95db988e48ac7582f811937e0c66fdc6fea6d0350eb2a112d'
  'finalpath-entry.cmd'='2b66bdec62b72df3665585c1e15d35f912ac13b708976417db1399b90a0f1018'
  'symbols/ntdll.pdb'='879596b54dc0b944e47160dcba01bac56fbc13eaed41fcad50897c6fdd730d1f'
  'symbols/kernelbase.pdb'='a440229ee962ea3034f3c282ad0dd9dd3b912855af21672b9ed67ea7787f4c90'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$parseErrors=$null;if($name.EndsWith('.ps1')){$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);$parseErrors=@($errors).Count;if($parseErrors){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"}};$result+=@{name=$name;sha256=$hash;parse_errors=$parseErrors}};ConvertTo-Json -InputObject $result -Depth 3
