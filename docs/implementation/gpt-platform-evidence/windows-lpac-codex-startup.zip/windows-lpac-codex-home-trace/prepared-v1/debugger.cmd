.echo OMS_CODEX_HOME_TRACE_BEGIN
.expr /s masm
.symopt+ 0x80000000
sxe -c "$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-98729cffbd39/arm-home-trace.cmd" cpr:codex.exe
sxe -c ".lastevent;g" ibp
sxn -c ".lastevent" epr
g
