.lastevent
.reload /f kernelbase.dll
.reload /f ntdll.dll
lmv m kernelbase
lmv m ntdll
bp kernelbase!CreateFileW "$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-98729cffbd39/createfile-entry.cmd"
bp kernelbase!GetFinalPathNameByHandleW "$$><C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-98729cffbd39/finalpath-entry.cmd"
bl
.echo OMS_HOME_API_BREAKPOINTS_SET
g
