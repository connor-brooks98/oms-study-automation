.printf "OMS_FINALPATH_ENTER pid=%x tid=%x handle=%p buffer=%p capacity=%x flags=%x\n", @$tpid, @$tid, @rcx, @rdx, @r8d, @r9d
~.bp /1 poi(@rsp) ".printf \"OMS_FINALPATH_RETURN pid=%x tid=%x length=%x\\n\", @$tpid, @$tid, @eax;!gle;gc"
gc
