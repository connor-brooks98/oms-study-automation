$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-98729cffbd39';$files=@{
  'probe-windows-lpac.ps1'='4dbcd2e33311689bf9d8f06c86d76809260b0f4dd32950a4b726408a816ff294'
  'probe-interactive.ps1'='9b8a042adc6ab76180b4dd42619623b908f8e0509e17151d470597ed894ef036'
  'run-lpac-task.ps1'='f04459f9b668f7d54cfcde1b1c7090bb6bc9876d421d3bfff743f127c0205bbd'
  'debugger.cmd'='1f360a3ddb7e6048b1249cc0ec5e0e5d9bf2a87c6f6eb5bd6d839484423ffdcd'
  'arm-home-trace.cmd'='3896f3238368938f757be6517cf3bf8d7881c3385ee92ac7ead39183b61db1ad'
  'kernelbase.cmd'='f18d4af4e25a1e5958919e0249cc39060b35794adb489d035eee476435c4a93a'
  'createfile-entry.cmd'='80ecd4501f3fbd42f10f6064b1d3865d36bb796a91eeb7efec781193f045f897'
  'finalpath-entry.cmd'='e275a77c7fa0bb520860adff2dd82ce4c530c8cbcea389b3f2cfe1eb9149f739'
  'symbols/ntdll.pdb'='879596b54dc0b944e47160dcba01bac56fbc13eaed41fcad50897c6fdd730d1f'
  'symbols/kernelbase.pdb'='a440229ee962ea3034f3c282ad0dd9dd3b912855af21672b9ed67ea7787f4c90'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$parseErrors=$null;if($name.EndsWith('.ps1')){$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);$parseErrors=@($errors).Count;if($parseErrors){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"}};$result+=@{name=$name;sha256=$hash;parse_errors=$parseErrors}};ConvertTo-Json -InputObject $result -Depth 3
