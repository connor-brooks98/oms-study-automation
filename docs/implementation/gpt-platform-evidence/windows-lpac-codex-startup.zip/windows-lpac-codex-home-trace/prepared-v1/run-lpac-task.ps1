$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$name='OMS GPT LPAC Codex Home Trace 98729cffbd39'
$stage='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-98729cffbd39/run'
if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){throw 'diagnostic task already exists'}
$hub=Get-ScheduledTask -TaskName 'OMS Study Hub V2'
if($hub.Principal.UserId -ne 'conbr' -or [int]$hub.Principal.LogonType -ne 3 -or [int]$hub.Principal.RunLevel -ne 0){throw 'live task identity drift'}
if((Get-FileHash -LiteralPath 'C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-98729cffbd39/probe-interactive.ps1' -Algorithm SHA256).Hash.ToLower() -ne '9b8a042adc6ab76180b4dd42619623b908f8e0509e17151d470597ed894ef036'){throw 'diagnostic script hash mismatch'}
$action=New-ScheduledTaskAction -Execute 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -Argument '-NoLogo -NoProfile -NonInteractive -EncodedCommand JABwAD0AJwBDADoALwBVAHMAZQByAHMALwBjAG8AbgBiAHIALwBBAHAAcABEAGEAdABhAC8ATABvAGMAYQBsAC8ATwBNAFMAUwB0AHUAZAB5AEgAdQBiAC8AYQBjAGMAZQBwAHQAYQBuAGMAZQAvAGwAcABhAGMALQA5ADgANwAyADkAYwBmAGYAYgBkADMAOQAvAHAAcgBvAGIAZQAtAGkAbgB0AGUAcgBhAGMAdABpAHYAZQAuAHAAcwAxACcAOwAgAGkAZgAoACgARwBlAHQALQBGAGkAbABlAEgAYQBzAGgAIAAtAEwAaQB0AGUAcgBhAGwAUABhAHQAaAAgACQAcAAgAC0AQQBsAGcAbwByAGkAdABoAG0AIABTAEgAQQAyADUANgApAC4ASABhAHMAaAAuAFQAbwBMAG8AdwBlAHIAKAApACAALQBuAGUAIAAnADkAYgA4AGEAMAA0ADIAYQBkAGMANgBhAGIANwA2ADEAOAAwAGIANABkAGQANAAyADYAMQA5ADYAMgAzAGIAOQAwADgAZgA4AGUAMAA1ADAAOQBlADEANwAxADUAMQBkADQANwAwADUAOQA3AGUAZAA4ADkANABlAGYAMAAzADYAJwApAHsAdABoAHIAbwB3ACAAJwBpAG4AbgBlAHIAIABoAGEAcwBoACAAbQBpAHMAbQBhAHQAYwBoACcAfQA7ACAAJgAgACgAWwBzAGMAcgBpAHAAdABiAGwAbwBjAGsAXQA6ADoAQwByAGUAYQB0AGUAKABbAEkATwAuAEYAaQBsAGUAXQA6ADoAUgBlAGEAZABBAGwAbABUAGUAeAB0ACgAJABwACkAKQApAA==' -WorkingDirectory 'C:\Users\conbr\AppData\Local\OMSStudyHub\acceptance'
$principal=New-ScheduledTaskPrincipal -UserId 'conbr' -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Seconds 110) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$task=New-ScheduledTask -Action $action -Principal $principal -Settings $settings
$outerPre=Invoke-RestMethod -TimeoutSec 5 http://127.0.0.1:8765/health
if($outerPre.status -ne 'ok' -or $outerPre.build_revision -ne 'f487c6229b91d2b1ac11729e465561f6c1ffe997' -or $outerPre.build_tree -ne 'a9f7cc7f9c03040cb63ccea3ef05b70add443e6a' -or $outerPre.schema_version -ne 31){throw 'live health drift'}
$preListeners=@(Get-NetTCPConnection -LocalPort 8765 -State Listen);if($preListeners.Count -ne 1 -or $preListeners[0].OwningProcess -ne 8268){throw 'listener drift'}
foreach($workerName in @('generation_worker','ingestion_worker','studio_worker')){if(-not $outerPre.workers.$workerName.alive -or $outerPre.workers.$workerName.current_error -or $outerPre.workers.$workerName.start_count -ne 1){throw 'worker drift'}}
$outerProcesses=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -in @('codex.exe','python.exe','pythonw.exe','cmd.exe','csc.exe','cdb.exe') -or $_.Name -like 'codex-command-runner*'} | Select-Object Name,ProcessId,ParentProcessId,CreationDate)
$baselineKeys=@($outerProcesses | ForEach-Object {"$($_.ProcessId)|$($_.CreationDate.ToUniversalTime().ToString('o'))"})
@{health=$outerPre;listeners=$preListeners;processes=$outerProcesses} | ConvertTo-Json -Depth 9 | Set-Content -Encoding UTF8 "$(Split-Path $stage)/outer-preflight.json"
function Stop-Owned {
  foreach($row in @($script:owned | Sort-Object @{Expression={if($_.name -eq 'cdb.exe'){1}else{0}};Descending=$true}, @{Expression='start_utc';Descending=$true})){
    if($null -eq $row -or $row -is [Array] -or $row.pid -is [Array]){throw 'invalid owned process record shape'}
    $ownedPid=0;$ownedStart=[DateTime]::MinValue
    if(-not [int]::TryParse([string]$row.pid,[ref]$ownedPid) -or $ownedPid -le 0 -or $row.name -isnot [string] -or $row.name -notmatch '^[A-Za-z0-9_. -]+\.exe$' -or $row.start_utc -isnot [string] -or -not [DateTime]::TryParseExact($row.start_utc,'o',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind,[ref]$ownedStart) -or $ownedStart.Kind -ne [DateTimeKind]::Utc){throw 'invalid owned process id/name/start time'}
    $target=$null
    try {
      try {$target=[Diagnostics.Process]::GetProcessById($ownedPid)} catch [ArgumentException] {continue}
      $null=$target.Handle
      if($target.HasExited){continue}
      if($target.StartTime.ToUniversalTime().ToString('o') -ne $row.start_utc -or $target.ProcessName -ne [IO.Path]::GetFileNameWithoutExtension($row.name)){throw 'owned PID identity changed; refuse kill'}
      $target.Kill();if(-not $target.WaitForExit(5000)){throw 'owned process not reaped'}
    } finally {if($null -ne $target){$target.Dispose()}}
  }
}
$registered=$false;$disabled=$false;$cleanupError=$null
try {
  Register-ScheduledTask -TaskName $name -InputObject $task | Out-Null
  $registered=$true
  $created=Get-ScheduledTask -TaskName $name
  if([int]$created.Principal.LogonType -ne 3 -or [int]$created.Principal.RunLevel -ne 0 -or @($created.Triggers | Where-Object { $null -ne $_ }).Count -ne 0){throw 'created diagnostic task differs'}
  Start-ScheduledTask -TaskName $name
  $deadline=(Get-Date).AddSeconds(115)
  do {
    Start-Sleep -Milliseconds 500
    $running=(Get-ScheduledTask -TaskName $name).State -eq 'Running'
  } while((( -not (Test-Path "$stage/result.json")) -or $running) -and (Get-Date) -lt $deadline)
  if($running){Stop-ScheduledTask -TaskName $name;throw 'only diagnostic task stopped after deadline'}
  if(-not (Test-Path "$stage/result.json")){throw 'diagnostic result absent'}
  if((Get-ScheduledTaskInfo -TaskName $name).LastTaskResult -ne 0){throw 'diagnostic task failed'}
  $r=Get-Content -Raw "$stage/result.json" | ConvertFrom-Json
  if(-not $r.passed -or $r.session_id -ne 1 -or $r.admin_token -or -not $r.postflight_ok -or $r.exit_code -ne 0 -or $r.timed_out){throw 'interactive LPAC probe failed'}
  $r | ConvertTo-Json -Depth 5
 } finally {
  if($registered){
    try {if((Get-ScheduledTask -TaskName $name).State -eq 'Running'){Stop-ScheduledTask -TaskName $name}} catch {$cleanupError+="task stop: $($_.Exception)`n"}
    try {
      Disable-ScheduledTask -TaskName $name | Out-Null
      $t=Get-ScheduledTask -TaskName $name
      $disabled=($t.State -eq 'Disabled')
      $info=Get-ScheduledTaskInfo -TaskName $name
      @{task=$name;state=[string]$t.State;logon_type=[int]$t.Principal.LogonType;run_level=[int]$t.Principal.RunLevel;last_result=$info.LastTaskResult} | ConvertTo-Json
    } catch {$cleanupError+="task disable/state: $($_.Exception)`n"}
  }
  try {if(Test-Path -LiteralPath "$stage/owned-processes.json"){$decoded=Get-Content -Raw -LiteralPath "$stage/owned-processes.json" | ConvertFrom-Json;$script:owned=@($decoded);Stop-Owned}} catch {$cleanupError+="owned cleanup: $($_.Exception)`n"}
  $preserved=$false;$outerHealth=$null;$outerListeners=@();$outerHelpers=@();$finalProcesses=@();$newProcesses=@();$missingProcesses=@();$postflightError=$null
  try {
    $outerHealth=Invoke-RestMethod -TimeoutSec 5 http://127.0.0.1:8765/health
    $outerListeners=@(Get-NetTCPConnection -LocalPort 8765 -State Listen | Select-Object OwningProcess)
    $outerHelpers=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -like 'codex-command-runner*'} | Select-Object Name,ProcessId,ParentProcessId,CreationDate)
    $finalProcesses=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -in @('codex.exe','python.exe','pythonw.exe','cmd.exe','csc.exe','cdb.exe') -or $_.Name -like 'codex-command-runner*'} | Select-Object Name,ProcessId,ParentProcessId,CreationDate)
    $newProcesses=@($finalProcesses | Where-Object {"$($_.ProcessId)|$($_.CreationDate.ToUniversalTime().ToString('o'))" -notin $baselineKeys})
    $finalKeys=@($finalProcesses | ForEach-Object {"$($_.ProcessId)|$($_.CreationDate.ToUniversalTime().ToString('o'))"})
    $missingProcesses=@($outerProcesses | Where-Object {"$($_.ProcessId)|$($_.CreationDate.ToUniversalTime().ToString('o'))" -notin $finalKeys})
    $preserved=($outerHealth.status -eq 'ok' -and $outerHealth.build_revision -eq $outerPre.build_revision -and $outerHealth.build_tree -eq $outerPre.build_tree -and $outerHealth.schema_version -eq $outerPre.schema_version -and $outerListeners.Count -eq 1 -and $outerListeners[0].OwningProcess -eq 8268 -and $outerHelpers.Count -eq 0 -and $newProcesses.Count -eq 0 -and $missingProcesses.Count -eq 0 -and $null -eq $cleanupError)
    foreach($workerName in @('generation_worker','ingestion_worker','studio_worker')){if(-not $outerHealth.workers.$workerName.alive -or $outerHealth.workers.$workerName.current_error -or $outerHealth.workers.$workerName.start_count -ne $outerPre.workers.$workerName.start_count){$preserved=$false}}
  } catch {$postflightError=$_.Exception.ToString();$preserved=$false}
  finally {
    $outerResult=@{utc=(Get-Date).ToUniversalTime().ToString('o');outer_postflight_ok=$preserved;health=$outerHealth;listeners=$outerListeners;helpers=$outerHelpers;processes=$finalProcesses;new_processes=$newProcesses;missing_processes=$missingProcesses;cleanup_error=$cleanupError;postflight_error=$postflightError;task_disabled=$disabled}
    $outerResult | ConvertTo-Json -Depth 9 | Set-Content -Encoding UTF8 "$(Split-Path $stage)/outer-postflight.json"
    $outerResult | ConvertTo-Json -Depth 9
  }
  if(-not $preserved -or ($registered -and -not $disabled)){throw 'outer postflight or diagnostic disable failed'}
}
