.printf "OMS_CREATEFILE_ENTER pid=%x tid=%x access=%x share=%x disposition=%x flags=%x path=%mu\n", @$tpid, @$tid, @edx, @r8d, dwo(@rsp+0x28), dwo(@rsp+0x30), @rcx
~.bp /1 poi(@rsp) ".printf \"OMS_CREATEFILE_RETURN pid=%x tid=%x handle=%p\\n\", @$tpid, @$tid, @rax;!gle;gc"
gc
