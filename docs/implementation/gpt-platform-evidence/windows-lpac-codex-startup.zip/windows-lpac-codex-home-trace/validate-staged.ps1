$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-98729cffbd39';$files=@{
  'probe-windows-lpac.ps1'='4dbcd2e33311689bf9d8f06c86d76809260b0f4dd32950a4b726408a816ff294'
  'probe-interactive.ps1'='c4211f1ed14727cc2c69362d6f8285cd5812f727644ae0462aeca98e06a81fe0'
  'run-lpac-task.ps1'='eddd03c7ac776c9492c9423d66ba2c21393fbcf7980c4a8913634dcfef862f25'
  'debugger.cmd'='c913f78bf910794dd48ccd2ba40a59bd504acc4010a82bdd33c6326c130de3ad'
  'arm-home-trace.cmd'='2642aa187c4bad9fb7ac444238abf2b6301d3b976430435fb337737f3ddb5d17'
  'kernelbase.cmd'='f276694515f3c19c2a1a20c7f6b7f42cd22add20bc9a0f9f78978f8c22e8f8b7'
  'createfile-entry.cmd'='51c1d17fb5b8e3b95db988e48ac7582f811937e0c66fdc6fea6d0350eb2a112d'
  'finalpath-entry.cmd'='2b66bdec62b72df3665585c1e15d35f912ac13b708976417db1399b90a0f1018'
  'symbols/ntdll.pdb'='879596b54dc0b944e47160dcba01bac56fbc13eaed41fcad50897c6fdd730d1f'
  'symbols/kernelbase.pdb'='a440229ee962ea3034f3c282ad0dd9dd3b912855af21672b9ed67ea7787f4c90'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$parseErrors=$null;if($name.EndsWith('.ps1')){$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);$parseErrors=@($errors).Count;if($parseErrors){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"}};$result+=@{name=$name;sha256=$hash;parse_errors=$parseErrors}};ConvertTo-Json -InputObject $result -Depth 3
