$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-4a67ba02c220';$files=@{
  'probe-windows-lpac.ps1'='3b59cb24f4b1e5cc61befeda13c57985a8bd451648c18fb6db2b5b6b32dfc88f'
  'probe-interactive.ps1'='c82dde9e1b29954acb2874d256f3bc196bd32ccb9910a8da24b631667a75d260'
  'run-lpac-task.ps1'='a4d51163092d59be953d40f1cdd23b80f6ee736cac9654e95f7db9b9d633f8da'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
