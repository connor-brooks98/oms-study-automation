# Read current-process token metadata only. No token changes, process/profile creation or LPAC launch.
$ErrorActionPreference='Stop'
if($PSVersionTable.PSEdition -ne 'Desktop' -or -not [Environment]::Is64BitProcess){throw '64-bit Windows PowerShell Desktop required'}
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public sealed class OmsTokenQueryRow {
    public string Test; public int Kind; public bool ReturnValue; public int LastError; public int Needed;
    public bool GuardPassed; public int? Value;
}
public static class OmsTokenQuery {
    [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool CloseHandle(IntPtr handle);
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool OpenProcessToken(IntPtr process, uint access, out IntPtr token);
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool GetTokenInformation(IntPtr token, int kind, IntPtr data, int length, out int needed);
    [DllImport("ntdll.dll")] static extern int NtQueryInformationToken(IntPtr token, int kind, IntPtr data, int length, out int needed);
    public static OmsTokenQueryRow[] Run() {
        List<OmsTokenQueryRow> rows = new List<OmsTokenQueryRow>();
        IntPtr token = IntPtr.Zero, data = IntPtr.Zero;
        try {
            bool opened = OpenProcessToken(GetCurrentProcess(), 8, out token);
            int openError = Marshal.GetLastWin32Error();
            rows.Add(new OmsTokenQueryRow { Test="open-current-token-query-only", ReturnValue=opened, LastError=openError });
            if (!opened) return rows.ToArray();
            int needed;
            bool original = GetTokenInformation(token, 20, IntPtr.Zero, 0, out needed);
            bool originalGuard = !original && Marshal.GetLastWin32Error() == 122 && needed > 0 && needed <= 65536;
            int originalError = Marshal.GetLastWin32Error();
            rows.Add(new OmsTokenQueryRow { Test="original-compound-size-guard", Kind=20, ReturnValue=original, LastError=originalError, Needed=needed, GuardPassed=originalGuard });
            bool snapshot = GetTokenInformation(token, 20, IntPtr.Zero, 0, out needed);
            int snapshotError = Marshal.GetLastWin32Error();
            rows.Add(new OmsTokenQueryRow { Test="immediate-error-size-guard", Kind=20, ReturnValue=snapshot, LastError=snapshotError, Needed=needed,
                GuardPassed=!snapshot && snapshotError == 122 && needed > 0 && needed <= 65536 });
            data = Marshal.AllocHGlobal(4);
            foreach (int kind in new int[] {20, 12, 29, 46}) {
                Marshal.WriteInt32(data, -1);
                bool ok = GetTokenInformation(token, kind, data, 4, out needed);
                int error = Marshal.GetLastWin32Error();
                rows.Add(new OmsTokenQueryRow { Test="fixed-dword-query", Kind=kind, ReturnValue=ok, LastError=error, Needed=needed,
                    GuardPassed=ok && needed == 4, Value=ok && needed == 4 ? (int?)Marshal.ReadInt32(data) : null });
            }
            int status = NtQueryInformationToken(token, 46, data, 4, out needed);
            rows.Add(new OmsTokenQueryRow { Test="nt-query-fixed-dword-status-in-last-error", Kind=46, ReturnValue=status >= 0, LastError=status, Needed=needed,
                GuardPassed=status >= 0 && needed == 4, Value=status >= 0 && needed == 4 ? (int?)Marshal.ReadInt32(data) : null });
            return rows.ToArray();
        } finally { if(data != IntPtr.Zero) Marshal.FreeHGlobal(data); if(token != IntPtr.Zero) CloseHandle(token); }
    }
}
'@
[OmsTokenQuery]::Run() | ConvertTo-Json -Depth 4
