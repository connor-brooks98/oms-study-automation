$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$stage='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-4a67ba02c220'
$root="$stage/run"
$profile='oms-lpac-4a67ba02c22048d99a21419ccbe5cdca'
$probeHash='3b59cb24f4b1e5cc61befeda13c57985a8bd451648c18fb6db2b5b6b32dfc88f'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=[Security.Principal.WindowsPrincipal]::new($identity)
$admin=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$session=[Diagnostics.Process]::GetCurrentProcess().SessionId
if($session -ne 1 -or $admin -or $identity.Name -ne 'Connors_NUC\conbr'){throw 'not approved limited interactive identity'}
if(Test-Path -LiteralPath $root){throw 'run fixture exists; no retry'}
New-Item -ItemType Directory -Path $root | Out-Null
$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetAccessRuleProtection($true,$false);$acl.SetOwner($identity.User)
$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($identity.User,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))
Set-Acl -LiteralPath $root -AclObject $acl
$script:owned=@();$process=$null;$outFile=$null;$errFile=$null;$outTask=$null;$errTask=$null
$started=$false;$timedOut=$false;$exitCode=$null;$errorText=$null;$pre=$null;$post=$null;$preserved=$false;$native=$null
function Snapshot {
  @{utc=(Get-Date).ToUniversalTime().ToString('o');health=(Invoke-RestMethod -TimeoutSec 5 http://127.0.0.1:8765/health);listeners=@(Get-NetTCPConnection -LocalPort 8765 -State Listen | Select-Object OwningProcess);processes=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -in @('codex.exe','python.exe','pythonw.exe','cmd.exe','csc.exe') -or $_.Name -like 'codex-command-runner*'} | Select-Object Name,ProcessId,ParentProcessId,CreationDate)}
}
function Save-Owned {
  ConvertTo-Json -InputObject @($script:owned) -Depth 4 | Set-Content -Encoding UTF8 "$root/owned-processes.json"
}
function Track-Children {
  $rows=@(Get-CimInstance Win32_Process | Select-Object Name,ProcessId,ParentProcessId,CreationDate)
  do {
    $added=$false;$ids=@($script:owned | ForEach-Object {$_.pid})
    foreach($row in $rows){
      $parent=@($rows | Where-Object {
        $candidate=$_
        $candidate.ProcessId -eq $row.ParentProcessId -and @($script:owned | Where-Object {$_.pid -eq $candidate.ProcessId -and $_.creation_utc -eq $candidate.CreationDate.ToUniversalTime().ToString('o')}).Count -eq 1
      })
      if($row.ProcessId -notin $ids -and $parent.Count -eq 1 -and $row.CreationDate -ge $parent[0].CreationDate){
        $child=$null
        try {
          try {$child=[Diagnostics.Process]::GetProcessById($row.ProcessId)} catch [ArgumentException] {continue}
          $null=$child.Handle
          if($child.HasExited){continue}
          $childStart=$child.StartTime.ToUniversalTime()
          if($child.ProcessName -ne [IO.Path]::GetFileNameWithoutExtension($row.Name) -or [Math]::Abs(($childStart-$row.CreationDate.ToUniversalTime()).Ticks) -ge 10){throw 'child identity changed during inventory'}
          $script:owned+=@{pid=[int]$row.ProcessId;name=$row.Name;start_utc=$childStart.ToString('o');creation_utc=$row.CreationDate.ToUniversalTime().ToString('o');parent_pid=[int]$row.ParentProcessId}
          $added=$true
        } finally {if($null -ne $child){$child.Dispose()}}
      }
    }
  } while($added)
  Save-Owned
}
function Stop-Owned {
  foreach($row in @($script:owned | Sort-Object start_utc -Descending)){
    if($null -eq $row -or $row -is [Array] -or $row.pid -is [Array]){throw 'invalid owned process record shape'}
    $ownedPid=0;$ownedStart=[DateTime]::MinValue
    if(-not [int]::TryParse([string]$row.pid,[ref]$ownedPid) -or $ownedPid -le 0 -or $row.name -isnot [string] -or $row.name -notmatch '^[A-Za-z0-9_. -]+\.exe$' -or $row.start_utc -isnot [string] -or -not [DateTime]::TryParseExact($row.start_utc,'o',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind,[ref]$ownedStart) -or $ownedStart.Kind -ne [DateTimeKind]::Utc){throw 'invalid owned process id/name/start time'}
    $target=$null
    try {
      try {$target=[Diagnostics.Process]::GetProcessById($ownedPid)} catch [ArgumentException] {continue}
      $null=$target.Handle
      if($target.HasExited){continue}
      if($target.StartTime.ToUniversalTime().ToString('o') -ne $row.start_utc -or $target.ProcessName -ne [IO.Path]::GetFileNameWithoutExtension($row.name)){throw 'owned PID identity changed; refuse kill'}
      $target.Kill();if(-not $target.WaitForExit(5000)){throw 'owned process not reaped'}
    } finally {if($null -ne $target){$target.Dispose()}}
  }
}
try {
  $pre=Snapshot;$pre | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 "$root/preflight.json"
  if($pre.health.status -ne 'ok' -or $pre.health.build_revision -ne 'f487c6229b91d2b1ac11729e465561f6c1ffe997' -or $pre.health.build_tree -ne 'a9f7cc7f9c03040cb63ccea3ef05b70add443e6a' -or $pre.health.schema_version -ne 31 -or $pre.listeners.Count -ne 1 -or $pre.listeners[0].OwningProcess -ne 8268){throw 'Hub preflight drift'}
  foreach($worker in @('generation_worker','ingestion_worker','studio_worker')){if(-not $pre.health.workers.$worker.alive -or $pre.health.workers.$worker.current_error -or $pre.health.workers.$worker.start_count -ne 1){throw 'worker preflight drift'}}
  $powershell='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
  $cmd='C:\Windows\System32\cmd.exe'
  if((Get-FileHash -LiteralPath $powershell -Algorithm SHA256).Hash.ToLower() -ne '8bb6fa8c283b4d92120b1ef249a9b311b0f804d4cabbe9981159976c8be76a5e'){throw 'PowerShell pin mismatch'}
  if((Get-FileHash -LiteralPath $cmd -Algorithm SHA256).Hash.ToLower() -ne '97ac98b1a92c286054cce55239cfccdfc23a5517bd07fe693072c9ca96c7dabb'){throw 'cmd pin mismatch'}
  if((Get-FileHash -LiteralPath "$stage/probe-windows-lpac.ps1" -Algorithm SHA256).Hash.ToLower() -ne $probeHash){throw 'LPAC script pin mismatch'}
  $inventory=@();foreach($path in @($powershell,$cmd,'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe','C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe')){
    $exists=Test-Path -LiteralPath $path;$entry=@{path=$path;exists=$exists}
    if($exists){$entry.sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();$entry.version=(Get-Item -LiteralPath $path).VersionInfo.FileVersion};$inventory+=$entry
  }
  ConvertTo-Json -InputObject $inventory -Depth 4 | Set-Content -Encoding UTF8 "$root/runtime-inventory.json"
  $text='$ErrorActionPreference=''Stop''; $p='''+"$stage/probe-windows-lpac.ps1"+'''; if((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower() -ne '''+$probeHash+'''){throw ''probe hash mismatch''}; & ([scriptblock]::Create([IO.File]::ReadAllText($p))) -FixtureParent '''+$root+''' -ProfileName '''+$profile+''''
  $start=[Diagnostics.ProcessStartInfo]::new();$start.FileName=$powershell
  $start.Arguments='-NoLogo -NoProfile -NonInteractive -EncodedCommand '+[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($text))
  $start.WorkingDirectory=$root;$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
  $start.EnvironmentVariables.Clear()
  foreach($key in @('SystemRoot','WINDIR')){$start.EnvironmentVariables[$key]='C:\Windows'}
  # Current-user profile identity is required for CreateAppContainerProfile; do not redirect it.
  foreach($key in @('USERPROFILE','APPDATA','LOCALAPPDATA')){$start.EnvironmentVariables[$key]=[Environment]::GetEnvironmentVariable($key)}
  $start.EnvironmentVariables['TEMP']=$root;$start.EnvironmentVariables['TMP']=$root
  $process=[Diagnostics.Process]::new();$process.StartInfo=$start
  $outFile=[IO.File]::Open("$root/probe.stdout",[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  $errFile=[IO.File]::Open("$root/probe.stderr",[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  $started=$process.Start();if(-not $started){throw 'probe did not start'}
  $rootRow=Get-CimInstance Win32_Process -Filter "ProcessId=$($process.Id)"
  if($rootRow.Name -ne 'powershell.exe' -or [Math]::Abs(($process.StartTime.ToUniversalTime()-$rootRow.CreationDate.ToUniversalTime()).Ticks) -ge 10){throw 'root process identity drift'}
  $script:owned+=@{pid=$process.Id;name='powershell.exe';start_utc=$process.StartTime.ToUniversalTime().ToString('o');creation_utc=$rootRow.CreationDate.ToUniversalTime().ToString('o');parent_pid=$PID};Save-Owned
  $outTask=$process.StandardOutput.BaseStream.CopyToAsync($outFile);$errTask=$process.StandardError.BaseStream.CopyToAsync($errFile)
  $deadline=(Get-Date).AddSeconds(60)
  do {Track-Children;$done=$process.WaitForExit(250)} while(-not $done -and (Get-Date) -lt $deadline)
  $timedOut=-not $done
  if($timedOut){Stop-Owned}
  if(-not $process.WaitForExit(5000)){throw 'probe not reaped'}
  $exitCode=$process.ExitCode
  if(-not $outTask.Wait(5000) -or -not $errTask.Wait(5000)){throw 'raw output capture did not finish'}
  if(Test-Path -LiteralPath "$root/$profile/result.json"){$native=Get-Content -Raw -LiteralPath "$root/$profile/result.json" | ConvertFrom-Json}
} catch {$errorText=$_.Exception.ToString()}
finally {
  try {Stop-Owned} catch {$errorText+="`ncleanup: $($_.Exception)"}
  try {if($started -and -not $process.HasExited){$process.Kill();if(-not $process.WaitForExit(5000)){throw 'owned root not reaped'}}} catch {$errorText+="`nroot cleanup: $($_.Exception)"}
  foreach($stream in @($outFile,$errFile)){if($null -ne $stream){$stream.Dispose()}}
  if($null -ne $process){$process.Dispose()}
  try {
    $post=Snapshot;$post | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 "$root/postflight.json"
    if($null -ne $pre){
      $before=@($pre.processes | ForEach-Object {"$($_.Name)|$($_.ProcessId)|$($_.CreationDate.ToUniversalTime().ToString('o'))"})
      $after=@($post.processes | ForEach-Object {"$($_.Name)|$($_.ProcessId)|$($_.CreationDate.ToUniversalTime().ToString('o'))"})
      $preserved=($post.health.status -eq 'ok' -and $post.health.build_revision -eq $pre.health.build_revision -and $post.health.build_tree -eq $pre.health.build_tree -and $post.health.schema_version -eq $pre.health.schema_version -and $post.listeners.Count -eq 1 -and $post.listeners[0].OwningProcess -eq 8268 -and @(Compare-Object $before $after).Count -eq 0)
      foreach($worker in @('generation_worker','ingestion_worker','studio_worker')){if(-not $post.health.workers.$worker.alive -or $post.health.workers.$worker.current_error -or $post.health.workers.$worker.start_count -ne $pre.health.workers.$worker.start_count){$preserved=$false}}
    }
  } catch {$errorText+="`npostflight: $($_.Exception)"}
  $passed=($null -eq $errorText -and $preserved -and -not $timedOut -and $exitCode -eq 0 -and $null -ne $native -and $native.status -eq 'passed' -and $native.native_result.Passed)
  @{passed=$passed;identity=$identity.Name;session_id=$session;admin_token=$admin;started=$started;timed_out=$timedOut;exit_code=$exitCode;postflight_ok=$preserved;error=$errorText;probe_sha256=$probeHash;profile_name=$profile;owned_processes=$script:owned;native_result=$native} | ConvertTo-Json -Depth 12 | Set-Content -Encoding UTF8 "$root/result.json"
}
if(-not $passed){exit 1}
