from pathlib import Path
import json,subprocess,base64,datetime
p=Path(__file__).resolve().parent
with (p/'codex-lto-graph-20260913-task-launch-once.json').open('x') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},f)
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','nuc','powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode((p/'codex-build-lto-graph-20260913-launch.ps1').read_text().encode('utf-16le')).decode()]
(p/'codex-lto-graph-20260913-task-launch.command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (p/'codex-lto-graph-20260913-task-launch.stdout').open('xb') as out,(p/'codex-lto-graph-20260913-task-launch.stderr').open('xb') as err:
 r=subprocess.run(cmd,stdout=out,stderr=err,timeout=30)
print(r.returncode)
