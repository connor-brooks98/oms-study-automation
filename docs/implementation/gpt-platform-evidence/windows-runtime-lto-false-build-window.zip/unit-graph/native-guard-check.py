import runpy,json,hashlib
from pathlib import Path
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/codex-build-lto-graph-20260913-guard.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='a1323afa0e7caeb90540a2a26af2444346102f4807c66b32ff963ad44807a043'
g=runpy.run_path(str(p))
print(json.dumps(g["health"]("preflight"),indent=2))
