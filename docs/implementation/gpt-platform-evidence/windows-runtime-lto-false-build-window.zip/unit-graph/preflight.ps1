$ErrorActionPreference='Stop'
$ci = & 'C:/Windows/System32/CiTool.exe' -lp -json
$ciExit=$LASTEXITCODE
if($ciExit -ne 0){throw "CiTool read failed: $ciExit"}
$policy=($ci -join "`n") | ConvertFrom-Json
$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
$h=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/health' -TimeoutSec 5
$listeners=@(Get-NetTCPConnection -State Listen -LocalPort 8765 | Select-Object LocalAddress,OwningProcess)
$owned=@(Get-CimInstance Win32_Process | Where-Object {$_.ExecutablePath -like '*runtime-build-734bbdfad4a9*' -or $_.CommandLine -like '*runtime-build-734bbdfad4a9*'} | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine)
$tasks=@(Get-ScheduledTask -TaskName 'OMS GPT Private Runtime Build 734bbdfad4a9*' | ForEach-Object {@{name=$_.TaskName;state=[string]$_.State;enabled=$_.Settings.Enabled}})
@{utc=(Get-Date).ToUniversalTime().ToString('o');policy=$policy;memory=($m | Select-Object AvailableBytes,CommittedBytes,CommitLimit);health=$h;listeners=$listeners;owned_processes=$owned;tasks=$tasks} | ConvertTo-Json -Depth 12
