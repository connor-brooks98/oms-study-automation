$ErrorActionPreference='Stop'
$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9'
$name='OMS GPT Private Runtime Build 734bbdfad4a9 lto-graph 20260913'
if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){throw 'fresh build task already exists'}
if(Test-Path -LiteralPath "$root/codex-build-lto-graph-20260913-once.json"){throw 'build launch already consumed'}
if((Get-FileHash -LiteralPath "$root/build-codex-lto-graph-20260913.py" -Algorithm SHA256).Hash.ToLower() -ne '0c0436ca611d96579726f5b21fec6bc45ac5d62f494685bb7395ef766cde1bcd'){throw 'build script hash mismatch'}
$action=New-ScheduledTaskAction -Execute 'C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe' -Argument ('-B -I "'+$root+'/build-codex-lto-graph-20260913.py"') -WorkingDirectory 'C:/'
$principal=New-ScheduledTaskPrincipal -UserId 'conbr' -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -MultipleInstances IgnoreNew -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$task=New-ScheduledTask -Action $action -Principal $principal -Settings $settings
$null=Register-ScheduledTask -TaskName $name -InputObject $task
Export-ScheduledTask -TaskName $name | Set-Content -Encoding UTF8 "$root/codex-build-lto-graph-20260913-task.xml"
Start-ScheduledTask -TaskName $name
@{task_name=$name;state=[string](Get-ScheduledTask -TaskName $name).State;script_sha256='0c0436ca611d96579726f5b21fec6bc45ac5d62f494685bb7395ef766cde1bcd';utc=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json
