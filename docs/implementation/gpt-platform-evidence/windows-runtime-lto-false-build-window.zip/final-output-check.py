from pathlib import Path
import json,datetime
r=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9');t=r/'target/codex-no-lto-20260913';e=t/'x86_64-pc-windows-msvc/release/codex.exe'
print(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),target_exists=t.is_dir(),target_reparse=bool(t.lstat().st_file_attributes & 0x400),executable_exists=e.exists(),path=str(e))))
