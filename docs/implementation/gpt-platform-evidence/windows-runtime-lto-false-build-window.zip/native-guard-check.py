import runpy,json,hashlib
from pathlib import Path
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/codex-build-nolto-20260913-guard.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='2cba2a7035f78d9822aceffae491d8192ca54b09ac0c146da25d1f38b1c44aa7'
g=runpy.run_path(str(p))
print(json.dumps(g["health"]("preflight"),indent=2))
