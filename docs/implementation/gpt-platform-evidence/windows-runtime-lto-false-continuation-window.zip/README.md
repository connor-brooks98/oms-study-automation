Prepared-only no-LTO continuation — not staged or launched.

The first no-LTO run reached its normal 90-minute timeout, with returncode124/timed_out=true, no cleanup/query errors, disabled task, zero owned processes and exact Hub preservation. Actual result/summary/stderr hashes are now bound; continuation-gate.json records exact local reconciliation/output-check/summary hashes. The previous unbound preparation is retained in prepared-unbound/. Final bound independent review is still required before staging or launch.

The driver is the current reviewed no-LTO driver with only fresh nolto2 task/log/once/guard names. Environment is byte-identical: CARGO_PROFILE_RELEASE_LTO=false, serial -j1, same target codex-no-lto-20260913 and short c2 cache, same pinned source/toolchain/std/arg0/lock/V8. There is no cross-crate LTO; local ThinLTO remains eligible. The existing target is retained for normal Cargo cache reuse; all prior logs remain immutable. Native staging requires target exists and final codex.exe is absent.

Limits remain 90 minutes, BelowNormal, 9.5 GiB owned kill-on-close job, preflight 11.5 GiB commit/13.5 GiB physical, ongoing 2 GiB commit/4 GiB physical floors at nominal 5-second cadence, Hub guard 30 seconds, Limited no-trigger task with 92-minute outer limit. No deadline extension, concurrent build, policy/pagefile/shared change, runtime execution or provider request is authorized by preparation.

Review normalized-delta.diff and prepared-hashes.json. After terminal evidence and final binding review, refresh read-only preflight, run stage-fresh-build.py, native hash/guard check, and the hash-bound launch-codex-build-nolto2-20260913.py once. Actual invocation remains gated; do not run task scripts directly.
