import runpy,json,hashlib
from pathlib import Path
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9/codex-build-nolto2-20260913-guard.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='5c1664cde78e9f9765196f266ab02e2c223a3c09be2ab30fbc9dd4e7c8dd4ed4'
g=runpy.run_path(str(p))
print(json.dumps(g["health"]("preflight"),indent=2))
