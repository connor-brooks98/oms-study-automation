"""Read only this build's retained progress and bounded log tails through a fresh SSH call."""
from pathlib import Path
import base64,datetime,json,subprocess
p=Path(__file__).resolve().parent;r=json.loads((p/'manifest.json').read_text())['remote_root']
source=f'''from pathlib import Path
import json
p=Path({r!r});out={{}}
for n in ['codex-build-nolto2-20260913-progress.json','codex-build-nolto2-20260913-summary.json','codex-build-nolto2-20260913-result.json']:
 f=p/n
 if f.exists():out[n]=json.loads(f.read_text())
for n in ['codex-build-nolto2-20260913.stdout','codex-build-nolto2-20260913.stderr','codex-build-nolto2-20260913-health.jsonl','codex-build-nolto2-20260913-memory.jsonl']:
 f=p/n
 if f.exists():
  with f.open('rb') as stream:
   stream.seek(max(0,f.stat().st_size-12000));out[n]=stream.read().decode(errors='replace')
print(json.dumps(out))
'''
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','nuc','C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe -B -I -c "import base64;exec(base64.b64decode('+repr(base64.b64encode(source.encode()).decode())+'))"']
folder=p/'codex-nolto2-20260913-progress';folder.mkdir(exist_ok=True);stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');base=folder/stamp
base.with_suffix('.command.json').write_text(json.dumps(cmd,indent=2)+'\n');result=subprocess.run(cmd,capture_output=True,timeout=20);base.with_suffix('.stdout').write_bytes(result.stdout);base.with_suffix('.stderr').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode();out=json.loads(result.stdout)
print(json.dumps({'snapshot':str(base.with_suffix('.stdout')),'state':out.get('codex-build-nolto2-20260913-progress.json'),'stderr_tail':out.get('codex-build-nolto2-20260913.stderr','')[-2500:],'last_memory':out.get('codex-build-nolto2-20260913-memory.jsonl','').splitlines()[-1:],'last_health':out.get('codex-build-nolto2-20260913-health.jsonl','').splitlines()[-1:]},indent=2))
