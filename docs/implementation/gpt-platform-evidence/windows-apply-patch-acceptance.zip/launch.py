from pathlib import Path
import subprocess,base64,json,datetime
p=Path(__file__).parent
command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=2','nuc','powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode((p/'invocation.ps1').read_text().encode('utf-16le')).decode()]
record={'candidate':'a699f7a39f4da562bf057ffc941961cbd7b3dd8f','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timed_out':False}
(p/'launch-record.json').write_text(json.dumps(record))
with (p/'native-launch.stdout').open('xb',buffering=0) as out, (p/'native-launch.stderr').open('xb',buffering=0) as err:
 process=subprocess.Popen(command,stdout=out,stderr=err)
 try:process.wait(timeout=125)
 except subprocess.TimeoutExpired:
  record['timed_out']=True
  process.kill()
  process.wait(timeout=5)
record.update(transport_returncode=process.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(p/'launch-record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
