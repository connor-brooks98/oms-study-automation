$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$name='OMS GPT Patch Acceptance cdf2b00b33fc'
$stage='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/apply-patch-6996bf2f57c4/run'
if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){throw 'diagnostic task already exists'}
$hub=Get-ScheduledTask -TaskName 'OMS Study Hub V2'
if($hub.Principal.UserId -ne 'conbr' -or [int]$hub.Principal.LogonType -ne 3 -or [int]$hub.Principal.RunLevel -ne 0){throw 'live task identity drift'}
if((Get-FileHash -LiteralPath 'C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/apply-patch-6996bf2f57c4/probe-interactive.ps1' -Algorithm SHA256).Hash.ToLower() -ne '40eac7cc155f457f6c9455fba06c061123f54f60db6d00f9148742f3f5519dea'){throw 'diagnostic script hash mismatch'}
$action=New-ScheduledTaskAction -Execute 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -Argument '-NoLogo -NoProfile -NonInteractive -EncodedCommand JABwAD0AJwBDADoALwBVAHMAZQByAHMALwBjAG8AbgBiAHIALwBBAHAAcABEAGEAdABhAC8ATABvAGMAYQBsAC8ATwBNAFMAUwB0AHUAZAB5AEgAdQBiAC8AYQBjAGMAZQBwAHQAYQBuAGMAZQAvAGEAcABwAGwAeQAtAHAAYQB0AGMAaAAtADYAOQA5ADYAYgBmADIAZgA1ADcAYwA0AC8AcAByAG8AYgBlAC0AaQBuAHQAZQByAGEAYwB0AGkAdgBlAC4AcABzADEAJwA7ACAAaQBmACgAKABHAGUAdAAtAEYAaQBsAGUASABhAHMAaAAgAC0ATABpAHQAZQByAGEAbABQAGEAdABoACAAJABwACAALQBBAGwAZwBvAHIAaQB0AGgAbQAgAFMASABBADIANQA2ACkALgBIAGEAcwBoAC4AVABvAEwAbwB3AGUAcgAoACkAIAAtAG4AZQAgACcANAAwAGUAYQBjADcAYwBjADEANQA1AGYANAA1ADcAZgA2AGMAOQA0ADUANQBmAGIAYQAwADYAYwAwADYAMQAxADIAMwBmADUANABmADYAMABkAGIANgBkADAAMABmADkAMQA0ADgANwA0ADIAZgAzAGYANQA1ADEAOQBkAGUAYQAnACkAewB0AGgAcgBvAHcAIAAnAGkAbgBuAGUAcgAgAGgAYQBzAGgAIABtAGkAcwBtAGEAdABjAGgAJwB9ADsAIAAmACAAKABbAHMAYwByAGkAcAB0AGIAbABvAGMAawBdADoAOgBDAHIAZQBhAHQAZQAoAFsASQBPAC4ARgBpAGwAZQBdADoAOgBSAGUAYQBkAEEAbABsAFQAZQB4AHQAKAAkAHAAKQApACkA' -WorkingDirectory 'C:\Users\conbr\AppData\Local\OMSStudyHub\acceptance'
$principal=New-ScheduledTaskPrincipal -UserId 'conbr' -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Seconds 90) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$task=New-ScheduledTask -Action $action -Principal $principal -Settings $settings
$outerPre=Invoke-RestMethod http://127.0.0.1:8765/health
if($outerPre.status -ne 'ok' -or $outerPre.build_revision -ne 'f487c6229b91d2b1ac11729e465561f6c1ffe997'){throw 'live health drift'}
$outerProcesses=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -in @('codex.exe','python.exe','pythonw.exe') -or $_.Name -like 'codex-command-runner*'} | Select-Object Name,ProcessId,ParentProcessId,CreationDate)
$baselineKeys=@($outerProcesses | ForEach-Object {"$($_.ProcessId)|$($_.CreationDate.ToUniversalTime().ToString('o'))"})
@{health=$outerPre;processes=$outerProcesses} | ConvertTo-Json -Depth 9 | Set-Content -Encoding UTF8 "$(Split-Path $stage)/outer-preflight.json"
$registered=$false
try {
  Register-ScheduledTask -TaskName $name -InputObject $task | Out-Null
  $registered=$true
  $created=Get-ScheduledTask -TaskName $name
  if([int]$created.Principal.LogonType -ne 3 -or [int]$created.Principal.RunLevel -ne 0 -or @($created.Triggers | Where-Object { $null -ne $_ }).Count -ne 0){throw 'created diagnostic task differs'}
  Start-ScheduledTask -TaskName $name
  $deadline=(Get-Date).AddSeconds(95)
  do {
    Start-Sleep -Milliseconds 500
    $running=(Get-ScheduledTask -TaskName $name).State -eq 'Running'
  } while((( -not (Test-Path "$stage/result.json")) -or $running) -and (Get-Date) -lt $deadline)
  if($running){Stop-ScheduledTask -TaskName $name;throw 'only diagnostic task stopped after deadline'}
  if(-not (Test-Path "$stage/result.json")){throw 'diagnostic result absent'}
  if((Get-ScheduledTaskInfo -TaskName $name).LastTaskResult -ne 0){throw 'diagnostic task failed'}
  $r=Get-Content -Raw "$stage/result.json" | ConvertFrom-Json
  if($r.session_id -ne 1 -or $r.admin_token -or -not $r.postflight_ok -or $r.exit_code -ne 0 -or $r.timed_out){throw 'interactive registry probe failed'}
  $r | ConvertTo-Json -Depth 5
} finally {
  if($registered){
    if((Get-ScheduledTask -TaskName $name).State -eq 'Running'){Stop-ScheduledTask -TaskName $name}
    Disable-ScheduledTask -TaskName $name | Out-Null
    $t=Get-ScheduledTask -TaskName $name
    $info=Get-ScheduledTaskInfo -TaskName $name
    @{task=$name;state=[string]$t.State;logon_type=[int]$t.Principal.LogonType;run_level=[int]$t.Principal.RunLevel;last_result=$info.LastTaskResult} | ConvertTo-Json
    $disabled=($t.State -eq 'Disabled')
  }
  $outerHealth=Invoke-RestMethod http://127.0.0.1:8765/health
  $outerListeners=@(Get-NetTCPConnection -LocalPort 8765 -State Listen | Select-Object OwningProcess)
  $outerHelpers=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -like 'codex-command-runner*'} | Select-Object Name,ProcessId,ParentProcessId,CreationDate)
  $finalProcesses=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -in @('codex.exe','python.exe','pythonw.exe') -or $_.Name -like 'codex-command-runner*'} | Select-Object Name,ProcessId,ParentProcessId,CreationDate)
  $newProcesses=@($finalProcesses | Where-Object {"$($_.ProcessId)|$($_.CreationDate.ToUniversalTime().ToString('o'))" -notin $baselineKeys})
  $preserved=($outerHealth.status -eq 'ok' -and $outerHealth.build_revision -eq $outerPre.build_revision -and $outerHealth.build_tree -eq $outerPre.build_tree -and $outerHealth.schema_version -eq $outerPre.schema_version -and $outerListeners.Count -eq 1 -and $outerListeners[0].OwningProcess -eq 8268 -and $outerHelpers.Count -eq 0 -and $newProcesses.Count -eq 0)
  foreach($workerName in @('generation_worker','ingestion_worker','studio_worker')){if(-not $outerHealth.workers.$workerName.alive -or $outerHealth.workers.$workerName.current_error -or $outerHealth.workers.$workerName.start_count -ne $outerPre.workers.$workerName.start_count){$preserved=$false}}
  $outerResult=@{utc=(Get-Date).ToUniversalTime().ToString('o');outer_postflight_ok=$preserved;health=$outerHealth;listeners=$outerListeners;helpers=$outerHelpers;processes=$finalProcesses;new_processes=$newProcesses}
  $outerResult | ConvertTo-Json -Depth 9 | Set-Content -Encoding UTF8 "$(Split-Path $stage)/outer-postflight.json"
  $outerResult | ConvertTo-Json -Depth 9
  if(-not $preserved -or ($registered -and -not $disabled)){throw 'outer postflight or diagnostic disable failed'}
}
