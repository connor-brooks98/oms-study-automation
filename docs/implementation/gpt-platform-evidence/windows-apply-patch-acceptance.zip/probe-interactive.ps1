$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/apply-patch-6996bf2f57c4/run'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
$admin=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$session=[System.Diagnostics.Process]::GetCurrentProcess().SessionId
if($session -ne 1 -or $admin -or $identity.Name -ne 'Connors_NUC\conbr'){throw 'not the approved limited interactive identity'}
if(Test-Path $root){throw 'fixture already exists'}
New-Item -ItemType Directory -Path $root | Out-Null
$pre=@{utc=(Get-Date).ToUniversalTime().ToString('o');health=(Invoke-RestMethod http://127.0.0.1:8765/health);listeners=@(Get-NetTCPConnection -LocalPort 8765 -State Listen | Select-Object OwningProcess);helper_processes=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -like 'codex-command-runner*'} | Select-Object Name,ProcessId,ParentProcessId,CreationDate)}
$pre | ConvertTo-Json -Depth 9 | Set-Content -Encoding UTF8 "$root/preflight.json"
if($pre.health.status -ne 'ok' -or $pre.health.build_revision -ne 'f487c6229b91d2b1ac11729e465561f6c1ffe997' -or $pre.listeners.Count -ne 1 -or $pre.listeners[0].OwningProcess -ne 8268 -or $pre.helper_processes.Count -ne 0){throw 'preflight drift'}
$scriptPath='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/apply-patch-6996bf2f57c4/probe-codex-windows-registry.py'
if((Get-FileHash -LiteralPath $scriptPath -Algorithm SHA256).Hash.ToLower() -ne '773d0fabc29438d0e1cdc1815e1fac187892aa2fd7f45aa826c7facc8aeaff1e'){throw 'probe hash mismatch'}
foreach($dir in @('home','temp','appdata','localappdata')){New-Item -ItemType Directory -Path "$root/$dir" | Out-Null}
$start=New-Object System.Diagnostics.ProcessStartInfo
$start.FileName='C:\Services\oms-study-automation-v2\.venv\Scripts\python.exe'
if((Get-FileHash -LiteralPath $start.FileName -Algorithm SHA256).Hash.ToLower() -ne '0b471133e110cfb53a061cad528ce8e517d7b9ac41a0a396c39ad795a487fc14'){throw 'python hash drift'}
$start.Arguments='-I -B "'+$scriptPath+'" --mode apply-patch --executable "C:\Users\conbr\.local\bin\codex.exe" --output-dir "'+$root+'/probe"'
$start.WorkingDirectory=$root
$start.UseShellExecute=$false;$start.CreateNoWindow=$true
$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
$start.EnvironmentVariables.Clear()
foreach($key in @('SystemRoot','WINDIR')){$start.EnvironmentVariables[$key]=[Environment]::GetEnvironmentVariable($key)}
foreach($pair in @(@('USERPROFILE','home'),@('HOME','home'),@('TEMP','temp'),@('TMP','temp'),@('APPDATA','appdata'),@('LOCALAPPDATA','localappdata'))){$start.EnvironmentVariables[$pair[0]]="$root/$($pair[1])"}
$process=New-Object System.Diagnostics.Process
$process.StartInfo=$start
$started=$false;$timedOut=$false;$exitCode=$null;$ownedPid=$null;$stdout='';$stderr=''
try {
  $started=$process.Start()
  if(-not $started){throw 'probe not started'}
  $ownedPid=$process.Id
  $outTask=$process.StandardOutput.ReadToEndAsync();$errTask=$process.StandardError.ReadToEndAsync()
  $timedOut=-not $process.WaitForExit(65000)
  if($timedOut){
    & 'C:\Windows\System32\taskkill.exe' /PID $ownedPid /T /F | Out-Null
    if(-not $process.WaitForExit(5000)){throw 'owned probe cleanup timed out'}
  }
  $stdout=$outTask.GetAwaiter().GetResult();$stderr=$errTask.GetAwaiter().GetResult()
  $exitCode=$process.ExitCode
} finally {
  if($started -and -not $process.HasExited){& 'C:\Windows\System32\taskkill.exe' /PID $ownedPid /T /F | Out-Null;$process.WaitForExit(5000) | Out-Null}
  $stdout | Set-Content -Encoding UTF8 "$root/probe.stdout"
  $stderr | Set-Content -Encoding UTF8 "$root/probe.stderr"
  $post=@{utc=(Get-Date).ToUniversalTime().ToString('o');health=(Invoke-RestMethod http://127.0.0.1:8765/health);listeners=@(Get-NetTCPConnection -LocalPort 8765 -State Listen | Select-Object OwningProcess);helper_processes=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -like 'codex-command-runner*'} | Select-Object Name,ProcessId,ParentProcessId,CreationDate)}
  $post | ConvertTo-Json -Depth 9 | Set-Content -Encoding UTF8 "$root/postflight.json"
  $preserved=($post.health.status -eq 'ok' -and $post.health.build_revision -eq $pre.health.build_revision -and $post.health.build_tree -eq $pre.health.build_tree -and $post.health.schema_version -eq $pre.health.schema_version -and $post.listeners.Count -eq 1 -and $post.listeners[0].OwningProcess -eq 8268 -and $post.helper_processes.Count -eq 0)
  foreach($name in @('generation_worker','ingestion_worker','studio_worker')){if(-not $post.health.workers.$name.alive -or $post.health.workers.$name.current_error -or $post.health.workers.$name.start_count -ne $pre.health.workers.$name.start_count){$preserved=$false}}
  $result=@{identity=$identity.Name;session_id=$session;admin_token=$admin;started=$started;pid=$ownedPid;timed_out=$timedOut;exit_code=$exitCode;postflight_ok=$preserved;probe_sha256='773d0fabc29438d0e1cdc1815e1fac187892aa2fd7f45aa826c7facc8aeaff1e';fixture=$root;scope='Windows fixed apply_patch denial with fixture-only canary; no provider'}
  $result | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 "$root/result.json"
  $process.Dispose()
}
if(-not $preserved -or $timedOut -or $exitCode -ne 0){exit 1}
