$ErrorActionPreference='Stop'
$t=Get-ScheduledTask -TaskName 'OMS GPT Private Arg0 Hostname compile dda6bd863481 20260913'
$owned=@(Get-CimInstance Win32_Process | Where-Object {$_.ExecutablePath -like '*runtime-build-734bbdfad4a9*' -or $_.CommandLine -like '*runtime-build-734bbdfad4a9*'} | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine)
@{utc=(Get-Date).ToUniversalTime().ToString('o');task=@{name=$t.TaskName;state=[string]$t.State;enabled=$t.Settings.Enabled};owned=$owned;health=Invoke-RestMethod -Uri 'http://127.0.0.1:8765/health' -TimeoutSec 5;listeners=@(Get-NetTCPConnection -State Listen -LocalPort 8765 | Select-Object LocalAddress,OwningProcess)} | ConvertTo-Json -Depth 7
