$ErrorActionPreference='Stop'
$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9'
$name='OMS GPT Private Arg0 Hostname compile dda6bd863481 20260913'
if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){throw 'fresh build task already exists'}
if(Test-Path -LiteralPath "$root/codex-arg0-hostname-compile-20260913-dda6bd863481-once.json"){throw 'build launch already consumed'}
if((Get-FileHash -LiteralPath "$root/codex-arg0-hostname-compile-20260913-dda6bd863481.py" -Algorithm SHA256).Hash.ToLower() -ne 'e5c5076d5bcea955de59ddbe6e44bb6a6f17ab7679d4b422db2c81b0c31a04e5'){throw 'build script hash mismatch'}
$action=New-ScheduledTaskAction -Execute 'C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe' -Argument ('-B -I "'+$root+'/codex-arg0-hostname-compile-20260913-dda6bd863481.py"') -WorkingDirectory 'C:/'
$principal=New-ScheduledTaskPrincipal -UserId 'conbr' -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 92) -MultipleInstances IgnoreNew -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$task=New-ScheduledTask -Action $action -Principal $principal -Settings $settings
$null=Register-ScheduledTask -TaskName $name -InputObject $task
Export-ScheduledTask -TaskName $name | Set-Content -Encoding UTF8 "$root/codex-arg0-hostname-compile-20260913-dda6bd863481-task.xml"
Start-ScheduledTask -TaskName $name
@{task_name=$name;state=[string](Get-ScheduledTask -TaskName $name).State;script_sha256='e5c5076d5bcea955de59ddbe6e44bb6a6f17ab7679d4b422db2c81b0c31a04e5';utc=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json
