"""Stage fresh reviewed build files only; do not launch."""
from pathlib import Path
import json,base64,subprocess,hashlib,zlib
p=Path(__file__).resolve().parent
assert json.loads((p/'build-gate.json').read_text())['finalized'] is True, 'Continuation is unbound; no staging or launch'
for n,h in json.loads((p/'build-gate.json').read_text())['files'].items():
 assert __import__('hashlib').sha256(Path(n).read_bytes()).hexdigest()==h,n
remote=json.loads((p/'manifest.json').read_text())['remote_root']
names=['codex-arg0-hostname-compile-20260913-dda6bd863481-plan.json','codex-arg0-hostname-compile-20260913-dda6bd863481.py','codex-arg0-hostname-compile-20260913-dda6bd863481-guard.py','codex-arg0-hostname-compile-20260913-dda6bd863481-pins.json','codex-arg0-hostname-compile-20260913-dda6bd863481-environment.json','launch-codex-arg0-hostname-compile-20260913-dda6bd863481-task.ps1']
hashes={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in names}
def run(label,cmd):
 (p/(label+'.command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 with (p/(label+'.stdout')).open('xb') as out,(p/(label+'.stderr')).open('xb') as err:r=subprocess.run(cmd,stdout=out,stderr=err,timeout=120)
 assert r.returncode==0,(label,r.returncode)
def query(label,s):
 cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','nuc','C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe -B -I -c "import base64,zlib;exec(zlib.decompress(base64.b64decode('+repr(base64.b64encode(zlib.compress(s.encode())).decode())+')))"']
 run(label,cmd)
query('stage-v3-precheck',f"from pathlib import Path\nimport hashlib,json\np=Path({remote!r})\nnames={names!r}\nassert all(not (p/n).exists() for n in names)\nassert (p/'target/codex-no-lto-20260913').is_dir()\nassert hashlib.sha256((p/'target/codex-no-lto-20260913/x86_64-pc-windows-msvc/release/codex.exe').read_bytes()).hexdigest()=='d6eb90b7409dc22f407a9dfa44ec629a8a5a6bf3ca001493aef13dd85a75dbda'\nassert Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/c2-734b-20260913').is_dir()\npins={json.loads((p/'codex-arg0-hostname-compile-20260913-dda6bd863481-pins.json').read_text())!r}\nfor n,h in pins['files'].items():\n if n not in names:assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n\nassert hashlib.sha256((p/'source/codex/codex-rs/arg0/src/lib.rs').read_bytes()).hexdigest()==pins['arg0_patched_sha256']\nassert hashlib.sha256((p/'sysroot/lib/rustlib/src/rust/library/std/src/sys/fs/windows.rs').read_bytes()).hexdigest()=='370abe5e4236878194a6e5c5bf4d11366a1b3ed23dd8235c6852ee7e0904f3f4'\nprint(json.dumps(dict(fresh=True,source_pins_passed=True)))")
run('stage-v3-upload',['scp','-q',*[str(p/n) for n in names],'nuc:'+remote+'/'])
query('stage-v3-verify',f"from pathlib import Path\nimport hashlib,json,ast\np=Path({remote!r}); expected={hashes!r}\nfor n,h in expected.items():\n assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n\n if n.endswith('.py'):ast.parse((p/n).read_text())\nprint(json.dumps(expected,indent=2))")
