"""Fixed phase-body delta; embed in reviewed fresh serial-driver adaptations.
No launcher or command-line interface. Do not import the existing native driver:
its progress, guard, task and once-file names belong to the release build.
"""
from pathlib import Path
import json
import re

TESTS = (
    'tests::windows_alias_home_rejects_resolved_temp_containment',
    'tests::windows_alias_home_preserves_first_use_and_resolution_errors',
)


def select_artifact(stdout, workspace, target):
    """Require one lib-test executable emitted for exactly the pinned arg0 source."""
    messages = [json.loads(line) for line in stdout.splitlines() if line.strip()]
    candidates = [m for m in messages if m.get('reason') == 'compiler-artifact'
                  and m.get('target', {}).get('name') == 'codex_arg0'
                  and m.get('profile', {}).get('test') is True
                  and m.get('executable')]
    assert len(candidates) == 1, 'expected exactly one codex_arg0 test executable'
    m = candidates[0]
    assert m['target']['kind'] == ['lib'], 'unexpected test target kind'
    assert Path(m['target']['src_path']) == workspace / 'arg0/src/lib.rs'
    exe = Path(m['executable'])
    deps = target / 'x86_64-pc-windows-msvc/release/deps'
    assert exe.is_absolute() and exe.parent == deps, 'unexpected executable directory'
    assert re.fullmatch(r'codex_arg0-[0-9a-f]+\.exe', exe.name), 'unexpected executable name'
    assert exe.is_file(), 'selected executable absent'
    # Reject filesystem redirection before freezing or executing the artifact.
    for path in (exe, *exe.parents):
        assert not (getattr(path.lstat(), 'st_file_attributes', 0) & 0x400), str(path)
    return exe


def check_one_test(stdout, stderr, name):
    """An exit-zero harness that matched zero tests is not acceptance."""
    assert stderr == b'', 'unexpected test stderr'
    text = stdout.decode('utf-8').replace('\r\n', '\n')
    assert re.findall(r'^running (\d+) test[s]?$', text, re.M) == ['1']
    assert re.findall(r'^test (.+) \.\.\. (.+)$', text, re.M) == [(name, 'ok')]
    summaries = re.findall(r'^test result: (.+)$', text, re.M)
    assert len(summaries) == 1
    assert re.fullmatch(r'ok\. 1 passed; 0 failed; 0 ignored; 0 measured; \d+ filtered out; finished in .+', summaries[0])


def compile_arg0(root, env, bounded, sha, plan, frozen_release):
    """Called only after source/tool/cache pins and parent acceptance gate pass."""
    assert env['CARGO_BUILD_JOBS'] == '1'
    assert env['CARGO_PROFILE_RELEASE_LTO'] == 'false'
    release = root / 'target/codex-no-lto-20260913/x86_64-pc-windows-msvc/release/codex.exe'
    assert Path(frozen_release['path']) == release and sha(release) == frozen_release['sha256']
    target = root / 'target/codex-no-lto-20260913'
    assert Path(env['CARGO_TARGET_DIR']) == target
    label = plan['phases']['compile']['label']
    args = plan['compile_argv']  # Freeze/hash this exact fixed plan in the final wrapper.
    bounded(label, args, env, timeout=5400)
    exe = select_artifact((root / (label + '.stdout')).read_text(encoding='utf-8'),
                          root / 'source/codex/codex-rs', target)
    assert sha(release) == frozen_release['sha256'], 'release artifact changed'
    receipt = dict(path=str(exe), bytes=exe.stat().st_size, sha256=sha(exe),
                   executed=False, target='codex_arg0', profile_test=True)
    with (root / (label + '-artifact.json')).open('x', encoding='utf-8') as f:
        json.dump(receipt, f, indent=2)
        f.write('\n')
    return receipt


def test_arg0(root, env, bounded, sha, plan, frozen_test, frozen_release):
    """Separate reviewed task; two fixed tests only, no compile in this phase."""
    assert env['CARGO_PROFILE_RELEASE_LTO'] == 'false'
    release = root / 'target/codex-no-lto-20260913/x86_64-pc-windows-msvc/release/codex.exe'
    assert Path(frozen_release['path']) == release and sha(release) == frozen_release['sha256']
    exe = Path(frozen_test['path'])
    assert exe.parent == root / 'target/codex-no-lto-20260913/x86_64-pc-windows-msvc/release/deps'
    assert re.fullmatch(r'codex_arg0-[0-9a-f]+\.exe', exe.name)
    assert frozen_test['profile_test'] is True and frozen_test['target'] == 'codex_arg0'
    for path in (exe, *exe.parents):
        assert not (getattr(path.lstat(), 'st_file_attributes', 0) & 0x400), str(path)
    results = []
    for number, name in enumerate(TESTS, 1):
        assert sha(exe) == frozen_test['sha256'], 'test artifact changed'
        label = plan['phases']['test']['label'] + '-' + str(number)
        temp = root / (plan['phases']['test']['label'] + '-temp-' + str(number))
        assert temp == Path(plan['test_temp_paths'][number - 1])
        temp.mkdir(exist_ok=False)  # Dedicated existing root; never reuse another TEMP.
        test_env = dict(env, TEMP=str(temp), TMP=str(temp))
        args = [str(exe), name, '--exact', '--nocapture', '--test-threads=1']
        bounded(label, args, test_env, timeout=60)
        check_one_test((root / (label + '.stdout')).read_bytes(),
                       (root / (label + '.stderr')).read_bytes(), name)
        assert sha(exe) == frozen_test['sha256'], 'test artifact changed'
        assert sha(release) == frozen_release['sha256'], 'release artifact changed'
        results.append(dict(name=name, passed=True, executable_sha256=frozen_test['sha256'],
                            temp=str(temp), label=label))
    return results


if __name__ == '__main__':
    raise SystemExit('Preparation fragment only: final fresh wrappers and gate bindings require review.')
