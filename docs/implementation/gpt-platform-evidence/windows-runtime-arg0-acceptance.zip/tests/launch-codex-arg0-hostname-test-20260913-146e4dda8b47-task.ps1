$ErrorActionPreference='Stop'
$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9'
$gate=Get-Content -Raw -LiteralPath "$root/codex-arg0-hostname-test-20260913-146e4dda8b47-gate.json" | ConvertFrom-Json
if($gate.finalized -ne $true -or -not $gate.test_artifact_sha256){throw 'Test artifact binding incomplete; no task launch'}
$name='OMS GPT Private Arg0 Hostname test 146e4dda8b47 20260913'
if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){throw 'fresh build task already exists'}
if(Test-Path -LiteralPath "$root/codex-arg0-hostname-test-20260913-146e4dda8b47-once.json"){throw 'build launch already consumed'}
if((Get-FileHash -LiteralPath "$root/codex-arg0-hostname-test-20260913-146e4dda8b47.py" -Algorithm SHA256).Hash.ToLower() -ne '4b490205ac6d643a08276e83d7446056df9384b2633878cd81595fa75015c829'){throw 'build script hash mismatch'}
$action=New-ScheduledTaskAction -Execute 'C:/Services/oms-study-automation-v2/.venv/Scripts/python.exe' -Argument ('-B -I "'+$root+'/codex-arg0-hostname-test-20260913-146e4dda8b47.py"') -WorkingDirectory 'C:/'
$principal=New-ScheduledTaskPrincipal -UserId 'conbr' -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Seconds 180) -MultipleInstances IgnoreNew -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$task=New-ScheduledTask -Action $action -Principal $principal -Settings $settings
$null=Register-ScheduledTask -TaskName $name -InputObject $task
Export-ScheduledTask -TaskName $name | Set-Content -Encoding UTF8 "$root/codex-arg0-hostname-test-20260913-146e4dda8b47-task.xml"
Start-ScheduledTask -TaskName $name
@{task_name=$name;state=[string](Get-ScheduledTask -TaskName $name).State;script_sha256='4b490205ac6d643a08276e83d7446056df9384b2633878cd81595fa75015c829';utc=(Get-Date).ToUniversalTime().ToString('o')} | ConvertTo-Json
