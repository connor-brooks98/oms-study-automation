from pathlib import Path
import hashlib,json,datetime
p=Path('C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/runtime-build-734bbdfad4a9')
print(json.dumps({"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"files":{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['target/codex-no-lto-20260913/x86_64-pc-windows-msvc/release/codex.exe', 'target/codex-no-lto-20260913/x86_64-pc-windows-msvc/release/deps/codex_arg0-da8d3b8a1852e964.exe', 'source/codex/codex-rs/Cargo.lock', 'source/codex/codex-rs/arg0/src/lib.rs', 'sysroot/lib/rustlib/src/rust/library/std/src/sys/fs/windows.rs', 'C:/Users/conbr/.local/bin/codex.exe']}}))
