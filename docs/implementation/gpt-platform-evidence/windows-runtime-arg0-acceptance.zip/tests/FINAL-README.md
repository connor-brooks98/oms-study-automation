# Native Windows arg0 tests — passed

Exactly two named unit tests passed serially under the fresh Limited task. Each process selected one test, passed one, filtered out nine, emitted empty stderr, and exited normally with code 0. Neither process timed out or reported a cleanup error. Each used a distinct fresh private TEMP directory and a 60-second bound. This phase did not compile code.

The test executable is SHA-256 2a1d3c6b86a19798b0d8f8af29d7af22ee4e6800e9ed998afebfa947c5ab0cba. Its successful compilation, unique Cargo artifact selection, source provenance and final execution bindings were independently reviewed before the test task launched. The original inert skeleton remains preserved under prepared-skeleton.

Both Hub checks and all four memory checks passed. Independent reconciliation at 2026-09-14T01:33:44.0460513Z confirmed the task disabled, no owned processes, and the original Hub listener, build, tree, schema and workers preserved. The final six hash checks at 2026-09-14T01:34:34.893262Z confirmed that the accepted d6eb runtime, test executable, installed original 444a runtime, arg0 source, lockfile and patched standard library remained unchanged.

These are ordinary Limited Windows unit tests. They complement the separately accepted LPAC version and initialize probes. They do not establish provider acceptance or authorize deployment, authentication, policy changes or live Hub changes. All raw invocations, stdout, stderr, result and reconciliation receipts are retained.
