# Fresh Windows Codex adversarial matrix

Reuses independently reviewed manifest462273d15b980adf43ef258cb7929d156c48dae5793e58198e0cac6ca222d49d. Its zero-HTTP failure remains frozen. The concrete Mac fixture firewall cause was isolated by ordinary curl and corrected with existing Apple system Python; both ordinary and strict LPAC curl now passed exact ordered synthetic HTTP responses.

Only substantive changes: pin and run the fixture using /usr/bin/python3 plus resolved Apple interpreter; correct call9 to namespace collaboration, name spawn_agent, required task_name/message/fork_turns=none, and exact rejection collaborationspawn_agent. Fresh private profile, task, nonce, port and evidence. No policy/firewall/runtime rebuild change.

Same15 fixed calls, exact rejection text and output types, empty advertised registry, mandatory notification identities, absent canary, known private-home metadata/router log classification, unknown fatal stderr fail. Hard120s fixture deadline,45s Codex child,80s inner helper,110s Limited task. Exact caller/AppContainer/capability/SID/session/read-access checks and Hub/worker preservation unchanged. Host client private-network access is intentionally allowed. This tests exact attempted model tool routes and their rejections; universal arbitrary network confinement, OS actual source reads and interruption remain separate claims.

No credentials, actual provider, retained source or private data, Anki, shared state changes. Await independent review and O clearance for one native run.

Local compatibility correction: Python3.9 lacks zip(strict=True). The existing exact15 call-ID assertion is retained, plus explicit equal-length assertion before plain zip. Initial local selfcheck caught this TypeError before native dispatch; corrected selfcheck must pass.
