"""Local only: exact rejection oracle and hard deadline under dripping headers."""
from pathlib import Path
import copy
import json
import multiprocessing
import runpy
import socket
import tempfile
import time

ROOT = Path(__file__).resolve().parent
m = runpy.run_path(str(ROOT / "fixture.py"))
calls = m["calls"]()
outputs = []
for call in calls:
    namespace = call.get("namespace", "")
    name = (namespace if namespace not in {"", "functions"} else "") + call["name"]
    custom = call["type"] == "custom_tool_call"
    outputs.append({"type": "custom_tool_call_output" if custom else "function_call_output",
                    "call_id": call["call_id"], "output": ("unsupported custom tool call: " if custom else "unsupported call: ") + name})
body = {"model": "gpt-5.5", "tools": [], "input": outputs}
m["inspect_request"](body, True)
for index in range(15):
    for field, bad in [("output", "unsupported call: unrelated_function"), ("type", "custom_tool_call_output" if index < 13 else "function_call_output")]:
        changed = copy.deepcopy(body)
        changed["input"][index][field] = bad
        try:
            m["inspect_request"](changed, True)
        except AssertionError:
            pass
        else:
            raise AssertionError(f"bad {field} accepted at {index}")

folder = Path(tempfile.mkdtemp(prefix="deadline-selfcheck-", dir=ROOT)) / "run"
with socket.socket() as s:
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
g = m["serve"].__globals__
g.update(HOST="127.0.0.1", PEER="127.0.0.1", PORT=port, OUTPUT=folder, FIXTURE_DEADLINE_SECONDS=0.7)
p = multiprocessing.get_context("fork").Process(target=m["serve"])
started = time.monotonic()
p.start()
try:
    until = time.monotonic() + 3
    while not (folder / "listening.json").exists() and time.monotonic() < until:
        time.sleep(0.01)
    assert (folder / "listening.json").exists()
    with socket.create_connection(("127.0.0.1", port), timeout=1) as client:
        client.sendall(b"POST /incomplete HTTP/1.1\r\nX-Drip: ")
        while p.is_alive() and time.monotonic() < until:
            try:
                client.sendall(b"x")
            except OSError:
                break
            time.sleep(0.05)
    p.join(1)
    assert not p.is_alive(), "hard deadline failed under active dripping headers"
    assert time.monotonic() - started < 2.5
    result = json.loads((folder / "result.json").read_text())
    assert result["passed"] is False and "hard 120-second fixture deadline exceeded" in result["errors"]
finally:
    if p.is_alive():
        p.terminate()
        p.join(2)
print("15 exact positive outputs; 30 wrong-name/type negatives; active-request hard deadline PASS")
