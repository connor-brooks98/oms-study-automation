if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-7c8087cd5bbc';$files=@{
  'probe-windows-lpac.ps1'='04641fb9a01af12a69e420db63b649220c73a75bb5aba78ba53bd4948a81120a'
  'probe-interactive.ps1'='51e15645f69337d698775e4bb3964e3bad6a1726559ff7d1ad41049ead3c4362'
  'run-lpac-task.ps1'='f8a5a7c1814410bb755734d738c8549d6c2687cdd101219fc4a2e31c54dc56f6'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
