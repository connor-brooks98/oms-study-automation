from pathlib import Path
import json,base64,subprocess,time,hashlib
r=Path('/Users/connor/.codex/visualizations/2026/09/11/01a09271-e627-7712-a2fc-ff675db23a8b/windows-restrictions-20260914/controlled-interrupt')
m=json.loads((r/'manifest.json').read_text())
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==m['runner_sha256'], 'runner hash drift'
e=r/'execution';e.mkdir(exist_ok=False)
def run(name,args,timeout=45):
 (e/(name+'.command.json')).write_text(json.dumps(args,indent=2))
 try:p=subprocess.run(args,capture_output=True,timeout=timeout)
 except subprocess.TimeoutExpired as x:
  (e/(name+'.stdout')).write_bytes(x.stdout or b'');(e/(name+'.stderr')).write_bytes(x.stderr or b'');raise
 (e/(name+'.stdout')).write_bytes(p.stdout);(e/(name+'.stderr')).write_bytes(p.stderr)
 print(name,p.returncode,flush=True)
 if p.returncode: raise RuntimeError(name+' failed: '+p.stderr.decode()[-1000:])
 return p.stdout

def ps(name,s,timeout=45):return run(name,['ssh','-o','BatchMode=yes','nuc','powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(s.encode('utf-16-le')).decode()],timeout)
s=(r.parent/'read-only-preflight.ps1').read_text()
x=json.loads(ps('fresh-preflight',s));assert x['runtime_sha']==m['executable_sha256'];assert x['health']['build_revision']=='f487c6229b91d2b1ac11729e465561f6c1ffe997';assert x['listeners'][0]['OwningProcess']==8268;assert not x['owned'];assert x['hub_process']['ParentProcessId']==11300
ps('stage-create',(r/'stage-create.ps1').read_text())
run('stage-copy',['scp','-q',*[str(r/k) for k in m['files']],f"nuc:{m['remote_root']}/"],90)
ps('stage-validation',(r/'validate-staged.ps1').read_text())
# Start the reviewed local fake service only after all native staging checks pass.
import sys
fixture_out=(e/'fixture.stdout').open('xb');fixture_err=(e/'fixture.stderr').open('xb')
assert hashlib.sha256((r/'fixture.py').read_bytes()).hexdigest()==m['fixture_sha256']
assert hashlib.sha256(Path(m['fixture_interpreter']).read_bytes()).hexdigest() == m['fixture_interpreter_sha256']
assert hashlib.sha256(Path(m['fixture_actual_interpreter']).read_bytes()).hexdigest() == m['fixture_actual_interpreter_sha256']
fixture=subprocess.Popen([m['fixture_interpreter'],str(r/'fixture.py')],stdout=fixture_out,stderr=fixture_err)
(e/'fixture-owned.json').write_text(json.dumps({'pid':fixture.pid,'executable':m['fixture_interpreter'],'script_sha256':m['fixture_sha256'],'started_epoch':time.time()}))
try:
 deadline=time.monotonic()+5
 while not (r/'fixture-execution/listening.json').exists() and fixture.poll() is None and time.monotonic()<deadline:time.sleep(.05)
 assert fixture.poll() is None and (r/'fixture-execution/listening.json').exists(),'fixture did not bind reviewed endpoint'
 listening=json.loads((r/'fixture-execution/listening.json').read_text())
 assert listening == {'host':m['fixture_host'],'port':m['fixture_port'],'peer':m['fixture_peer'],'pid':fixture.pid}, 'fixture listening identity drift'
 (e/'dispatch-once.json').write_text(json.dumps({'utc':time.time(),'manifest_sha256':hashlib.sha256((r/'manifest.json').read_bytes()).hexdigest(),'task_name':m['task_name']}))
 ps('invocation',(r/'invocation.ps1').read_text(),150)
finally:
 if (r/'fixture-execution').exists():(r/'fixture-execution/stop').touch(exist_ok=False)
 try:fixture.wait(timeout=5)
 except subprocess.TimeoutExpired:
  fixture.kill();fixture.wait(timeout=5)
  (e/'fixture-forced-cleanup.json').write_text(json.dumps({'pid':fixture.pid,'forced_kill':True}))
 fixture_out.close();fixture_err.close()
 (e/'fixture-process-result.json').write_text(json.dumps({'pid':fixture.pid,'exit_code':fixture.returncode,'reaped':True}))

assert fixture.returncode == 0 and not (e/'fixture-forced-cleanup.json').exists(), 'fixture failed or required forced cleanup'
assert json.loads((r/'fixture-execution/result.json').read_text())['passed'], 'fixture rejection assertions failed'
