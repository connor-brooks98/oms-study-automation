if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-c2b3590cd4fb';$files=@{
  'probe-windows-lpac.ps1'='5ad9718c33d7e0888ecd369c66510f01fca65feb9a69854244addf333e28a63e'
  'probe-interactive.ps1'='216021159ce12975091e58052b4077aab7b0fb0ba0bd3d99661eb84a3ad194f9'
  'run-lpac-task.ps1'='d83fab3dd14af664510504d8aba70a7b428d885322fab4cc94332e781d8f70db'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
