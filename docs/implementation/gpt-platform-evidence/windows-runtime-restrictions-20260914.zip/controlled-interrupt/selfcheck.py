from pathlib import Path
import runpy,json,socket,multiprocessing,tempfile,time,urllib.request
ROOT=Path(__file__).resolve().parent
m=runpy.run_path(str(ROOT/'fixture.py'))
for mode in ['withhold','deadline']:
 folder=Path(tempfile.mkdtemp(prefix='interrupt-'+mode+'-',dir=ROOT))/'run'
 with socket.socket() as sock:
  sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 m['serve'].__globals__.update(HOST='127.0.0.1',PEER='127.0.0.1',PORT=port,OUTPUT=folder,FIXTURE_DEADLINE_SECONDS=5 if mode=='withhold' else .7)
 p=multiprocessing.get_context('fork').Process(target=m['serve']);p.start()
 try:
  until=time.monotonic()+3
  while not (folder/'listening.json').exists() and time.monotonic()<until:time.sleep(.01)
  assert (folder/'listening.json').exists()
  if mode=='withhold':
   request=urllib.request.Request('http://127.0.0.1:'+str(port)+m['ENDPOINT'],data=json.dumps({'model':'gpt-5.5','tools':[],'input':[]}).encode(),headers={'Content-Type':'application/json'})
   with urllib.request.urlopen(request,timeout=.2) as response:
    assert response.status==200 and response.headers['Content-Length']=='1048576'
    try:response.read(1)
    except (TimeoutError,socket.timeout):pass
    else:raise AssertionError('fixture transmitted body')
   (folder/'stop').touch()
  else:
   with socket.create_connection(('127.0.0.1',port),timeout=1) as client:
    client.sendall(b'POST /incomplete HTTP/1.1\r\nX-Drip: ')
    while p.is_alive() and time.monotonic()<until:
     try:client.sendall(b'x')
     except OSError:break
     time.sleep(.05)
  p.join(2);assert not p.is_alive()
  result=json.loads((folder/'result.json').read_text())
  if mode=='withhold':assert p.exitcode==0 and result['passed'] and result['requests']==1 and result['headers_sent_body_withheld']
  else:assert not result['passed'] and 'hard 120-second fixture deadline exceeded' in result['errors']
 finally:
  if p.is_alive():p.terminate();p.join(2)
print('System Python exact one POST headers/body-withholding and active-header hard-deadline PASS')
