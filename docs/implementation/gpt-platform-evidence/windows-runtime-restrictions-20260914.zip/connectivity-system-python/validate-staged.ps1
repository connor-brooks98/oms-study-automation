if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-70268f3595d4';$files=@{
  'probe-windows-lpac.ps1'='ece67f81eb43c40abbac5f4504432a90c9e44a3f17acc3f1683cafa163435667'
  'probe-interactive.ps1'='d85615decf05895d011524aef9888ea7a8b6c6c71abe3b6bf3e04761663fe043'
  'run-lpac-task.ps1'='ee73e5ebaa3f8a03d6204a6e311c33d30e8da94edcc9e451bcf90acf2ecff4d6'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
