# Fresh system-Python connectivity discriminator

Prior generic curl control failed before LPAC. macOS firewall log at 2026-09-14 14:56:38 local identifies exact fixture PID 13021 and queued inbound Python.app flow, then says it is not prompting until an existing response arrives. This is concrete fixture-side firewall gating evidence, not a Windows LPAC failure.

Use existing allowed Apple system Python /usr/bin/python3 (3.9.6) for the otherwise identical fixture, with both shim and resolved interpreter SHA pins in runner/manifest. No settings or firewall change. Fresh profile, nonce, port, stage, task, and evidence. Native curl hash/args/timers and ordinary Limited control first remain unchanged. Max two ordered GET requests, hard45s fixture limit, no credentials/provider/Codex calls. Prior failed evidence remains frozen.

Read-only diagnosis and interpreter provenance: ../connectivity-diagnosis. Validate local selfcheck under /usr/bin/python3 before execution. O clearance required for exactly one native run after independent review.
