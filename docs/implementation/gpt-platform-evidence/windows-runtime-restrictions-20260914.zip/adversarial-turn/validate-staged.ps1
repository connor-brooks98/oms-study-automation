if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-04e96e8b4b2e';$files=@{
  'probe-windows-lpac.ps1'='4caaea15b529910d082e56e5bcc7af0de71e20f462b241d0dba4e1a878a60ac6'
  'probe-interactive.ps1'='0d09b31c6a39b2d6740bc849f5aa0cd18e2430a10abcbb46e6fb220e342751f4'
  'run-lpac-task.ps1'='1e3db6bf06ba086c56f5c4217ba4bc19d7babe36d4468d7331e274eaf7854960'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
