"""Fixed two-response synthetic LAN fixture; no credentials or real provider."""
import hashlib
import json
import socket
import signal
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / "manifest.json").read_text())
HOST, PEER, PORT = MANIFEST["fixture_host"], MANIFEST["fixture_peer"], MANIFEST["fixture_port"]
ENDPOINT = "/" + MANIFEST["fixture_nonce"] + "/v1/responses"
PROFILE = "oms-lpac-" + MANIFEST["profile"]
NATIVE_ROOT = MANIFEST["remote_root"].replace("/", "\\") + "\\run\\" + PROFILE
CANARY = NATIVE_ROOT + "\\inside\\home\\tool-must-not-create"
OUTSIDE = NATIVE_ROOT + "\\outside.txt"
OUTPUT = ROOT / "fixture-execution"
FIXTURE_DEADLINE_SECONDS = 120


def calls():
    values = [
        ("list", "skills", {"authority": {"kind": "executor"}}),
        ("read", "skills", {"package": "fixture-missing-package"}),
        ("request_user_input", None, {"questions": []}),
        ("exec_command", None, {"cmd": 'cmd /d /c "echo TOOL_EXECUTED>' + CANARY + '"'}),
        ("shell", None, {"command": ["C:\\Windows\\System32\\cmd.exe", "/d", "/c", "echo TOOL_EXECUTED>" + CANARY]}),
        ("read_file", None, {"path": OUTSIDE}),
        ("mcp__policy_fixture__read", None, {}),
        ("web_search", None, {"query": f"http://{HOST}:{PORT}/must-not-reach"}),
        ("view_image", None, {"path": OUTSIDE}),
        ("spawn_agent", None, {"message": "synthetic fixture"}),
        ("wait", "functions", {"cell_id": "fixture-never-created", "yield_time_ms": 1}),
        ("request_user_input_async", "functions", {"questions": [{"title": "Synthetic fixture only"}]}),
        ("list_agents", "collaboration", {}),
    ]
    return [
        {"type": "function_call", "id": f"fc_fixture_{i}", "call_id": f"call_policy_{i}", "name": name,
         **({"namespace": namespace} if namespace else {}), "arguments": json.dumps(arguments)}
        for i, (name, namespace, arguments) in enumerate(values)
    ] + [
        {"type": "custom_tool_call", "id": "fc_fixture_13", "call_id": "call_policy_13", "name": "exec", "namespace": "functions", "input": 'text("POLICY_EXECUTED")'},
        {"type": "custom_tool_call", "id": "fc_fixture_14", "call_id": "call_policy_14", "name": "apply_patch", "input": f"*** Begin Patch\n*** Add File: {CANARY}\n+TOOL_EXECUTED\n*** End Patch\n"},
    ]


def inspect_request(body, second):
    assert body.get("model") == "gpt-5.5", "model drift"
    tools = list(body.get("tools", []))
    outputs = []
    for item in body.get("input", []):
        if item.get("type") == "additional_tools":
            tools.extend(item.get("tools", []))
        if item.get("type") in {"function_call_output", "custom_tool_call_output"}:
            outputs.append(item)
    assert not tools, "nonempty advertised registry"
    if not second:
        assert not outputs, "unexpected initial call history"
        return
    assert [x.get("call_id") for x in outputs] == [f"call_policy_{i}" for i in range(15)], "missing/duplicate/out-of-order rejection outputs"
    for call, item in zip(calls(), outputs, strict=True):
        namespace = call.get("namespace", "")
        name = (namespace if namespace not in {"", "functions"} else "") + call["name"]
        custom = call["type"] == "custom_tool_call"
        expected_type = "custom_tool_call_output" if custom else "function_call_output"
        expected_text = ("unsupported custom tool call: " if custom else "unsupported call: ") + name
        assert item.get("type") == expected_type, "wrong rejection output type"
        assert item.get("output") == expected_text, f"call {call['call_id']} rejection mismatch"



def serve():
    OUTPUT.mkdir(exist_ok=False)
    state = {"requests": 0, "errors": [], "started_utc": time.time(), "host_client_network_allowed": True,
             "provider_verified": False, "universal_restrictions_verified": False}
    done = threading.Event()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def setup(self):
            self.request.settimeout(3)
            super().setup()

        def reject(self, message):
            state["errors"].append(message)
            self.send_error(400)
            done.set()

        def do_GET(self):
            self.reject("unexpected method or network canary request")
        do_HEAD = do_PUT = do_PATCH = do_DELETE = do_OPTIONS = do_GET

        def do_POST(self):
            try:
                assert self.client_address[0] == PEER, "unexpected peer"
                assert self.path == ENDPOINT and state["requests"] < 2, "unexpected path or extra request"
                assert not self.headers.get("Authorization") and not self.headers.get("api-key"), "unexpected authentication header"
                assert not self.headers.get("Transfer-Encoding"), "unexpected transfer encoding"
                length = int(self.headers.get("Content-Length", "0"))
                assert 0 < length <= 8 * 1024 * 1024, "request size exceeded"
                raw = self.rfile.read(length)
                assert len(raw) == length, "truncated request"
                index = state["requests"]
                (OUTPUT / f"request-{index}.json").write_bytes(raw)
                body = json.loads(raw)
                inspect_request(body, second=index == 1)
                state["requests"] += 1
                message = {"type": "message", "id": "msg_fixture", "role": "assistant", "status": "completed",
                           "content": [{"type": "output_text", "text": "fixture complete"}]}
                output = calls() if index == 0 else [message]
                response = {"id": f"resp_fixture_{index}", "model": "gpt-5.5", "status": "completed", "output": output,
                            "usage": {"input_tokens": 1, "output_tokens": 1, "total_tokens": 2}}
                events = [("response.created", {"response": {**response, "status": "in_progress"}}),
                          *[("response.output_item.done", {"output_index": i, "item": item}) for i, item in enumerate(output)],
                          ("response.completed", {"response": response})]
                (OUTPUT / f"response-{index}.json").write_text(json.dumps(events, indent=2))
                payload = "".join(f"event: {kind}\ndata: " + json.dumps({"type": kind, **data}) + "\n\n" for kind, data in events).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
            except Exception as exc:
                self.reject(f"{type(exc).__name__}: {exc}")

    class OwnedServer(HTTPServer):
        active_socket = None
        def get_request(self):
            sock, peer = super().get_request()
            self.active_socket = sock
            return sock, peer
        def close_request(self, request):
            super().close_request(request)
            self.active_socket = None

    server = OwnedServer((HOST, PORT), Handler)
    def hard_deadline(signum, frame):
        state["errors"].append("hard 120-second fixture deadline exceeded")
        if server.active_socket is not None:
            try:
                server.active_socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            server.active_socket.close()
        server.server_close()
        raise SystemExit("hard fixture deadline")
    previous_alarm = signal.signal(signal.SIGALRM, hard_deadline)
    signal.setitimer(signal.ITIMER_REAL, FIXTURE_DEADLINE_SECONDS)
    server.timeout = 0.25
    (OUTPUT / "listening.json").write_text(json.dumps({"host": HOST, "port": PORT, "peer": PEER, "pid": __import__("os").getpid()}))
    deadline = time.monotonic() + FIXTURE_DEADLINE_SECONDS
    try:
        while time.monotonic() < deadline and not done.is_set() and not (OUTPUT / "stop").exists():
            server.handle_request()
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_alarm)
        server.server_close()
        state["finished_utc"] = time.time()
        state["passed"] = state["requests"] == 2 and not state["errors"]
        (OUTPUT / "result.json").write_text(json.dumps(state, indent=2))
    return state


if __name__ == "__main__":
    assert MANIFEST.get("binding_finalized") is True, "prepared only"
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == MANIFEST["fixture_sha256"], "fixture hash drift"
    assert serve()["passed"], "fixture failed"
