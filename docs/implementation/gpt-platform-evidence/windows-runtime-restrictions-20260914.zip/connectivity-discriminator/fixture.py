"""Fixed two-response synthetic LAN fixture; no credentials or real provider."""
import hashlib
import json
import socket
import signal
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / "manifest.json").read_text())
HOST, PEER, PORT = MANIFEST["fixture_host"], MANIFEST["fixture_peer"], MANIFEST["fixture_port"]
ENDPOINT = "/" + MANIFEST["fixture_nonce"] + "/v1/responses"
PROFILE = "oms-lpac-" + MANIFEST["profile"]
NATIVE_ROOT = MANIFEST["remote_root"].replace("/", "\\") + "\\run\\" + PROFILE
CANARY = NATIVE_ROOT + "\\inside\\home\\tool-must-not-create"
OUTSIDE = NATIVE_ROOT + "\\outside.txt"
OUTPUT = ROOT / "fixture-execution"
FIXTURE_DEADLINE_SECONDS = 45


def serve():
    OUTPUT.mkdir(exist_ok=False)
    state = {"requests": 0, "errors": [], "started_utc": time.time(), "host_client_network_allowed": True,
             "provider_verified": False, "universal_restrictions_verified": False}
    done = threading.Event()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def setup(self):
            self.request.settimeout(3)
            super().setup()

        def reject(self, message):
            state["errors"].append(message)
            self.send_error(400)
            done.set()

        def do_GET(self):
            try:
                assert self.client_address[0] == PEER, "unexpected peer"
                assert state["requests"] < 2, "extra request"
                expected = "/" + MANIFEST["fixture_nonce"] + "/" + ["control", "lpac"][state["requests"]]
                assert self.path == expected, "unexpected or out-of-order nonce endpoint"
                assert not self.headers.get("Authorization") and not self.headers.get("api-key"), "unexpected auth"
                assert not self.headers.get("Content-Length") and not self.headers.get("Transfer-Encoding"), "unexpected request body"
                (OUTPUT / (str(state["requests"]) + "-request.json")).write_text(json.dumps({"peer":self.client_address[0],"path":self.path,"utc":time.time()}))
                state["requests"] += 1
                payload = b"OMS_NETWORK_OK\n"
                self.send_response(200)
                self.send_header("Content-Type", "text/plain")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
            except Exception as exc:
                self.reject(f"{type(exc).__name__}: {exc}")
        def do_POST(self):
            self.reject("unexpected HTTP method")
        do_HEAD = do_PUT = do_PATCH = do_DELETE = do_OPTIONS = do_POST

    class OwnedServer(HTTPServer):
        active_socket = None
        def get_request(self):
            sock, peer = super().get_request()
            self.active_socket = sock
            return sock, peer
        def close_request(self, request):
            super().close_request(request)
            self.active_socket = None

    server = OwnedServer((HOST, PORT), Handler)
    def hard_deadline(signum, frame):
        state["errors"].append("hard 45-second fixture deadline exceeded")
        if server.active_socket is not None:
            try:
                server.active_socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            server.active_socket.close()
        server.server_close()
        raise SystemExit("hard fixture deadline")
    previous_alarm = signal.signal(signal.SIGALRM, hard_deadline)
    signal.setitimer(signal.ITIMER_REAL, FIXTURE_DEADLINE_SECONDS)
    server.timeout = 0.25
    (OUTPUT / "listening.json").write_text(json.dumps({"host": HOST, "port": PORT, "peer": PEER, "pid": __import__("os").getpid()}))
    deadline = time.monotonic() + FIXTURE_DEADLINE_SECONDS
    try:
        while time.monotonic() < deadline and not done.is_set() and not (OUTPUT / "stop").exists():
            server.handle_request()
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_alarm)
        server.server_close()
        state["finished_utc"] = time.time()
        state["passed"] = state["requests"] == 2 and not state["errors"]
        (OUTPUT / "result.json").write_text(json.dumps(state, indent=2))
    return state


if __name__ == "__main__":
    assert MANIFEST.get("binding_finalized") is True, "prepared only"
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == MANIFEST["fixture_sha256"], "fixture hash drift"
    assert serve()["passed"], "fixture failed"
