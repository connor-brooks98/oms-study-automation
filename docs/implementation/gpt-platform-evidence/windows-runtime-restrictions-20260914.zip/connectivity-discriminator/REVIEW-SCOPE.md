# Synthetic connectivity discriminator — prepared only

Read-only inventory verified installed Microsoft-signed `C:/Windows/System32/curl.exe` version8.21.0,818512bytes,SHA25673d24149ff289afc49ec41f08918ef9faa727d39ad993e929757dc2ddafab805 at18:47:34Z. Copy only that binary to a new private probe path; no installation or shared dependency change.

Reuse the accepted strict LPAC version wrapper with two fixed HTTP GET commands. Ordinary Limited control runs first against the new Mac fixture `/nonce/control`. Curl disables config loading and proxies, uses no authentication, no redirects/retries, connect timeout3seconds and total5seconds. Owned control process has an8second wrapper limit and is reaped even on failure. Stop before LPAC profile/child creation if control does not return exact `OMS_NETWORK_OK\n`, empty stderr and exit0.

Only after that control passes, launch the copied identical curl executable under fresh strict LPAC with the same privateNetworkClientServer SID3 + lpacCom + registryRead capabilities as the failed Codex turn; exact profile SID/AppContainer/session/AccessChecks and child-process restrictions remain. Fixed GET `/nonce/lpac`, same curl arguments,15second native limit,60second inner guard,110second Limited task. Preserve both raw results and distinguish endpoint control failure from LPAC-only failure. No Codex app-server/model/provider/auth request occurs in this discriminator.

Mac fixture binds exactly192.168.68.55:50071, permits only native peer192.168.68.59 and nonce0821f318befa4beba86c92c77fdb0c92. Exactly two GETs maximum, ordered control thenLPAC; allother paths/methods/auth/body headers fail. Hard45second listener/active-request alarm with owned runner cleanup, as in reviewed adversarial fixture. No firewall, loopback exemption, policy, account, registry, shared ACL or live Hub changes.

Outcome scope is narrow: generic TCP/HTTP transport through this LPAC token and this endpoint. Even both GETs passing does not prove Codex advanced to its HTTP client or universal restriction enforcement; it tells the subsequent runtime trace which layer to inspect. Keep all earlier failed evidence immutable and production/provider flags false.
