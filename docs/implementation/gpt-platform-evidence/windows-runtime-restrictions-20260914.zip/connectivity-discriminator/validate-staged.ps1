if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-b6b8689c2c74';$files=@{
  'probe-windows-lpac.ps1'='34176e2136c470209f631e608696e673a2ba9d4d0e50ff54468ca4a4b899b35d'
  'probe-interactive.ps1'='cd37ec011d87e9c55073a02dc5e4ab15194e9ce77b7aea81f1f7f2d23cb0508a'
  'run-lpac-task.ps1'='090104bd094cbb8b56a9b65f5ee611b920816c05f39153637978a521809b68f9'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
