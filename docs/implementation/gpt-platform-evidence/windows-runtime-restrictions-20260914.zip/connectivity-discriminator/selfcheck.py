"""Local loopback check of the two fixed GETs; never invokes Windows or curl."""
from pathlib import Path
import json
import multiprocessing
import runpy
import socket
import tempfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
m = runpy.run_path(str(ROOT / "fixture.py"))
folder = Path(tempfile.mkdtemp(prefix="get-selfcheck-", dir=ROOT)) / "run"
with socket.socket() as s:
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
m["serve"].__globals__.update(HOST="127.0.0.1", PEER="127.0.0.1", PORT=port, OUTPUT=folder, FIXTURE_DEADLINE_SECONDS=5)
p = multiprocessing.get_context("fork").Process(target=m["serve"])
p.start()
try:
    deadline = time.monotonic() + 3
    while not (folder / "listening.json").exists() and time.monotonic() < deadline:
        time.sleep(.01)
    assert (folder / "listening.json").exists()
    for suffix in ["control", "lpac"]:
        url = f"http://127.0.0.1:{port}/{m['MANIFEST']['fixture_nonce']}/{suffix}"
        with urllib.request.urlopen(url, timeout=1) as response:
            assert response.status == 200 and response.read() == b"OMS_NETWORK_OK\n"
    (folder / "stop").touch()
    p.join(1)
    assert not p.is_alive() and p.exitcode == 0
    result = json.loads((folder / "result.json").read_text())
    assert result["passed"] and result["requests"] == 2 and not result["errors"]
finally:
    if p.is_alive():
        p.terminate()
        p.join(2)
print("Fixed nonce control/LPAC GET fixture PASS on local loopback")
