if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-df8da0330406';$files=@{
  'probe-windows-lpac.ps1'='e59dea594801a2b8dcc7872524c7535a2493c9ccf3f8c8efb2ed19b09e5fc86a'
  'probe-interactive.ps1'='844df67e3a8c1008bb7925bf163e19afdf5abd54a48afbcee3dab1262c671c7d'
  'run-lpac-task.ps1'='e1a418fbff512aff8a200ce71d0b137b07d1a722b502a3e57a024767084d58f4'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
