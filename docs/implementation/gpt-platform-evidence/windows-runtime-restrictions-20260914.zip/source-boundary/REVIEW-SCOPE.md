# Current LPAC OS source/write boundary

One fixed cmd.exe diagnostic, SHA pinned from read-only installed identity. Fresh profile/task/stage; same current3 capabilities and Limited/session1/token/AccessCheck checks. No Codex or HTTP/provider process. Reuses accepted read-boundary mode, adds private writable home matching runtime permissions and three fixed synthetic file operations.

Positive controls: read inside/inside.txt exact nonce marker and write inside/home/allowed-write.txt exact OMS_WRITE_OK. Negative controls: reading parent/outside.txt denied; creating inside/blocked-write.txt denied; creating parent/outside-write.txt denied. Exact stdout/three English Access is denied stderr/exit1 required; existing inside/outside markers unchanged, forbidden new paths absent. No retained user paths or shared ACL changes.45s child/80s inner/110s task retained; all cleanup and Hub guards.

This proves these actual current LPAC file operations, not every possible path or production launcher integration. Await independent review/O clearance.
