if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-402b7507f860';$files=@{
  'probe-windows-lpac.ps1'='091f7fb9ba627b07ee909e49cbb3783d49cf34e5b57fa8bb91b64b14471b3afb'
  'probe-interactive.ps1'='498cc9f9b366509c26aae5ddd086e442494924f8a3075b91e17ef0324fca50fc'
  'run-lpac-task.ps1'='db29f819eb68a5b47beae90c54c3afcd4cff1e7b3923370a69a4240496bfd23c'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
