from pathlib import Path
import json,base64,subprocess,time,hashlib
r=Path('/Users/connor/.codex/visualizations/2026/09/11/01a09271-e627-7712-a2fc-ff675db23a8b/windows-restrictions-20260914/source-boundary')
m=json.loads((r/'manifest.json').read_text())
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==m['runner_sha256'], 'runner hash drift'
e=r/'execution';e.mkdir(exist_ok=False)
def run(name,args,timeout=45):
 (e/(name+'.command.json')).write_text(json.dumps(args,indent=2))
 try:p=subprocess.run(args,capture_output=True,timeout=timeout)
 except subprocess.TimeoutExpired as x:
  (e/(name+'.stdout')).write_bytes(x.stdout or b'');(e/(name+'.stderr')).write_bytes(x.stderr or b'');raise
 (e/(name+'.stdout')).write_bytes(p.stdout);(e/(name+'.stderr')).write_bytes(p.stderr)
 print(name,p.returncode,flush=True)
 if p.returncode: raise RuntimeError(name+' failed: '+p.stderr.decode()[-1000:])
 return p.stdout

def ps(name,s,timeout=45):return run(name,['ssh','-o','BatchMode=yes','nuc','powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(s.encode('utf-16-le')).decode()],timeout)
s=(r.parent/'read-only-preflight.ps1').read_text()
x=json.loads(ps('fresh-preflight',s));assert x['runtime_sha']==m['executable_sha256'];assert x['health']['build_revision']=='f487c6229b91d2b1ac11729e465561f6c1ffe997';assert x['listeners'][0]['OwningProcess']==8268;assert not x['owned'];assert x['hub_process']['ParentProcessId']==11300
ps('stage-create',(r/'stage-create.ps1').read_text())
run('stage-copy',['scp','-q',*[str(r/k) for k in m['files']],f"nuc:{m['remote_root']}/"],90)
ps('stage-validation',(r/'validate-staged.ps1').read_text())
ps('invocation',(r/'invocation.ps1').read_text(),150)
