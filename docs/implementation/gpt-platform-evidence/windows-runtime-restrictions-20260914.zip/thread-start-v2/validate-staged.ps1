if('true' -ne 'true'){throw 'Prepared only: exact rebuilt runtime hash has not been bound.'}
$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-727dd1588b12';$files=@{
  'probe-windows-lpac.ps1'='6d439e157bdea3dba94e4d984e2d8ded7270c58325e142a0a5f9eae73fc8253c'
  'probe-interactive.ps1'='54991678db55c70f6c326bd8075865e62c7892aa16d81eafd1177f06f43df56b'
  'run-lpac-task.ps1'='2217dc20b1939bde9f60b1f0bbd983f476cb09ae1eb3c918fd3fa8d8bac22848'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
