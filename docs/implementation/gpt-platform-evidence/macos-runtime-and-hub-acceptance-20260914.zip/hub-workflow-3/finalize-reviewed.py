import hashlib,json,runpy
from pathlib import Path
from zipfile import ZipFile
import httpx
from oms_hub.study_generation.native_quiz import parse_native_quiz
root=Path(__file__).parent
run_id="3518e8cc-fe0a-422b-8473-e02eb2cfe0be"
base="http://127.0.0.1:62170"
fixture=runpy.run_path("/Users/connor/Developer/worktrees/oms-gpt-runtime-activation/tests/v2/test_gpt_lecture_acceptance.py")
review_path=root/"review.json"
assert hashlib.sha256(review_path.read_bytes()).hexdigest()=="c5eeec69ca9eca710b8401baff47dcf600813e64b6af62d5e280f051530fc5da"
review=json.loads(review_path.read_text())
assert [q["correct_index"] for q in review["questions"]]==[0,2,1]
receipt={"run_id":run_id,"hub_verified":False,"native_mac_office_verified":False}
with httpx.Client(base_url=base,timeout=30,trust_env=False) as client:
    assert client.get("/settings").status_code==200
    client.headers["X-CSRF-Token"]=client.cookies["study_hub_csrf"]
    assert client.get(f"/studio/runs/{run_id}/review/data").json()==review
    fixture["_verify"](client,run_id)
    after=client.get(f"/studio/runs/{run_id}/review/data")
    assert after.status_code==200 and not after.json()["blockers"]
    (root/"verified-review.json").write_text(json.dumps(after.json(),indent=2))
    assert client.get(f"/studio/runs/{run_id}/preview/content").status_code==200
    published=client.post(f"/studio/runs/{run_id}/publication")
    assert published.status_code==200,published.text
    token=published.json()["token"]
    receipt.update(publication=published.json(),quiz_url=f"{base}/public/quizzes/{token}")
    (root/"final-result.json").write_text(json.dumps(receipt,indent=2))
    public=client.get(f"/public/quizzes/{token}/content")
    assert public.status_code==200
    content=public.json();questions=content["questions"]
    assert len(questions)==3
    assert all("correct" not in key and key!="rationale" for q in questions for key in q)
    (root/"public-content.json").write_text(json.dumps(content,indent=2))
    assert client.get(f"/public/quizzes/{token}").status_code==200
    media=client.get(next(q["image_url"] for q in questions if q.get("image_url")))
    assert media.status_code==200 and media.headers["content-type"].startswith("image/png")
    (root/"published-diagram.png").write_bytes(media.content)
    first=questions[0]
    answer=client.post(f"/public/quizzes/{token}/answer",json={"question_id":first["id"],"choice_id":"c1"})
    assert answer.status_code==200 and answer.json()["correct"] is True and "rationale" in answer.json()
    (root/"grade.json").write_text(json.dumps(answer.json(),indent=2))
    exports={}
    for suffix in ("json","zip","pdf"):
        response=client.get(f"/studio/runs/{run_id}/exports/{suffix}")
        assert response.status_code==200,response.text
        assert response.headers["cache-control"]=="private, no-store"
        path=root/f"synthetic-lecture-quiz.{suffix}"
        path.write_bytes(response.content)
        exports[suffix]={"path":str(path),"sha256":hashlib.sha256(response.content).hexdigest(),"bytes":len(response.content)}
    quiz=parse_native_quiz((root/"synthetic-lecture-quiz.json").read_text())
    assert len(quiz.questions)==3
    with ZipFile(root/"synthetic-lecture-quiz.zip") as bundle:
        manifest=json.loads(bundle.read("manifest.json"))
        assert bundle.read(next(iter(manifest["images"].values()))["path"])==media.content
    assert (root/"synthetic-lecture-quiz.pdf").read_bytes().startswith(b"%PDF-")
    receipt.update(hub_verified=True,answer_verification=True,publication_verified=True,grading_verified=True,exports=exports)
    (root/"final-result.json").write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
