# Insert before app=create_app(settings), in the isolated preview serve.py only.
import hashlib
import runpy
import oms_hub.app as app_module
fixture = runpy.run_path("/Users/connor/Developer/worktrees/oms-gpt-mac-acceptance/tests/v2/test_gpt_lecture_acceptance.py")
class SyntheticConverter(fixture["FixtureOfficeConverter"]):
    def convert(self, source, destination):
        if hashlib.sha256(source.read_bytes()).hexdigest() != "c38f77e33c33a0b25679475a0c80e28fb50db0dfa7a048c6fb54206d7508d6c5":
            raise ValueError("This preview converter accepts only the reviewed synthetic slide")
        return super().convert(source, destination)
app_module.SerialOfficeConverter = lambda *args, **kwargs: SyntheticConverter()
app_module.PresentationRenderer = fixture["IsolatedFixtureRenderer"]
# Keep the existing app=create_app(settings) here; never replace CodexSessionClient.
app = create_app(settings)
def paid_or_google(*args, **kwargs):
    raise AssertionError("Paid API and Google are outside this synthetic acceptance")
for method in ("clean", "generate_text", "generate_text_for_task", "for_task", "test_connection"):
    setattr(app.state.llm_service, method, paid_or_google)
app.state.medical_accuracy_gate.validate = paid_or_google
app.state.studio_worker.gateway.ask_studio = paid_or_google
app.state.notebook_connection.invalidate = paid_or_google
