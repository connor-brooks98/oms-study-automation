import json,os,socket
from pathlib import Path
import uvicorn
from oms_hub.app import create_app
from oms_hub.config import Settings
root=Path(__file__).parent
config=json.loads((root/'launch.json').read_text())
listener=socket.socket();listener.bind(('127.0.0.1',config['port']));port=listener.getsockname()[1]
settings=Settings(_env_file=None,transcript_prompt_path=Path('/Users/connor/.codex/visualizations/2026/09/11/01a09271-e627-7712-a2fc-ff675db23a8b/mac-generation-acceptance-20260914/hub-synthetic-artifacts-1/cleaning-prompt.md'),transcript_prompt_sha256='865034d61ed0493c2d95fa6e60edeb2911a84026d18ba2ba609c6003fba5a2c7',icloud_staging_root=root/'synthetic-staging',data_dir=root/'data',database_url=f"sqlite:///{root/'data'/'hub.db'}",study_root=root/'lectures',dashboard_host='127.0.0.1',dashboard_port=port,anki_enabled=False,study_backend='codex_subscription',codex_executable=Path(config['executable']),codex_binary_sha256=config['sha256'],build_revision=config['commit'],build_tree=config['tree'])
# Insert before app=create_app(settings), in the isolated preview serve.py only.
import hashlib
import runpy
import oms_hub.app as app_module
fixture = runpy.run_path("/Users/connor/Developer/worktrees/oms-gpt-mac-acceptance/tests/v2/test_gpt_lecture_acceptance.py")
class SyntheticConverter(fixture["FixtureOfficeConverter"]):
    def convert(self, source, destination):
        if hashlib.sha256(source.read_bytes()).hexdigest() != "c38f77e33c33a0b25679475a0c80e28fb50db0dfa7a048c6fb54206d7508d6c5":
            raise ValueError("This preview converter accepts only the reviewed synthetic slide")
        return super().convert(source, destination)
app_module.SerialOfficeConverter = lambda *args, **kwargs: SyntheticConverter()
app_module.PresentationRenderer = fixture["IsolatedFixtureRenderer"]
# Keep the existing app=create_app(settings) here; never replace CodexSessionClient.
app = create_app(settings)
def paid_or_google(*args, **kwargs):
    raise AssertionError("Paid API and Google are outside this synthetic acceptance")
for method in ("clean", "generate_text", "generate_text_for_task", "for_task", "test_connection"):
    setattr(app.state.llm_service, method, paid_or_google)
app.state.medical_accuracy_gate.validate = paid_or_google
app.state.studio_worker.gateway.ask_studio = paid_or_google
app.state.notebook_connection.invalidate = paid_or_google

(root/'server.json').write_text(json.dumps({'pid':os.getpid(),'port':port,'url':f'http://127.0.0.1:{port}','root':str(root),'commit':config['commit']}))
uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,log_level='info')).run(sockets=[listener])
