"""One-shot launcher; executing this file starts the reviewed remote task."""
from pathlib import Path
import base64
import datetime
import hashlib
import json
import subprocess

p = Path(__file__).parent
stage = json.loads((p / 'stage.json').read_text())
for name, key in [('probe-windows-lpac.ps1', 'script_sha256'), ('probe-interactive.ps1', 'inner_sha256'), ('run-lpac-task.ps1', 'outer_sha256')]:
    assert hashlib.sha256((p / name).read_bytes()).hexdigest() == stage[key], name
command = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'ServerAliveInterval=5', '-o', 'ServerAliveCountMax=2', 'nuc',
           'powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand ' + base64.b64encode((p / 'invocation.ps1').read_text().encode('utf-16le')).decode()]
record = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'timed_out': False, 'task_name': stage['task_name'], 'probe_sha256': stage['script_sha256']}
# A consumed or ambiguous launch is never replayed automatically.
with (p / 'launch-record.json').open('x') as out:
    json.dump(record, out)
with (p / 'native-launch.stdout').open('xb', buffering=0) as out, (p / 'native-launch.stderr').open('xb', buffering=0) as err:
    process = subprocess.Popen(command, stdout=out, stderr=err)
    try:
        process.wait(timeout=145)
    except subprocess.TimeoutExpired:
        record['timed_out'] = True
        process.kill()  # SSH transport only; remote task has its own watchdog.
        process.wait(timeout=5)
record.update(transport_returncode=process.returncode, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(p / 'launch-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
