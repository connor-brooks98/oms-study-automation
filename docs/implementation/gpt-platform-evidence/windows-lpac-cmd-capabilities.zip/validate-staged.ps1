$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-f66f9c339220';$files=@{
  'probe-windows-lpac.ps1'='e0f721e87a521cedb8100bd682badee0c8220082c372cb02d69e1174a4a05123'
  'probe-interactive.ps1'='3cee9a5c3a24ca96629e150206e886d9ad44081534c78507bf497793234c81d8'
  'run-lpac-task.ps1'='ea97ab0aed75fb64c3fce244555e138f6225bd0d9889170a33d8f9a1fb9e008e'
}
$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
