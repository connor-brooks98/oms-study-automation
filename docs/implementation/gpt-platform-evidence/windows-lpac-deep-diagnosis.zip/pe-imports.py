import struct,json,hashlib
from pathlib import Path

def inspect(path):
 b=Path(path).read_bytes()
 def u16(o):return struct.unpack_from('<H',b,o)[0]
 def u32(o):return struct.unpack_from('<I',b,o)[0]
 assert b[:2]==b'MZ'
 pe=u32(0x3c);assert b[pe:pe+4]==b'PE\0\0'
 machine=u16(pe+4);sections=u16(pe+6);opt=pe+24;magic=u16(opt);assert magic==0x20b and machine==0x8664
 sh=opt+u16(pe+20);sizeheaders=u32(opt+60)
 def offset(rva):
  if rva<sizeheaders:return rva
  for i in range(sections):
   o=sh+40*i;vs,va,rs,rp=struct.unpack_from('<IIII',b,o+8)
   if va<=rva<va+max(vs,rs):
    delta=rva-va;assert delta<rs;return rp+delta
  raise ValueError(('unmapped RVA',hex(rva)))
 def string(rva):
  o=offset(rva);e=b.index(b'\0',o,min(len(b),o+4096));return b[o:e].decode('ascii')
 rva,size=struct.unpack_from('<II',b,opt+120);imports=[]
 if rva:
  for i in range(min(size//20,4096)):
   lookup,stamp,chain,name,iat=struct.unpack_from('<IIIII',b,offset(rva+i*20))
   if not any((lookup,stamp,chain,name,iat)):break
   funcs=[];th=offset(lookup or iat)
   for j in range(65536):
    v=struct.unpack_from('<Q',b,th+8*j)[0]
    if not v:break
    funcs.append('ordinal:'+str(v&65535) if v>>63 else string(v+2))
   else:raise ValueError('unterminated thunk')
   imports.append({'dll':string(name),'functions':funcs})
  else:raise ValueError('unterminated import table')
 return {'path':str(path),'sha256':hashlib.sha256(b).hexdigest(),'machine':hex(machine),'imports':imports}
print(json.dumps([inspect(r'C:\Windows\System32\cmd.exe'),inspect(r'C:\Users\conbr\.local\bin\codex.exe')],indent=2))
