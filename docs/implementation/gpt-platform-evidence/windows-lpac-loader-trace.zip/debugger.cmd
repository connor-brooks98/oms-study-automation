.echo OMS_LOADER_TRACE_BEGIN
sxe -c ".lastevent;!gflag +sls;g" cpr
sxe -c ".lastevent;!gflag +sls;g" ibp
sxe -c ".exr -1;kb;gn" -c2 ".exr -1;kb;gn" 0xc0000142
sxn -c ".lastevent" epr
g
