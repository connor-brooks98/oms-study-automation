$ErrorActionPreference='Stop';$root='C:/Users/conbr/AppData/Local/OMSStudyHub/acceptance/lpac-fcd55bd8cb55';$files=@{
  'probe-windows-lpac.ps1'='e0f721e87a521cedb8100bd682badee0c8220082c372cb02d69e1174a4a05123'
  'probe-interactive.ps1'='54f7230945321510fb70fcb8a466998742d5e080b6d9a5ffe01e30b66e871577'
  'run-lpac-task.ps1'='4d018e02c0afad0b901f7bcda4ddd666cf9c755ce91b5cb07978661e4b6afbf0'
}
if((Get-FileHash -LiteralPath (Join-Path $root 'debugger.cmd') -Algorithm SHA256).Hash.ToLower() -ne '71f7c357bd91fa93c922e23c9c737ab631d5435f4c977c3f58fddc3a07e37dbe'){throw 'debugger command staged hash mismatch'};$result=@();foreach($name in $files.Keys){$path=Join-Path $root $name;$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();if($hash -ne $files[$name]){throw "staged hash mismatch: $name"};$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput([IO.File]::ReadAllText($path),[ref]$tokens,[ref]$errors);if(@($errors).Count){$errors | Format-List | Out-String | Write-Output;throw "PowerShell parse failed: $name"};$result+=@{name=$name;sha256=$hash;parse_errors=0}};ConvertTo-Json -InputObject $result -Depth 3
